'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface ThresholdMoment {
  id: string
  title: string
  description: string
  type: ThresholdType
  phase: 'approaching' | 'crossing' | 'integrating' | 'completed'
  beforeState: string    // Who you were before
  afterState?: string    // Who you are becoming/became
  lessons: string[]
  challenges: string[]
  gifts: string[]        // What this threshold gave you
  witnesses?: string[]   // People who witnessed/supported
  rituals?: string[]     // Rituals performed
  symbols: string[]      // Symbols associated
  dateStarted: number
  dateCrossed?: number
  dateIntegrated?: number
  intensity: number      // 1-10
  notes: ThresholdNote[]
}

interface ThresholdNote {
  id: string
  content: string
  phase: ThresholdMoment['phase']
  timestamp: number
}

type ThresholdType = 
  | 'death_rebirth'      // Major transformation
  | 'initiation'         // Entry into new role/stage
  | 'separation'         // Leaving something behind
  | 'return'             // Coming back changed
  | 'awakening'          // Consciousness shift
  | 'healing'            // Healing journey
  | 'commitment'         // Major commitment
  | 'release'            // Letting go
  | 'emergence'          // Something new emerging
  | 'integration'        // Bringing parts together

// ============================================================================
// CONSTANTS
// ============================================================================

const THRESHOLD_TYPES: Record<ThresholdType, { label: string; icon: string; color: string; description: string }> = {
  death_rebirth: { 
    label: 'Death & Rebirth', 
    icon: '🔥', 
    color: 'red',
    description: 'Complete transformation - the old self dies, new self emerges'
  },
  initiation: { 
    label: 'Initiation', 
    icon: '⚔️', 
    color: 'amber',
    description: 'Entry into a new role, stage of life, or community'
  },
  separation: { 
    label: 'Separation', 
    icon: '🚪', 
    color: 'purple',
    description: 'Leaving behind what no longer serves'
  },
  return: { 
    label: 'Return', 
    icon: '🏠', 
    color: 'emerald',
    description: 'Coming back to origin, transformed'
  },
  awakening: { 
    label: 'Awakening', 
    icon: '👁️', 
    color: 'cyan',
    description: 'Shift in consciousness or perception'
  },
  healing: { 
    label: 'Healing Journey', 
    icon: '💚', 
    color: 'green',
    description: 'Moving through and integrating wounds'
  },
  commitment: { 
    label: 'Commitment', 
    icon: '💍', 
    color: 'pink',
    description: 'Major vow, promise, or dedication'
  },
  release: { 
    label: 'Release', 
    icon: '🕊️', 
    color: 'sky',
    description: 'Letting go of attachments, identities, or burdens'
  },
  emergence: { 
    label: 'Emergence', 
    icon: '🦋', 
    color: 'violet',
    description: 'Something new coming into being'
  },
  integration: { 
    label: 'Integration', 
    icon: '☯️', 
    color: 'indigo',
    description: 'Bringing disparate parts into wholeness'
  }
}

const PHASE_INFO = {
  approaching: { label: 'Approaching', color: 'amber', icon: '→' },
  crossing: { label: 'Crossing', color: 'red', icon: '⚡' },
  integrating: { label: 'Integrating', color: 'purple', icon: '∞' },
  completed: { label: 'Completed', color: 'emerald', icon: '✓' }
}

// ============================================================================
// THRESHOLD CARD
// ============================================================================

function ThresholdCard({ 
  threshold, 
  onSelect 
}: { 
  threshold: ThresholdMoment
  onSelect: () => void
}) {
  const typeInfo = THRESHOLD_TYPES[threshold.type]
  const phaseInfo = PHASE_INFO[threshold.phase]
  
  const daysSinceCrossing = threshold.dateCrossed 
    ? Math.floor((Date.now() - threshold.dateCrossed) / (1000 * 60 * 60 * 24))
    : null
  
  return (
    <div 
      className={`cascade-card p-5 cursor-pointer hover:border-${typeInfo.color}-500/30 transition-all`}
      onClick={onSelect}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{typeInfo.icon}</span>
          <div>
            <h3 className="font-medium text-zinc-200">{threshold.title}</h3>
            <p className="text-xs text-zinc-500">{typeInfo.label}</p>
          </div>
        </div>
        <span className={`px-2 py-1 rounded-full text-xs bg-${phaseInfo.color}-500/20 text-${phaseInfo.color}-400`}>
          {phaseInfo.icon} {phaseInfo.label}
        </span>
      </div>
      
      <p className="text-sm text-zinc-400 line-clamp-2 mb-4">{threshold.description}</p>
      
      {/* Before/After */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="p-2 bg-zinc-800/50 rounded text-xs">
          <p className="text-zinc-500 mb-1">Before</p>
          <p className="text-zinc-400 line-clamp-1">{threshold.beforeState}</p>
        </div>
        <div className={`p-2 bg-${typeInfo.color}-500/5 rounded text-xs`}>
          <p className="text-zinc-500 mb-1">After</p>
          <p className="text-zinc-300 line-clamp-1">{threshold.afterState || '...'}</p>
        </div>
      </div>
      
      {/* Progress indicator */}
      <div className="flex gap-1 mb-3">
        {(['approaching', 'crossing', 'integrating', 'completed'] as const).map((phase, i) => (
          <div 
            key={phase}
            className={`h-1 flex-1 rounded-full ${
              i <= ['approaching', 'crossing', 'integrating', 'completed'].indexOf(threshold.phase)
                ? `bg-${typeInfo.color}-500`
                : 'bg-zinc-800'
            }`}
          />
        ))}
      </div>
      
      {/* Symbols */}
      {threshold.symbols.length > 0 && (
        <div className="flex gap-1">
          {threshold.symbols.slice(0, 5).map((symbol, i) => (
            <span key={i} className="text-lg">{symbol}</span>
          ))}
        </div>
      )}
      
      {daysSinceCrossing !== null && (
        <p className="text-xs text-zinc-600 mt-2">
          {daysSinceCrossing === 0 ? 'Crossed today' : `${daysSinceCrossing} days since crossing`}
        </p>
      )}
    </div>
  )
}

// ============================================================================
// CREATE THRESHOLD FORM
// ============================================================================

function CreateThresholdForm({
  onSave,
  onCancel
}: {
  onSave: (threshold: Omit<ThresholdMoment, 'id' | 'notes'>) => void
  onCancel: () => void
}) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [type, setType] = useState<ThresholdType>('emergence')
  const [phase, setPhase] = useState<ThresholdMoment['phase']>('approaching')
  const [beforeState, setBeforeState] = useState('')
  const [afterState, setAfterState] = useState('')
  const [lessons, setLessons] = useState('')
  const [challenges, setChallenges] = useState('')
  const [gifts, setGifts] = useState('')
  const [symbols, setSymbols] = useState('')
  const [intensity, setIntensity] = useState(7)
  
  const handleSubmit = () => {
    if (!title.trim() || !beforeState.trim()) return
    
    onSave({
      title,
      description,
      type,
      phase,
      beforeState,
      afterState: afterState || undefined,
      lessons: lessons.split('\n').filter(l => l.trim()),
      challenges: challenges.split('\n').filter(c => c.trim()),
      gifts: gifts.split('\n').filter(g => g.trim()),
      symbols: symbols.split(' ').filter(s => s.trim()),
      intensity,
      dateStarted: Date.now(),
      dateCrossed: phase !== 'approaching' ? Date.now() : undefined
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Mark a Threshold</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Name this threshold..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">What is this threshold?</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what you're going through..."
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Type</label>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            {(Object.entries(THRESHOLD_TYPES) as [ThresholdType, typeof THRESHOLD_TYPES[ThresholdType]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setType(key)}
                className={`p-2 rounded-lg text-xs transition-all ${
                  type === key
                    ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                    : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
                title={info.description}
              >
                <span className="text-lg block">{info.icon}</span>
                <span className="text-zinc-400">{info.label}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Current Phase</label>
          <div className="grid grid-cols-4 gap-2">
            {(Object.entries(PHASE_INFO) as [ThresholdMoment['phase'], typeof PHASE_INFO[ThresholdMoment['phase']]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setPhase(key)}
                className={`p-3 rounded-lg text-sm ${
                  phase === key
                    ? `bg-${info.color}-500/20 text-${info.color}-400 border border-${info.color}-500/50`
                    : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                {info.icon} {info.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Who I was before</label>
            <textarea
              value={beforeState}
              onChange={(e) => setBeforeState(e.target.value)}
              placeholder="The old self, old life, old way..."
              rows={2}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Who I am becoming</label>
            <textarea
              value={afterState}
              onChange={(e) => setAfterState(e.target.value)}
              placeholder="The new self emerging..."
              rows={2}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Intensity (1-10)</label>
          <input
            type="range"
            min="1"
            max="10"
            value={intensity}
            onChange={(e) => setIntensity(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-zinc-600">
            <span>Gentle shift</span>
            <span className="text-amber-400 font-bold">{intensity}</span>
            <span>Complete transformation</span>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Challenges (one per line)</label>
            <textarea
              value={challenges}
              onChange={(e) => setChallenges(e.target.value)}
              placeholder="What makes this hard..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Lessons (one per line)</label>
            <textarea
              value={lessons}
              onChange={(e) => setLessons(e.target.value)}
              placeholder="What this is teaching..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Gifts (one per line)</label>
            <textarea
              value={gifts}
              onChange={(e) => setGifts(e.target.value)}
              placeholder="What this is giving..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Symbols (emojis/words, space separated)</label>
          <input
            type="text"
            value={symbols}
            onChange={(e) => setSymbols(e.target.value)}
            placeholder="🔥 🦋 🌊 phoenix rebirth..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!title.trim() || !beforeState.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-red-500 text-white font-medium rounded-lg disabled:opacity-50"
          >
            Mark Threshold
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function ThresholdPage() {
  const [thresholds, setThresholds] = useState<ThresholdMoment[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedThreshold, setSelectedThreshold] = useState<ThresholdMoment | null>(null)
  const [filter, setFilter] = useState<'all' | ThresholdMoment['phase']>('all')
  
  // Load thresholds
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-thresholds')
      if (saved) setThresholds(JSON.parse(saved))
    }
  }, [])
  
  const saveThreshold = (threshold: Omit<ThresholdMoment, 'id' | 'notes'>) => {
    const newThreshold: ThresholdMoment = {
      ...threshold,
      id: `threshold-${Date.now()}`,
      notes: []
    }
    
    const updated = [newThreshold, ...thresholds]
    setThresholds(updated)
    localStorage.setItem('cascade-thresholds', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const updatePhase = (id: string, phase: ThresholdMoment['phase']) => {
    const updated = thresholds.map(t => {
      if (t.id === id) {
        return {
          ...t,
          phase,
          dateCrossed: phase !== 'approaching' && !t.dateCrossed ? Date.now() : t.dateCrossed,
          dateIntegrated: phase === 'completed' ? Date.now() : t.dateIntegrated
        }
      }
      return t
    })
    setThresholds(updated)
    localStorage.setItem('cascade-thresholds', JSON.stringify(updated))
  }
  
  const filteredThresholds = filter === 'all' 
    ? thresholds 
    : thresholds.filter(t => t.phase === filter)
  
  // Stats
  const activeCount = thresholds.filter(t => t.phase !== 'completed').length
  const completedCount = thresholds.filter(t => t.phase === 'completed').length
  const crossingCount = thresholds.filter(t => t.phase === 'crossing').length
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Threshold Moments</h1>
        <p className="text-zinc-500">Track your liminal passages and transformations</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{thresholds.length}</p>
          <p className="text-xs text-zinc-500">Total Thresholds</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-red-400">{crossingCount}</p>
          <p className="text-xs text-zinc-500">Currently Crossing</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{activeCount}</p>
          <p className="text-xs text-zinc-500">Active</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{completedCount}</p>
          <p className="text-xs text-zinc-500">Completed</p>
        </div>
      </div>
      
      {showCreate ? (
        <CreateThresholdForm onSave={saveThreshold} onCancel={() => setShowCreate(false)} />
      ) : (
        <>
          <button
            onClick={() => setShowCreate(true)}
            className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-amber-400 hover:border-amber-500/30 transition-all"
          >
            + Mark a Threshold
          </button>
          
          {/* Filter */}
          <div className="flex gap-2 mb-6">
            {(['all', 'approaching', 'crossing', 'integrating', 'completed'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-lg text-sm ${
                  filter === f
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                {f === 'all' ? 'All' : PHASE_INFO[f].label}
              </button>
            ))}
          </div>
          
          {filteredThresholds.length === 0 ? (
            <div className="cascade-card p-12 text-center">
              <p className="text-4xl mb-4">🚪</p>
              <p className="text-zinc-400">No thresholds marked yet</p>
              <p className="text-sm text-zinc-600">Life is a series of thresholds</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredThresholds.map(threshold => (
                <ThresholdCard
                  key={threshold.id}
                  threshold={threshold}
                  onSelect={() => setSelectedThreshold(threshold)}
                />
              ))}
            </div>
          )}
        </>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-amber-500/5 to-red-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🚪 On Thresholds</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "The threshold is the place where you leave behind everything that was and 
          prepare for everything that might be." — Joseph Campbell
        </p>
        <p className="text-sm text-zinc-500">
          Liminal spaces are neither here nor there. They are the doorways between states 
          of being. Every major life transition is a threshold: leaving a job, ending a 
          relationship, having a child, a health crisis, a spiritual awakening. By marking 
          and honoring these passages, we transform unconscious change into conscious initiation.
        </p>
      </div>
    </div>
  )
}
