'use client'

import { useState, useEffect, useMemo } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface DataSource {
  key: string
  name: string
  icon: string
  color: string
  count: number
  lastUpdated: number | null
  path: string
}

interface Connection {
  source: string
  target: string
  type: 'correlation' | 'causation' | 'resonance' | 'conflict'
  strength: number  // 0-1
  description: string
  timestamp: number
}

interface IntegrationInsight {
  id: string
  title: string
  description: string
  sources: string[]
  category: 'pattern' | 'correlation' | 'recommendation' | 'warning'
  importance: 'low' | 'medium' | 'high'
  timestamp: number
}

// ============================================================================
// DATA SOURCE DEFINITIONS
// ============================================================================

const DATA_SOURCES: Omit<DataSource, 'count' | 'lastUpdated'>[] = [
  { key: 'cascade-journal', name: 'Journal', icon: '📓', color: 'cyan', path: '/journal' },
  { key: 'cascade-dreams', name: 'Dreams', icon: '🌙', color: 'indigo', path: '/dreams' },
  { key: 'cascade-shadow-aspects', name: 'Shadow', icon: '🌑', color: 'purple', path: '/shadow' },
  { key: 'cascade-inner-parts', name: 'Inner Council', icon: '👥', color: 'pink', path: '/council' },
  { key: 'cascade-life-scripts', name: 'Life Scripts', icon: '📜', color: 'amber', path: '/scripts' },
  { key: 'cascade-archetypes', name: 'Archetypes', icon: '🏛️', color: 'red', path: '/archetypes' },
  { key: 'cascade-synchronicities', name: 'Synchronicities', icon: '✨', color: 'purple', path: '/sync' },
  { key: 'cascade-thresholds', name: 'Thresholds', icon: '🚪', color: 'amber', path: '/thresholds' },
  { key: 'cascade-attractors', name: 'Attractors', icon: '🎯', color: 'cyan', path: '/attractors' },
  { key: 'cascade-temporal-anchors', name: 'Temporal Anchors', icon: '⚓', color: 'blue', path: '/anchors' },
  { key: 'cascade-field-notes', name: 'Field Notes', icon: '📝', color: 'amber', path: '/notes' },
  { key: 'cascade-somatic', name: 'Somatic', icon: '🧘', color: 'emerald', path: '/somatic' },
  { key: 'cascade-relationships', name: 'Relationships', icon: '💗', color: 'pink', path: '/constellation' },
  { key: 'cascade-beliefs', name: 'Beliefs', icon: '🏛️', color: 'amber', path: '/beliefs' },
  { key: 'cascade-gifts', name: 'Gifts', icon: '🎁', color: 'amber', path: '/gifts' },
  { key: 'cascade-predictions', name: 'Predictions', icon: '🎯', color: 'cyan', path: '/testing' },
  { key: 'cascade-goals', name: 'Goals', icon: '🎯', color: 'emerald', path: '/goals' },
  { key: 'cascade-decisions', name: 'Decisions', icon: '⚖️', color: 'purple', path: '/decisions' },
  { key: 'cascade-gratitude', name: 'Gratitude', icon: '🙏', color: 'pink', path: '/gratitude' },
  { key: 'cascade-focus', name: 'Focus', icon: '🎯', color: 'cyan', path: '/focus' },
]

// ============================================================================
// NETWORK VISUALIZATION
// ============================================================================

function NetworkView({ 
  sources, 
  connections,
  onNodeClick 
}: { 
  sources: DataSource[]
  connections: Connection[]
  onNodeClick: (source: DataSource) => void
}) {
  // Position nodes in a circle
  const centerX = 250
  const centerY = 200
  const radius = 160
  
  const activeSources = sources.filter(s => s.count > 0)
  
  const getPosition = (index: number, total: number) => {
    const angle = (index / total) * 2 * Math.PI - Math.PI / 2
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle)
    }
  }
  
  return (
    <svg viewBox="0 0 500 400" className="w-full h-full">
      {/* Connection lines */}
      {connections.map((conn, i) => {
        const sourceIndex = activeSources.findIndex(s => s.key === conn.source)
        const targetIndex = activeSources.findIndex(s => s.key === conn.target)
        if (sourceIndex === -1 || targetIndex === -1) return null
        
        const sourcePos = getPosition(sourceIndex, activeSources.length)
        const targetPos = getPosition(targetIndex, activeSources.length)
        
        return (
          <line
            key={`conn-${i}`}
            x1={sourcePos.x}
            y1={sourcePos.y}
            x2={targetPos.x}
            y2={targetPos.y}
            stroke={conn.type === 'correlation' ? '#06b6d4' :
                   conn.type === 'resonance' ? '#a855f7' :
                   conn.type === 'conflict' ? '#ef4444' : '#71717a'}
            strokeWidth={conn.strength * 3}
            strokeOpacity={0.4}
          />
        )
      })}
      
      {/* Center node */}
      <circle
        cx={centerX}
        cy={centerY}
        r="30"
        fill="url(#centerGrad)"
        className="drop-shadow-lg"
      />
      <text
        x={centerX}
        y={centerY}
        textAnchor="middle"
        dominantBaseline="middle"
        className="text-xs fill-white font-medium"
      >
        YOU
      </text>
      
      {/* Data source nodes */}
      {activeSources.map((source, i) => {
        const pos = getPosition(i, activeSources.length)
        const size = Math.min(25, 10 + Math.log(source.count + 1) * 5)
        
        return (
          <g 
            key={source.key} 
            onClick={() => onNodeClick(source)}
            className="cursor-pointer"
          >
            <circle
              cx={pos.x}
              cy={pos.y}
              r={size}
              fill={`rgb(39, 39, 42)`}
              stroke={`var(--${source.color}-500, #06b6d4)`}
              strokeWidth="2"
              className="hover:stroke-white transition-all"
            />
            <text
              x={pos.x}
              y={pos.y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-sm pointer-events-none"
            >
              {source.icon}
            </text>
            <text
              x={pos.x}
              y={pos.y + size + 12}
              textAnchor="middle"
              className="text-[10px] fill-zinc-500 pointer-events-none"
            >
              {source.name}
            </text>
            <text
              x={pos.x}
              y={pos.y + size + 22}
              textAnchor="middle"
              className="text-[8px] fill-zinc-600 pointer-events-none"
            >
              ({source.count})
            </text>
          </g>
        )
      })}
      
      {/* Gradient definitions */}
      <defs>
        <radialGradient id="centerGrad">
          <stop offset="0%" stopColor="#06b6d4" />
          <stop offset="100%" stopColor="#a855f7" />
        </radialGradient>
      </defs>
    </svg>
  )
}

// ============================================================================
// INSIGHT CARD
// ============================================================================

function InsightCard({ insight }: { insight: IntegrationInsight }) {
  const categoryColors = {
    pattern: 'purple',
    correlation: 'cyan',
    recommendation: 'emerald',
    warning: 'amber'
  }
  
  const categoryIcons = {
    pattern: '🔮',
    correlation: '🔗',
    recommendation: '💡',
    warning: '⚠️'
  }
  
  return (
    <div className={`cascade-card p-4 border-l-2 border-${categoryColors[insight.category]}-500`}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <span>{categoryIcons[insight.category]}</span>
          <span className={`text-xs px-2 py-0.5 rounded bg-${categoryColors[insight.category]}-500/20 text-${categoryColors[insight.category]}-400`}>
            {insight.category}
          </span>
        </div>
        <span className={`text-xs ${
          insight.importance === 'high' ? 'text-red-400' :
          insight.importance === 'medium' ? 'text-amber-400' :
          'text-zinc-500'
        }`}>
          {insight.importance} importance
        </span>
      </div>
      <h4 className="text-sm font-medium text-zinc-200 mb-1">{insight.title}</h4>
      <p className="text-xs text-zinc-400 mb-2">{insight.description}</p>
      <div className="flex flex-wrap gap-1">
        {insight.sources.map(source => {
          const sourceInfo = DATA_SOURCES.find(s => s.key === source)
          return (
            <span key={source} className="text-xs px-1.5 py-0.5 bg-zinc-800 rounded text-zinc-500">
              {sourceInfo?.icon} {sourceInfo?.name}
            </span>
          )
        })}
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function IntegrationHubPage() {
  const [sources, setSources] = useState<DataSource[]>([])
  const [connections, setConnections] = useState<Connection[]>([])
  const [insights, setInsights] = useState<IntegrationInsight[]>([])
  const [selectedSource, setSelectedSource] = useState<DataSource | null>(null)
  
  // Load all data sources
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const loadedSources = DATA_SOURCES.map(source => {
        const data = localStorage.getItem(source.key)
        let parsed: any[] = []
        try {
          parsed = data ? JSON.parse(data) : []
        } catch {}
        
        const lastEntry = parsed.length > 0 
          ? Math.max(...parsed.map((e: any) => e.timestamp || e.createdAt || 0))
          : null
        
        return {
          ...source,
          count: Array.isArray(parsed) ? parsed.length : 0,
          lastUpdated: lastEntry
        }
      })
      
      setSources(loadedSources)
      generateInsights(loadedSources)
      generateConnections(loadedSources)
    }
  }, [])
  
  const generateConnections = (loadedSources: DataSource[]) => {
    const newConnections: Connection[] = []
    
    // Shadow ↔ Scripts correlation
    const shadowCount = loadedSources.find(s => s.key === 'cascade-shadow-aspects')?.count || 0
    const scriptsCount = loadedSources.find(s => s.key === 'cascade-life-scripts')?.count || 0
    if (shadowCount > 0 && scriptsCount > 0) {
      newConnections.push({
        source: 'cascade-shadow-aspects',
        target: 'cascade-life-scripts',
        type: 'correlation',
        strength: 0.8,
        description: 'Shadow aspects often link to limiting scripts',
        timestamp: Date.now()
      })
    }
    
    // Dreams ↔ Shadow resonance
    const dreamsCount = loadedSources.find(s => s.key === 'cascade-dreams')?.count || 0
    if (dreamsCount > 0 && shadowCount > 0) {
      newConnections.push({
        source: 'cascade-dreams',
        target: 'cascade-shadow-aspects',
        type: 'resonance',
        strength: 0.7,
        description: 'Dreams often reveal shadow material',
        timestamp: Date.now()
      })
    }
    
    // Archetypes ↔ Inner Council
    const archetypesCount = loadedSources.find(s => s.key === 'cascade-archetypes')?.count || 0
    const councilCount = loadedSources.find(s => s.key === 'cascade-inner-parts')?.count || 0
    if (archetypesCount > 0 && councilCount > 0) {
      newConnections.push({
        source: 'cascade-archetypes',
        target: 'cascade-inner-parts',
        type: 'resonance',
        strength: 0.9,
        description: 'Inner parts embody archetypal energies',
        timestamp: Date.now()
      })
    }
    
    // Beliefs ↔ Scripts
    const beliefsCount = loadedSources.find(s => s.key === 'cascade-beliefs')?.count || 0
    if (beliefsCount > 0 && scriptsCount > 0) {
      newConnections.push({
        source: 'cascade-beliefs',
        target: 'cascade-life-scripts',
        type: 'correlation',
        strength: 0.9,
        description: 'Core beliefs form the foundation of life scripts',
        timestamp: Date.now()
      })
    }
    
    // Somatic ↔ Shadow
    const somaticCount = loadedSources.find(s => s.key === 'cascade-somatic')?.count || 0
    if (somaticCount > 0 && shadowCount > 0) {
      newConnections.push({
        source: 'cascade-somatic',
        target: 'cascade-shadow-aspects',
        type: 'correlation',
        strength: 0.8,
        description: 'Body holds shadow material as tension',
        timestamp: Date.now()
      })
    }
    
    // Thresholds ↔ Archetypes
    const thresholdsCount = loadedSources.find(s => s.key === 'cascade-thresholds')?.count || 0
    if (thresholdsCount > 0 && archetypesCount > 0) {
      newConnections.push({
        source: 'cascade-thresholds',
        target: 'cascade-archetypes',
        type: 'resonance',
        strength: 0.7,
        description: 'Thresholds activate archetypal energies',
        timestamp: Date.now()
      })
    }
    
    // Attractors ↔ Goals
    const attractorsCount = loadedSources.find(s => s.key === 'cascade-attractors')?.count || 0
    const goalsCount = loadedSources.find(s => s.key === 'cascade-goals')?.count || 0
    if (attractorsCount > 0 && goalsCount > 0) {
      newConnections.push({
        source: 'cascade-attractors',
        target: 'cascade-goals',
        type: 'correlation',
        strength: 0.8,
        description: 'Goals are steps toward attractor states',
        timestamp: Date.now()
      })
    }
    
    // Gifts ↔ Relationships
    const giftsCount = loadedSources.find(s => s.key === 'cascade-gifts')?.count || 0
    const relationshipsCount = loadedSources.find(s => s.key === 'cascade-relationships')?.count || 0
    if (giftsCount > 0 && relationshipsCount > 0) {
      newConnections.push({
        source: 'cascade-gifts',
        target: 'cascade-relationships',
        type: 'resonance',
        strength: 0.6,
        description: 'Gifts are often reflected in relationships',
        timestamp: Date.now()
      })
    }
    
    setConnections(newConnections)
  }
  
  const generateInsights = (loadedSources: DataSource[]) => {
    const newInsights: IntegrationInsight[] = []
    
    // Activity pattern
    const activeSources = loadedSources.filter(s => s.count > 0)
    if (activeSources.length >= 5) {
      newInsights.push({
        id: 'insight-1',
        title: 'Strong Integration Practice',
        description: `You're actively tracking ${activeSources.length} data streams. This multi-dimensional awareness supports holistic growth.`,
        sources: activeSources.slice(0, 4).map(s => s.key),
        category: 'pattern',
        importance: 'medium',
        timestamp: Date.now()
      })
    }
    
    // Shadow-Script correlation
    const shadowCount = loadedSources.find(s => s.key === 'cascade-shadow-aspects')?.count || 0
    const scriptsCount = loadedSources.find(s => s.key === 'cascade-life-scripts')?.count || 0
    if (shadowCount > 0 && scriptsCount > 0) {
      newInsights.push({
        id: 'insight-2',
        title: 'Deep Psychological Work Active',
        description: 'Both shadow aspects and life scripts are being tracked. Consider exploring how your shadow aspects may be related to your limiting scripts.',
        sources: ['cascade-shadow-aspects', 'cascade-life-scripts'],
        category: 'correlation',
        importance: 'high',
        timestamp: Date.now()
      })
    }
    
    // Dreams without shadow work
    const dreamsCount = loadedSources.find(s => s.key === 'cascade-dreams')?.count || 0
    if (dreamsCount > 3 && shadowCount === 0) {
      newInsights.push({
        id: 'insight-3',
        title: 'Dreams May Reveal Shadow',
        description: 'You have recorded dreams but no shadow aspects. Dreams often contain shadow material. Consider mining your dreams for shadow content.',
        sources: ['cascade-dreams', 'cascade-shadow-aspects'],
        category: 'recommendation',
        importance: 'medium',
        timestamp: Date.now()
      })
    }
    
    // Somatic awareness
    const somaticCount = loadedSources.find(s => s.key === 'cascade-somatic')?.count || 0
    if (somaticCount > 0 && shadowCount > 0) {
      newInsights.push({
        id: 'insight-4',
        title: 'Body-Shadow Connection',
        description: 'Tracking both somatic sensations and shadow aspects. The body often holds what the mind represses. Notice where tension correlates with shadow themes.',
        sources: ['cascade-somatic', 'cascade-shadow-aspects'],
        category: 'correlation',
        importance: 'high',
        timestamp: Date.now()
      })
    }
    
    // Gifts and service
    const giftsCount = loadedSources.find(s => s.key === 'cascade-gifts')?.count || 0
    const goalsCount = loadedSources.find(s => s.key === 'cascade-goals')?.count || 0
    if (giftsCount > 0 && goalsCount > 0) {
      newInsights.push({
        id: 'insight-5',
        title: 'Gift-Goal Alignment Check',
        description: 'You have identified gifts and set goals. Review whether your goals utilize your natural gifts. Alignment here creates flow.',
        sources: ['cascade-gifts', 'cascade-goals'],
        category: 'recommendation',
        importance: 'medium',
        timestamp: Date.now()
      })
    }
    
    // Synchronicity awareness
    const syncCount = loadedSources.find(s => s.key === 'cascade-synchronicities')?.count || 0
    if (syncCount >= 5) {
      newInsights.push({
        id: 'insight-6',
        title: 'High Synchronicity Awareness',
        description: `You've logged ${syncCount} synchronicities. You're developing sensitivity to meaningful coincidences. Reality is becoming more responsive to your attention.`,
        sources: ['cascade-synchronicities'],
        category: 'pattern',
        importance: 'medium',
        timestamp: Date.now()
      })
    }
    
    // Threshold active
    const thresholdsCount = loadedSources.find(s => s.key === 'cascade-thresholds')?.count || 0
    if (thresholdsCount > 0) {
      newInsights.push({
        id: 'insight-7',
        title: 'Active Threshold Crossing',
        description: 'You are tracking a threshold moment. This is a liminal time. Honor the transition. Let the old die so the new can emerge.',
        sources: ['cascade-thresholds'],
        category: 'pattern',
        importance: 'high',
        timestamp: Date.now()
      })
    }
    
    setInsights(newInsights)
  }
  
  // Stats
  const totalEntries = sources.reduce((sum, s) => sum + s.count, 0)
  const activeSources = sources.filter(s => s.count > 0).length
  const recentActivity = sources.filter(s => {
    if (!s.lastUpdated) return false
    const dayAgo = Date.now() - 24 * 60 * 60 * 1000
    return s.lastUpdated > dayAgo
  }).length
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Integration Hub</h1>
        <p className="text-zinc-500">See the connections across your entire system</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{totalEntries}</p>
          <p className="text-xs text-zinc-500">Total Entries</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{activeSources}</p>
          <p className="text-xs text-zinc-500">Active Streams</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{connections.length}</p>
          <p className="text-xs text-zinc-500">Connections</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{recentActivity}</p>
          <p className="text-xs text-zinc-500">Active Today</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Network visualization */}
        <div className="lg:col-span-2">
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">🕸️ Data Network</h3>
            <div className="h-[400px]">
              <NetworkView 
                sources={sources}
                connections={connections}
                onNodeClick={setSelectedSource}
              />
            </div>
            <div className="mt-4 flex gap-4 justify-center text-xs text-zinc-500">
              <span><span className="inline-block w-3 h-0.5 bg-cyan-500 mr-1"></span>Correlation</span>
              <span><span className="inline-block w-3 h-0.5 bg-purple-500 mr-1"></span>Resonance</span>
              <span><span className="inline-block w-3 h-0.5 bg-red-500 mr-1"></span>Conflict</span>
            </div>
          </div>
          
          {/* Data sources grid */}
          <div className="mt-6 cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">📊 All Data Streams</h3>
            <div className="grid grid-cols-4 gap-3">
              {sources.map(source => (
                <a
                  key={source.key}
                  href={source.path}
                  className={`p-3 rounded-lg text-center hover:bg-zinc-800 transition-all ${
                    source.count > 0 ? '' : 'opacity-50'
                  }`}
                >
                  <span className="text-2xl block mb-1">{source.icon}</span>
                  <span className="text-xs text-zinc-400 block">{source.name}</span>
                  <span className={`text-xs ${source.count > 0 ? 'text-cyan-400' : 'text-zinc-600'}`}>
                    {source.count}
                  </span>
                </a>
              ))}
            </div>
          </div>
        </div>
        
        {/* Insights sidebar */}
        <div className="space-y-6">
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">💡 Integration Insights</h3>
            {insights.length === 0 ? (
              <p className="text-sm text-zinc-500">Add data to different streams to see insights emerge</p>
            ) : (
              <div className="space-y-4">
                {insights.map(insight => (
                  <InsightCard key={insight.id} insight={insight} />
                ))}
              </div>
            )}
          </div>
          
          {/* Philosophy */}
          <div className="cascade-card p-6 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
            <h3 className="text-lg font-medium text-zinc-200 mb-3">🕸️ On Integration</h3>
            <p className="text-sm text-zinc-400 mb-3">
              "The whole is greater than the sum of its parts." — Aristotle
            </p>
            <p className="text-sm text-zinc-500">
              Your inner landscape is not a collection of separate fragments — it's an 
              interconnected web. Dreams connect to shadow, shadow to beliefs, beliefs to 
              relationships, relationships to gifts. By seeing these connections, you 
              move from analysis to integration, from parts to wholeness.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
