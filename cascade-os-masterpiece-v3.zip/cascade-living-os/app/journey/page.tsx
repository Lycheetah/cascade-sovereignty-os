'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface JourneyStage {
  id: number
  name: string
  archetype: string
  description: string
  questions: string[]
  gifts: string[]
  shadows: string[]
  threshold: string
}

interface JourneyEntry {
  id: string
  stageId: number
  title: string
  narrative: string
  mentors: string[]
  allies: string[]
  threshold_crossed?: string
  gift_received?: string
  shadow_faced?: string
  lessons: string[]
  symbols: string[]
  timestamp: number
}

interface ActiveJourney {
  id: string
  name: string
  intention: string
  currentStage: number
  entries: JourneyEntry[]
  startedAt: number
  completedAt?: number
}

// ============================================================================
// THE 12 STAGES OF THE HERO'S JOURNEY
// ============================================================================

const JOURNEY_STAGES: JourneyStage[] = [
  {
    id: 1,
    name: 'The Ordinary World',
    archetype: 'The Innocent',
    description: 'Life before the adventure. The familiar world with its comforts and limitations.',
    questions: ['What is your current reality?', 'What feels incomplete or limiting?', 'What do you long for?'],
    gifts: ['Innocence', 'Trust', 'Optimism'],
    shadows: ['Denial', 'Complacency', 'Naivety'],
    threshold: 'Recognizing the call'
  },
  {
    id: 2,
    name: 'The Call to Adventure',
    archetype: 'The Orphan',
    description: 'Something disrupts the ordinary world. A challenge, opportunity, or crisis demands response.',
    questions: ['What is calling you?', 'What challenge has appeared?', 'What can no longer be ignored?'],
    gifts: ['Realism', 'Empathy', 'Resilience'],
    shadows: ['Victimhood', 'Cynicism', 'Helplessness'],
    threshold: 'Acknowledging the call'
  },
  {
    id: 3,
    name: 'Refusal of the Call',
    archetype: 'The Warrior',
    description: 'Fear and doubt arise. The ego resists change and clings to safety.',
    questions: ['What fears hold you back?', 'What are you protecting?', 'What is the cost of not answering?'],
    gifts: ['Courage', 'Discipline', 'Determination'],
    shadows: ['Aggression', 'Ruthlessness', 'Avoidance'],
    threshold: 'Choosing courage over comfort'
  },
  {
    id: 4,
    name: 'Meeting the Mentor',
    archetype: 'The Caregiver',
    description: 'A guide appears offering wisdom, tools, or confidence needed for the journey.',
    questions: ['Who or what is guiding you?', 'What wisdom have you received?', 'What tools do you need?'],
    gifts: ['Compassion', 'Generosity', 'Nurturing'],
    shadows: ['Martyrdom', 'Enabling', 'Guilt'],
    threshold: 'Receiving the gift'
  },
  {
    id: 5,
    name: 'Crossing the Threshold',
    archetype: 'The Seeker',
    description: 'Leaving the known world behind. The point of no return into the adventure.',
    questions: ['What are you leaving behind?', 'What is your first step?', 'What threshold are you crossing?'],
    gifts: ['Autonomy', 'Ambition', 'Identity'],
    shadows: ['Perfectionism', 'Chronic dissatisfaction', 'Self-absorption'],
    threshold: 'Taking the leap'
  },
  {
    id: 6,
    name: 'Tests, Allies, Enemies',
    archetype: 'The Destroyer',
    description: 'The special world tests the hero. Allies and enemies are distinguished.',
    questions: ['What is testing you?', 'Who are your true allies?', 'What must be destroyed or released?'],
    gifts: ['Humility', 'Metamorphosis', 'Revolution'],
    shadows: ['Destruction', 'Self-destruction', 'Rage'],
    threshold: 'Passing the tests'
  },
  {
    id: 7,
    name: 'Approach to the Inmost Cave',
    archetype: 'The Lover',
    description: 'Preparing for the central ordeal. Moving toward the greatest fear.',
    questions: ['What is your deepest fear?', 'What do you love enough to face it for?', 'How are you preparing?'],
    gifts: ['Passion', 'Commitment', 'Ecstasy'],
    shadows: ['Obsession', 'Jealousy', 'Loss of identity'],
    threshold: 'Committing fully'
  },
  {
    id: 8,
    name: 'The Ordeal',
    archetype: 'The Creator',
    description: 'The supreme crisis. Death and rebirth. Facing the greatest fear directly.',
    questions: ['What must die for the new to be born?', 'What is being created through this?', 'What is transforming?'],
    gifts: ['Identity', 'Vocation', 'Creativity'],
    shadows: ['Obsessive creation', 'Inability to complete', 'Self-indulgence'],
    threshold: 'Surviving transformation'
  },
  {
    id: 9,
    name: 'The Reward',
    archetype: 'The Ruler',
    description: 'Claiming the treasure. The hero takes possession of what was sought.',
    questions: ['What have you gained?', 'What new power or knowledge do you have?', 'How will you use it?'],
    gifts: ['Responsibility', 'Order', 'Sovereignty'],
    shadows: ['Control', 'Tyranny', 'Rigidity'],
    threshold: 'Accepting the prize'
  },
  {
    id: 10,
    name: 'The Road Back',
    archetype: 'The Magician',
    description: 'Beginning the return journey. Integrating the experience with ordinary life.',
    questions: ['How will you return?', 'What must be integrated?', 'What transformation must be embodied?'],
    gifts: ['Transformation', 'Vision', 'Power'],
    shadows: ['Manipulation', 'Disconnection', 'Megalomania'],
    threshold: 'Choosing to return'
  },
  {
    id: 11,
    name: 'The Resurrection',
    archetype: 'The Sage',
    description: 'Final test where everything is at stake. The hero is transformed completely.',
    questions: ['What is your final test?', 'How are you different now?', 'What wisdom have you gained?'],
    gifts: ['Wisdom', 'Non-attachment', 'Truth'],
    shadows: ['Coldness', 'Dogmatism', 'Disconnection'],
    threshold: 'Emerging transformed'
  },
  {
    id: 12,
    name: 'Return with the Elixir',
    archetype: 'The Jester',
    description: 'The hero returns to the ordinary world bearing gifts for others.',
    questions: ['What gift do you bring back?', 'How will you share it?', 'What joy arises?'],
    gifts: ['Joy', 'Freedom', 'Liberation'],
    shadows: ['Cruelty', 'Irresponsibility', 'Debauchery'],
    threshold: 'Sharing the gift'
  }
]

// ============================================================================
// JOURNEY VISUALIZATION
// ============================================================================

function JourneyCircle({ 
  currentStage, 
  entries,
  onStageClick 
}: { 
  currentStage: number
  entries: JourneyEntry[]
  onStageClick: (stageId: number) => void
}) {
  const centerX = 200
  const centerY = 200
  const radius = 160
  
  return (
    <div className="relative">
      <svg width="400" height="400" className="mx-auto">
        {/* Background circle */}
        <circle
          cx={centerX}
          cy={centerY}
          r={radius}
          fill="none"
          stroke="rgb(63, 63, 70)"
          strokeWidth="2"
          strokeDasharray="4,4"
        />
        
        {/* Inner circle */}
        <circle
          cx={centerX}
          cy={centerY}
          r={radius * 0.3}
          fill="url(#journeyGradient)"
          fillOpacity="0.2"
        />
        
        {/* Stage nodes */}
        {JOURNEY_STAGES.map((stage, i) => {
          const angle = (i / 12) * 2 * Math.PI - Math.PI / 2
          const x = centerX + radius * Math.cos(angle)
          const y = centerY + radius * Math.sin(angle)
          
          const hasEntries = entries.some(e => e.stageId === stage.id)
          const isCurrent = currentStage === stage.id
          const isPast = stage.id < currentStage
          
          return (
            <g key={stage.id} onClick={() => onStageClick(stage.id)} className="cursor-pointer">
              {/* Connection line */}
              <line
                x1={centerX}
                y1={centerY}
                x2={x}
                y2={y}
                stroke={isPast ? 'rgb(6, 182, 212)' : 'rgb(63, 63, 70)'}
                strokeWidth="1"
                strokeOpacity={isPast ? 0.5 : 0.2}
              />
              
              {/* Stage circle */}
              <circle
                cx={x}
                cy={y}
                r={isCurrent ? 20 : 16}
                fill={isCurrent ? 'rgb(168, 85, 247)' : isPast ? 'rgb(6, 182, 212)' : 'rgb(39, 39, 42)'}
                stroke={hasEntries ? 'rgb(245, 158, 11)' : 'rgb(63, 63, 70)'}
                strokeWidth={hasEntries ? 3 : 1}
                className={isCurrent ? 'animate-pulse' : ''}
              />
              
              {/* Stage number */}
              <text
                x={x}
                y={y}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="white"
                fontSize="12"
                fontWeight="bold"
              >
                {stage.id}
              </text>
            </g>
          )
        })}
        
        {/* Gradient definition */}
        <defs>
          <radialGradient id="journeyGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgb(168, 85, 247)" />
            <stop offset="100%" stopColor="rgb(6, 182, 212)" />
          </radialGradient>
        </defs>
        
        {/* Center text */}
        <text
          x={centerX}
          y={centerY - 10}
          textAnchor="middle"
          fill="rgb(161, 161, 170)"
          fontSize="12"
        >
          Stage {currentStage}
        </text>
        <text
          x={centerX}
          y={centerY + 10}
          textAnchor="middle"
          fill="white"
          fontSize="14"
          fontWeight="bold"
        >
          {JOURNEY_STAGES[currentStage - 1]?.name.split(' ').slice(1).join(' ')}
        </text>
      </svg>
    </div>
  )
}

// ============================================================================
// STAGE DETAIL
// ============================================================================

function StageDetail({ 
  stage, 
  entries,
  onAddEntry,
  onClose
}: { 
  stage: JourneyStage
  entries: JourneyEntry[]
  onAddEntry: (entry: Omit<JourneyEntry, 'id' | 'timestamp'>) => void
  onClose: () => void
}) {
  const [showForm, setShowForm] = useState(false)
  const [narrative, setNarrative] = useState('')
  const [title, setTitle] = useState('')
  const [lessons, setLessons] = useState('')
  
  const stageEntries = entries.filter(e => e.stageId === stage.id)
  
  const handleSubmit = () => {
    if (!narrative.trim()) return
    
    onAddEntry({
      stageId: stage.id,
      title: title || `${stage.name} Entry`,
      narrative,
      mentors: [],
      allies: [],
      lessons: lessons.split('\n').filter(l => l.trim()),
      symbols: []
    })
    
    setShowForm(false)
    setNarrative('')
    setTitle('')
    setLessons('')
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl font-bold text-purple-400">{stage.id}</span>
            <h3 className="text-xl font-medium text-zinc-200">{stage.name}</h3>
          </div>
          <p className="text-sm text-cyan-400">{stage.archetype}</p>
        </div>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      <p className="text-zinc-400 mb-6">{stage.description}</p>
      
      {/* Questions */}
      <div className="mb-6 p-4 bg-purple-500/10 rounded-lg">
        <p className="text-sm text-purple-400 mb-2">Questions for this stage:</p>
        <ul className="space-y-1">
          {stage.questions.map((q, i) => (
            <li key={i} className="text-sm text-zinc-300">• {q}</li>
          ))}
        </ul>
      </div>
      
      {/* Gifts & Shadows */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-3 bg-emerald-500/10 rounded-lg">
          <p className="text-xs text-emerald-400 mb-2">Gifts</p>
          <div className="flex flex-wrap gap-1">
            {stage.gifts.map((g, i) => (
              <span key={i} className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-xs">{g}</span>
            ))}
          </div>
        </div>
        <div className="p-3 bg-red-500/10 rounded-lg">
          <p className="text-xs text-red-400 mb-2">Shadows</p>
          <div className="flex flex-wrap gap-1">
            {stage.shadows.map((s, i) => (
              <span key={i} className="px-2 py-0.5 bg-red-500/20 text-red-300 rounded text-xs">{s}</span>
            ))}
          </div>
        </div>
      </div>
      
      {/* Threshold */}
      <div className="mb-6 p-3 bg-amber-500/10 rounded-lg">
        <p className="text-xs text-amber-400 mb-1">Threshold to cross:</p>
        <p className="text-sm text-zinc-200">{stage.threshold}</p>
      </div>
      
      {/* Entry Form */}
      {showForm ? (
        <div className="space-y-4 mb-6">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Entry title..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
          <textarea
            value={narrative}
            onChange={(e) => setNarrative(e.target.value)}
            placeholder="Describe your experience in this stage..."
            rows={4}
            className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
          <textarea
            value={lessons}
            onChange={(e) => setLessons(e.target.value)}
            placeholder="Lessons learned (one per line)..."
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
          <div className="flex gap-2">
            <button onClick={() => setShowForm(false)} className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded-lg">
              Cancel
            </button>
            <button onClick={handleSubmit} className="flex-1 py-2 bg-purple-500 text-white rounded-lg">
              Save Entry
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className="w-full py-3 mb-6 cascade-card text-center text-zinc-400 hover:text-purple-400"
        >
          + Add Entry for This Stage
        </button>
      )}
      
      {/* Stage Entries */}
      {stageEntries.length > 0 && (
        <div>
          <p className="text-sm text-zinc-400 mb-2">Your journey at this stage:</p>
          <div className="space-y-2">
            {stageEntries.map(entry => (
              <div key={entry.id} className="p-3 bg-zinc-800/50 rounded-lg">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>{entry.title}</span>
                  <span>{new Date(entry.timestamp).toLocaleDateString()}</span>
                </div>
                <p className="text-sm text-zinc-300 line-clamp-2">{entry.narrative}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function ArchetypalJourneyPage() {
  const [journeys, setJourneys] = useState<ActiveJourney[]>([])
  const [activeJourney, setActiveJourney] = useState<ActiveJourney | null>(null)
  const [selectedStage, setSelectedStage] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [newJourneyName, setNewJourneyName] = useState('')
  const [newJourneyIntention, setNewJourneyIntention] = useState('')
  
  // Load journeys
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-journeys')
      if (saved) {
        const parsed = JSON.parse(saved)
        setJourneys(parsed)
        if (parsed.length > 0 && !parsed[0].completedAt) {
          setActiveJourney(parsed[0])
        }
      }
    }
  }, [])
  
  const createJourney = () => {
    if (!newJourneyName.trim()) return
    
    const newJourney: ActiveJourney = {
      id: `journey-${Date.now()}`,
      name: newJourneyName,
      intention: newJourneyIntention,
      currentStage: 1,
      entries: [],
      startedAt: Date.now()
    }
    
    const updated = [newJourney, ...journeys]
    setJourneys(updated)
    setActiveJourney(newJourney)
    localStorage.setItem('cascade-journeys', JSON.stringify(updated))
    setShowCreate(false)
    setNewJourneyName('')
    setNewJourneyIntention('')
  }
  
  const addEntry = (entry: Omit<JourneyEntry, 'id' | 'timestamp'>) => {
    if (!activeJourney) return
    
    const newEntry: JourneyEntry = {
      ...entry,
      id: `entry-${Date.now()}`,
      timestamp: Date.now()
    }
    
    const updatedJourney = {
      ...activeJourney,
      entries: [...activeJourney.entries, newEntry]
    }
    
    const updatedJourneys = journeys.map(j => 
      j.id === activeJourney.id ? updatedJourney : j
    )
    
    setActiveJourney(updatedJourney)
    setJourneys(updatedJourneys)
    localStorage.setItem('cascade-journeys', JSON.stringify(updatedJourneys))
  }
  
  const advanceStage = () => {
    if (!activeJourney || activeJourney.currentStage >= 12) return
    
    const updatedJourney = {
      ...activeJourney,
      currentStage: activeJourney.currentStage + 1,
      completedAt: activeJourney.currentStage === 11 ? Date.now() : undefined
    }
    
    const updatedJourneys = journeys.map(j => 
      j.id === activeJourney.id ? updatedJourney : j
    )
    
    setActiveJourney(updatedJourney)
    setJourneys(updatedJourneys)
    localStorage.setItem('cascade-journeys', JSON.stringify(updatedJourneys))
  }
  
  const currentStageData = activeJourney 
    ? JOURNEY_STAGES[activeJourney.currentStage - 1] 
    : null
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Archetypal Journey</h1>
        <p className="text-zinc-500">Track your hero's journey through 12 stages</p>
      </header>
      
      {!activeJourney && !showCreate ? (
        <div className="cascade-card p-12 text-center">
          <p className="text-4xl mb-4">🗺️</p>
          <p className="text-zinc-400 mb-4">No active journey</p>
          <button
            onClick={() => setShowCreate(true)}
            className="px-6 py-3 bg-gradient-to-r from-purple-500 to-cyan-500 text-zinc-900 font-medium rounded-lg"
          >
            Begin Your Journey
          </button>
        </div>
      ) : showCreate ? (
        <div className="cascade-card p-6 max-w-lg mx-auto">
          <h2 className="text-xl font-bold text-zinc-100 mb-6">Begin a New Journey</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-400 mb-2">Journey Name</label>
              <input
                type="text"
                value={newJourneyName}
                onChange={(e) => setNewJourneyName(e.target.value)}
                placeholder="e.g., Career Transformation, Healing Journey..."
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-400 mb-2">Intention</label>
              <textarea
                value={newJourneyIntention}
                onChange={(e) => setNewJourneyIntention(e.target.value)}
                placeholder="What is this journey about? What do you seek?"
                rows={3}
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
              />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowCreate(false)} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
                Cancel
              </button>
              <button onClick={createJourney} className="flex-1 py-3 bg-purple-500 text-white rounded-lg">
                Begin Journey
              </button>
            </div>
          </div>
        </div>
      ) : activeJourney && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Journey Circle */}
          <div className="cascade-card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-medium text-zinc-200">{activeJourney.name}</h3>
                <p className="text-sm text-zinc-500">Started {new Date(activeJourney.startedAt).toLocaleDateString()}</p>
              </div>
              {activeJourney.currentStage < 12 && (
                <button
                  onClick={advanceStage}
                  className="px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg text-sm"
                >
                  Advance Stage →
                </button>
              )}
            </div>
            
            <JourneyCircle
              currentStage={activeJourney.currentStage}
              entries={activeJourney.entries}
              onStageClick={setSelectedStage}
            />
            
            {activeJourney.intention && (
              <div className="mt-4 p-3 bg-zinc-800/50 rounded-lg">
                <p className="text-xs text-zinc-500 mb-1">Intention:</p>
                <p className="text-sm text-zinc-300 italic">"{activeJourney.intention}"</p>
              </div>
            )}
          </div>
          
          {/* Stage Detail or Current Stage */}
          {selectedStage ? (
            <StageDetail
              stage={JOURNEY_STAGES[selectedStage - 1]}
              entries={activeJourney.entries}
              onAddEntry={addEntry}
              onClose={() => setSelectedStage(null)}
            />
          ) : currentStageData && (
            <StageDetail
              stage={currentStageData}
              entries={activeJourney.entries}
              onAddEntry={addEntry}
              onClose={() => {}}
            />
          )}
        </div>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-purple-500/5 to-cyan-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🗺️ The Hero's Journey</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "A hero is someone who has given his or her life to something bigger than oneself." — Joseph Campbell
        </p>
        <p className="text-sm text-zinc-500">
          Every transformation follows the same archetypal pattern. By mapping your journey to these 
          stages, you gain perspective on where you are, what's being asked of you, and what gifts 
          await. You are always the hero of your own story.
        </p>
      </div>
    </div>
  )
}
