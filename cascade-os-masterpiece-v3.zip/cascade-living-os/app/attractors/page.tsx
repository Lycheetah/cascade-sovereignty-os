'use client'

import { useState, useEffect, useMemo } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface AttractorState {
  id: string
  name: string
  description: string
  domain: AttractorDomain
  
  // The vision
  vividDescription: string  // Present tense, as if already there
  sensoryDetails: string[]  // What you see, hear, feel
  emotionalSignature: string[] // Emotions in that state
  
  // Measurement
  indicators: AttractorIndicator[]
  currentConvergence: number  // 0-100
  
  // Dynamics
  pullStrength: number       // 1-10 how strong the attraction
  resistances: string[]      // What's pulling away
  enablers: string[]         // What's pulling toward
  
  // Tracking
  convergenceHistory: { value: number; timestamp: number }[]
  lastUpdated: number
  createdAt: number
  
  // Status
  status: 'distant' | 'approaching' | 'near' | 'arrived'
  lamague: string  // LAMAGUE symbol
}

interface AttractorIndicator {
  name: string
  current: number     // 0-10
  target: number      // 0-10
  weight: number      // How important (1-5)
}

type AttractorDomain = 
  | 'self'           // Personal state of being
  | 'relationship'   // Relational attractor
  | 'creative'       // Creative/expressive state
  | 'professional'   // Career/work attractor
  | 'financial'      // Abundance state
  | 'health'         // Physical/mental wellbeing
  | 'spiritual'      // Spiritual development
  | 'lifestyle'      // Way of living
  | 'impact'         // Contribution/legacy

// ============================================================================
// CONSTANTS
// ============================================================================

const DOMAIN_INFO: Record<AttractorDomain, { label: string; icon: string; color: string }> = {
  self: { label: 'Self', icon: '🌟', color: 'amber' },
  relationship: { label: 'Relationship', icon: '💗', color: 'pink' },
  creative: { label: 'Creative', icon: '🎨', color: 'purple' },
  professional: { label: 'Professional', icon: '💼', color: 'cyan' },
  financial: { label: 'Financial', icon: '💰', color: 'emerald' },
  health: { label: 'Health', icon: '🌿', color: 'green' },
  spiritual: { label: 'Spiritual', icon: '✨', color: 'indigo' },
  lifestyle: { label: 'Lifestyle', icon: '🏡', color: 'orange' },
  impact: { label: 'Impact', icon: '🌍', color: 'blue' }
}

const STATUS_INFO = {
  distant: { label: 'Distant', color: 'zinc', min: 0, max: 25 },
  approaching: { label: 'Approaching', color: 'amber', min: 25, max: 50 },
  near: { label: 'Near', color: 'cyan', min: 50, max: 80 },
  arrived: { label: 'Arrived', color: 'emerald', min: 80, max: 100 }
}

const LAMAGUE_OPTIONS = ['⟟', '≋', 'Ψ', 'Φ↑', '✧', '∥◁▷∥', '⟲', '∞', '◆']

// ============================================================================
// CONVERGENCE VISUALIZATION
// ============================================================================

function ConvergenceVisual({ 
  attractor 
}: { 
  attractor: AttractorState 
}) {
  const domain = DOMAIN_INFO[attractor.domain]
  
  return (
    <div className="relative h-32 w-full overflow-hidden rounded-lg bg-zinc-900/50">
      {/* Background gradient toward attractor */}
      <div 
        className={`absolute inset-0 bg-gradient-to-r from-zinc-900 via-${domain.color}-500/10 to-${domain.color}-500/30`}
        style={{ 
          backgroundSize: `${100 + attractor.pullStrength * 10}% 100%`,
          animation: 'pulse 3s ease-in-out infinite'
        }}
      />
      
      {/* Current position marker */}
      <div 
        className="absolute top-1/2 -translate-y-1/2 transition-all duration-1000"
        style={{ left: `${attractor.currentConvergence}%` }}
      >
        <div className={`w-4 h-4 rounded-full bg-${domain.color}-400 shadow-lg shadow-${domain.color}-500/50`} />
        <div className={`absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs text-${domain.color}-400 font-bold whitespace-nowrap`}>
          {attractor.currentConvergence}%
        </div>
      </div>
      
      {/* Attractor point */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2">
        <div className={`text-3xl animate-pulse`}>{domain.icon}</div>
      </div>
      
      {/* LAMAGUE symbol */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl text-zinc-600">
        {attractor.lamague}
      </div>
    </div>
  )
}

// ============================================================================
// ATTRACTOR CARD
// ============================================================================

function AttractorCard({ 
  attractor, 
  onSelect,
  onUpdateConvergence
}: { 
  attractor: AttractorState
  onSelect: () => void
  onUpdateConvergence: (value: number) => void
}) {
  const domain = DOMAIN_INFO[attractor.domain]
  const status = STATUS_INFO[attractor.status]
  
  // Calculate weighted convergence
  const weightedConvergence = useMemo(() => {
    if (attractor.indicators.length === 0) return attractor.currentConvergence
    
    const totalWeight = attractor.indicators.reduce((sum, i) => sum + i.weight, 0)
    const weightedSum = attractor.indicators.reduce((sum, i) => {
      const progress = (i.current / i.target) * 100
      return sum + (progress * i.weight)
    }, 0)
    
    return Math.round(weightedSum / totalWeight)
  }, [attractor.indicators, attractor.currentConvergence])
  
  return (
    <div className={`cascade-card p-5 hover:border-${domain.color}-500/30 transition-all`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{domain.icon}</span>
          <div>
            <h3 className="font-medium text-zinc-200">{attractor.name}</h3>
            <p className="text-xs text-zinc-500">{domain.label}</p>
          </div>
        </div>
        <span className={`px-2 py-1 rounded-full text-xs bg-${status.color}-500/20 text-${status.color}-400`}>
          {status.label}
        </span>
      </div>
      
      <p className="text-sm text-zinc-400 line-clamp-2 mb-4">{attractor.description}</p>
      
      {/* Convergence visual */}
      <ConvergenceVisual attractor={attractor} />
      
      {/* Indicators preview */}
      {attractor.indicators.length > 0 && (
        <div className="mt-4 space-y-2">
          {attractor.indicators.slice(0, 3).map((indicator, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="text-xs text-zinc-500 w-24 truncate">{indicator.name}</span>
              <div className="flex-1 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-${domain.color}-500`}
                  style={{ width: `${(indicator.current / indicator.target) * 100}%` }}
                />
              </div>
              <span className="text-xs text-zinc-400">{indicator.current}/{indicator.target}</span>
            </div>
          ))}
        </div>
      )}
      
      {/* Pull strength */}
      <div className="mt-4 flex items-center justify-between">
        <div className="flex items-center gap-1">
          <span className="text-xs text-zinc-500">Pull:</span>
          {Array.from({ length: attractor.pullStrength }).map((_, i) => (
            <span key={i} className={`text-${domain.color}-400 text-xs`}>→</span>
          ))}
        </div>
        <button
          onClick={onSelect}
          className={`px-3 py-1 bg-${domain.color}-500/20 text-${domain.color}-400 rounded text-sm hover:bg-${domain.color}-500/30`}
        >
          Details
        </button>
      </div>
    </div>
  )
}

// ============================================================================
// CREATE ATTRACTOR FORM
// ============================================================================

function CreateAttractorForm({
  onSave,
  onCancel
}: {
  onSave: (attractor: Omit<AttractorState, 'id' | 'createdAt' | 'lastUpdated' | 'convergenceHistory' | 'status'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [domain, setDomain] = useState<AttractorDomain>('self')
  const [vividDescription, setVividDescription] = useState('')
  const [sensoryDetails, setSensoryDetails] = useState('')
  const [emotionalSignature, setEmotionalSignature] = useState('')
  const [pullStrength, setPullStrength] = useState(7)
  const [resistances, setResistances] = useState('')
  const [enablers, setEnablers] = useState('')
  const [currentConvergence, setCurrentConvergence] = useState(20)
  const [lamague, setLamague] = useState('Φ↑')
  const [indicators, setIndicators] = useState<AttractorIndicator[]>([])
  const [newIndicator, setNewIndicator] = useState({ name: '', target: 10 })
  
  const addIndicator = () => {
    if (!newIndicator.name.trim()) return
    setIndicators([...indicators, { 
      name: newIndicator.name, 
      current: 0, 
      target: newIndicator.target,
      weight: 3
    }])
    setNewIndicator({ name: '', target: 10 })
  }
  
  const handleSubmit = () => {
    if (!name.trim() || !vividDescription.trim()) return
    
    onSave({
      name,
      description,
      domain,
      vividDescription,
      sensoryDetails: sensoryDetails.split('\n').filter(s => s.trim()),
      emotionalSignature: emotionalSignature.split(',').map(e => e.trim()).filter(Boolean),
      indicators,
      currentConvergence,
      pullStrength,
      resistances: resistances.split('\n').filter(r => r.trim()),
      enablers: enablers.split('\n').filter(e => e.trim()),
      lamague
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Define Attractor State</h2>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Sovereign Creative"
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">LAMAGUE Symbol</label>
            <div className="flex gap-2">
              {LAMAGUE_OPTIONS.map(s => (
                <button
                  key={s}
                  onClick={() => setLamague(s)}
                  className={`px-3 py-2 rounded text-lg ${
                    lamague === s ? 'bg-purple-500/20 border border-purple-500/50' : 'bg-zinc-800'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Domain</label>
          <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
            {(Object.entries(DOMAIN_INFO) as [AttractorDomain, typeof DOMAIN_INFO[AttractorDomain]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setDomain(key)}
                className={`p-2 rounded-lg text-xs ${
                  domain === key
                    ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                    : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
              >
                <span className="text-lg block">{info.icon}</span>
                <span className="text-zinc-400">{info.label}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Brief Description</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="One-line summary of this attractor state"
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Vivid Description (write as if already there)</label>
          <textarea
            value={vividDescription}
            onChange={(e) => setVividDescription(e.target.value)}
            placeholder="I am... I have... I feel... (present tense, detailed)"
            rows={3}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Sensory Details (one per line)</label>
            <textarea
              value={sensoryDetails}
              onChange={(e) => setSensoryDetails(e.target.value)}
              placeholder="What do you see, hear, feel in this state?"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Emotional Signature (comma separated)</label>
            <textarea
              value={emotionalSignature}
              onChange={(e) => setEmotionalSignature(e.target.value)}
              placeholder="peace, joy, confidence, excitement..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Pull Strength (1-10)</label>
          <input
            type="range"
            min="1"
            max="10"
            value={pullStrength}
            onChange={(e) => setPullStrength(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-zinc-600">
            <span>Gentle pull</span>
            <span className="text-cyan-400 font-bold">{pullStrength}</span>
            <span>Magnetic force</span>
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Current Convergence (%)</label>
          <input
            type="range"
            min="0"
            max="100"
            value={currentConvergence}
            onChange={(e) => setCurrentConvergence(parseInt(e.target.value))}
            className="w-full"
          />
          <p className="text-center text-cyan-400 font-bold">{currentConvergence}%</p>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Resistances (one per line)</label>
            <textarea
              value={resistances}
              onChange={(e) => setResistances(e.target.value)}
              placeholder="What pulls you away from this state?"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Enablers (one per line)</label>
            <textarea
              value={enablers}
              onChange={(e) => setEnablers(e.target.value)}
              placeholder="What pulls you toward this state?"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        {/* Indicators */}
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Measurable Indicators</label>
          <div className="space-y-2 mb-2">
            {indicators.map((ind, i) => (
              <div key={i} className="flex items-center gap-2 p-2 bg-zinc-800/50 rounded">
                <span className="text-sm text-zinc-300">{ind.name}</span>
                <span className="text-xs text-zinc-500 ml-auto">Target: {ind.target}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={newIndicator.name}
              onChange={(e) => setNewIndicator({ ...newIndicator, name: e.target.value })}
              placeholder="Indicator name..."
              className="flex-1 px-3 py-2 bg-zinc-800 border border-zinc-700 rounded text-sm text-zinc-200"
            />
            <input
              type="number"
              value={newIndicator.target}
              onChange={(e) => setNewIndicator({ ...newIndicator, target: parseInt(e.target.value) || 10 })}
              className="w-20 px-3 py-2 bg-zinc-800 border border-zinc-700 rounded text-sm text-zinc-200"
            />
            <button onClick={addIndicator} className="px-3 py-2 bg-cyan-500/20 text-cyan-400 rounded">
              Add
            </button>
          </div>
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!name.trim() || !vividDescription.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-zinc-900 font-medium rounded-lg disabled:opacity-50"
          >
            Create Attractor
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function AttractorsPage() {
  const [attractors, setAttractors] = useState<AttractorState[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedAttractor, setSelectedAttractor] = useState<AttractorState | null>(null)
  
  // Load attractors
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-attractors')
      if (saved) setAttractors(JSON.parse(saved))
    }
  }, [])
  
  const saveAttractor = (attractor: Omit<AttractorState, 'id' | 'createdAt' | 'lastUpdated' | 'convergenceHistory' | 'status'>) => {
    const status = attractor.currentConvergence >= 80 ? 'arrived' :
                   attractor.currentConvergence >= 50 ? 'near' :
                   attractor.currentConvergence >= 25 ? 'approaching' : 'distant'
    
    const newAttractor: AttractorState = {
      ...attractor,
      id: `attractor-${Date.now()}`,
      status,
      convergenceHistory: [{ value: attractor.currentConvergence, timestamp: Date.now() }],
      createdAt: Date.now(),
      lastUpdated: Date.now()
    }
    
    const updated = [newAttractor, ...attractors]
    setAttractors(updated)
    localStorage.setItem('cascade-attractors', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const updateConvergence = (id: string, value: number) => {
    const status = value >= 80 ? 'arrived' :
                   value >= 50 ? 'near' :
                   value >= 25 ? 'approaching' : 'distant'
    
    const updated = attractors.map(a => {
      if (a.id === id) {
        return {
          ...a,
          currentConvergence: value,
          status: status as AttractorState['status'],
          convergenceHistory: [...a.convergenceHistory, { value, timestamp: Date.now() }],
          lastUpdated: Date.now()
        }
      }
      return a
    })
    setAttractors(updated)
    localStorage.setItem('cascade-attractors', JSON.stringify(updated))
  }
  
  // Stats
  const avgConvergence = attractors.length > 0
    ? Math.round(attractors.reduce((sum, a) => sum + a.currentConvergence, 0) / attractors.length)
    : 0
  const arrivedCount = attractors.filter(a => a.status === 'arrived').length
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Attractor States</h1>
        <p className="text-zinc-500">Define and converge toward ideal future states</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{attractors.length}</p>
          <p className="text-xs text-zinc-500">Attractors</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{avgConvergence}%</p>
          <p className="text-xs text-zinc-500">Avg Convergence</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{arrivedCount}</p>
          <p className="text-xs text-zinc-500">Arrived</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">
            {attractors.reduce((sum, a) => sum + a.pullStrength, 0)}
          </p>
          <p className="text-xs text-zinc-500">Total Pull</p>
        </div>
      </div>
      
      {showCreate ? (
        <CreateAttractorForm onSave={saveAttractor} onCancel={() => setShowCreate(false)} />
      ) : (
        <>
          <button
            onClick={() => setShowCreate(true)}
            className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/30 transition-all"
          >
            + Define Attractor State
          </button>
          
          {attractors.length === 0 ? (
            <div className="cascade-card p-12 text-center">
              <p className="text-4xl mb-4">🎯</p>
              <p className="text-zinc-400">No attractor states defined yet</p>
              <p className="text-sm text-zinc-600">Create your first magnetic future</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {attractors.map(attractor => (
                <AttractorCard
                  key={attractor.id}
                  attractor={attractor}
                  onSelect={() => setSelectedAttractor(attractor)}
                  onUpdateConvergence={(value) => updateConvergence(attractor.id, value)}
                />
              ))}
            </div>
          )}
        </>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🎯 On Attractor States</h3>
        <p className="text-sm text-zinc-400 mb-3">
          In dynamical systems theory, an attractor is a state toward which a system naturally 
          evolves. Your future self exists as an attractor in possibility space.
        </p>
        <p className="text-sm text-zinc-500">
          By vividly defining the state you're converging toward — with sensory details, 
          emotional signatures, and measurable indicators — you increase its gravitational 
          pull on your present actions. The clearer the attractor, the stronger the pull. 
          You don't create the future; you're drawn toward it.
        </p>
      </div>
    </div>
  )
}
