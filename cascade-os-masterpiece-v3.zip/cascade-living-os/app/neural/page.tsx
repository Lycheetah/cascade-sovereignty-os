'use client'

import { useState, useEffect, useMemo } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface NeuralPathway {
  id: string
  name: string
  type: 'build' | 'break'  // Building new habit or breaking old one
  cue: string              // What triggers the behavior
  routine: string          // The behavior itself
  reward: string           // The reward/outcome
  replacement?: string     // For 'break' type - what replaces it
  strength: number         // 0-100 how established
  targetStrength: number   // Goal strength
  repetitions: number      // Total times performed
  streak: number           // Current consecutive days
  longestStreak: number
  history: PathwayEvent[]
  difficulty: 1 | 2 | 3 | 4 | 5
  identity: string         // "I am a person who..."
  createdAt: number
}

interface PathwayEvent {
  id: string
  type: 'completed' | 'missed' | 'resisted' | 'urge'
  notes?: string
  context?: string
  timestamp: number
}

interface PathwayStats {
  totalPathways: number
  avgStrength: number
  totalRepetitions: number
  activeStreaks: number
}

// ============================================================================
// CONSTANTS
// ============================================================================

const PATHWAY_TEMPLATES = [
  { name: 'Morning Meditation', cue: 'Wake up', routine: '10 min meditation', reward: 'Calm clarity', identity: 'I am a person who starts days mindfully' },
  { name: 'Exercise Habit', cue: 'After work', routine: '30 min exercise', reward: 'Energy and strength', identity: 'I am an active, healthy person' },
  { name: 'Reading Habit', cue: 'Before bed', routine: 'Read for 20 minutes', reward: 'Knowledge and relaxation', identity: 'I am a lifelong learner' },
  { name: 'Gratitude Practice', cue: 'Morning coffee', routine: 'Write 3 gratitudes', reward: 'Positive mindset', identity: 'I am a grateful person' },
  { name: 'Digital Detox', cue: 'Phone urge', routine: 'Put phone down', reward: 'Presence and peace', identity: 'I am present and intentional', type: 'break' as const }
]

const STRENGTH_LABELS = [
  { min: 0, max: 20, label: 'Nascent', color: 'zinc', description: 'Just beginning to form' },
  { min: 21, max: 40, label: 'Developing', color: 'blue', description: 'Requires conscious effort' },
  { min: 41, max: 60, label: 'Establishing', color: 'cyan', description: 'Becoming more automatic' },
  { min: 61, max: 80, label: 'Strong', color: 'emerald', description: 'Well-established pathway' },
  { min: 81, max: 100, label: 'Automatic', color: 'purple', description: 'Deeply wired, effortless' }
]

// ============================================================================
// PATHWAY VISUALIZATION
// ============================================================================

function PathwayVisualization({ pathway }: { pathway: NeuralPathway }) {
  const strengthLabel = STRENGTH_LABELS.find(l => pathway.strength >= l.min && pathway.strength <= l.max)!
  
  // Generate "neural" lines based on strength
  const lines = useMemo(() => {
    const count = Math.ceil(pathway.strength / 10)
    return Array.from({ length: count }).map((_, i) => ({
      offset: (i / count) * 100,
      opacity: 0.2 + (pathway.strength / 100) * 0.8
    }))
  }, [pathway.strength])
  
  return (
    <div className="relative h-24 overflow-hidden rounded-lg bg-zinc-900">
      {/* Neural pathway lines */}
      <svg className="absolute inset-0 w-full h-full">
        {lines.map((line, i) => (
          <path
            key={i}
            d={`M 0 ${20 + line.offset * 0.6} Q 25 ${10 + i * 5}, 50 ${24 + line.offset * 0.5} T 100 ${20 + line.offset * 0.6}`}
            fill="none"
            stroke={`rgba(6, 182, 212, ${line.opacity})`}
            strokeWidth={1 + (pathway.strength / 50)}
            className="animate-pulse"
            style={{ animationDelay: `${i * 0.1}s` }}
          />
        ))}
        
        {/* Nodes */}
        <circle cx="0" cy="50%" r="8" fill="rgb(6, 182, 212)" fillOpacity="0.5" />
        <circle cx="50%" cy="50%" r="6" fill="rgb(168, 85, 247)" fillOpacity="0.5" />
        <circle cx="100%" cy="50%" r="8" fill="rgb(16, 185, 129)" fillOpacity="0.5" />
      </svg>
      
      {/* Labels */}
      <div className="absolute inset-0 flex items-center justify-between px-4">
        <div className="text-center">
          <p className="text-xs text-cyan-400 font-medium">CUE</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-purple-400 font-medium">ROUTINE</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-emerald-400 font-medium">REWARD</p>
        </div>
      </div>
      
      {/* Strength indicator */}
      <div className="absolute bottom-2 left-2 right-2 h-1 bg-zinc-800 rounded-full overflow-hidden">
        <div 
          className={`h-full bg-${strengthLabel.color}-500 transition-all duration-500`}
          style={{ width: `${pathway.strength}%` }}
        />
      </div>
    </div>
  )
}

// ============================================================================
// PATHWAY CARD
// ============================================================================

function PathwayCard({ 
  pathway, 
  onComplete,
  onResist,
  onSelect
}: { 
  pathway: NeuralPathway
  onComplete: () => void
  onResist: () => void
  onSelect: () => void
}) {
  const strengthLabel = STRENGTH_LABELS.find(l => pathway.strength >= l.min && pathway.strength <= l.max)!
  const todayCompleted = pathway.history.some(h => 
    h.type === 'completed' && 
    new Date(h.timestamp).toDateString() === new Date().toDateString()
  )
  
  return (
    <div className="cascade-card overflow-hidden">
      {/* Visualization */}
      <PathwayVisualization pathway={pathway} />
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-${pathway.type === 'build' ? 'emerald' : 'amber'}-400`}>
                {pathway.type === 'build' ? '➕' : '➖'}
              </span>
              <h3 className="font-medium text-zinc-200">{pathway.name}</h3>
            </div>
            <p className={`text-xs text-${strengthLabel.color}-400`}>
              {strengthLabel.label} • {pathway.strength}%
            </p>
          </div>
          <div className="text-right">
            <p className="text-lg font-bold text-amber-400">{pathway.streak}</p>
            <p className="text-xs text-zinc-500">day streak</p>
          </div>
        </div>
        
        {/* Habit Loop */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
          <div className="p-2 bg-cyan-500/10 rounded">
            <p className="text-cyan-400 font-medium">Cue</p>
            <p className="text-zinc-400 truncate">{pathway.cue}</p>
          </div>
          <div className="p-2 bg-purple-500/10 rounded">
            <p className="text-purple-400 font-medium">Routine</p>
            <p className="text-zinc-400 truncate">{pathway.routine}</p>
          </div>
          <div className="p-2 bg-emerald-500/10 rounded">
            <p className="text-emerald-400 font-medium">Reward</p>
            <p className="text-zinc-400 truncate">{pathway.reward}</p>
          </div>
        </div>
        
        {/* Identity */}
        <p className="text-xs text-zinc-500 italic mb-3">"{pathway.identity}"</p>
        
        {/* Actions */}
        <div className="flex gap-2">
          {pathway.type === 'build' ? (
            <button
              onClick={onComplete}
              disabled={todayCompleted}
              className={`flex-1 py-2 rounded-lg text-sm transition-all ${
                todayCompleted
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : 'bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30'
              }`}
            >
              {todayCompleted ? '✓ Done Today' : 'Complete'}
            </button>
          ) : (
            <button
              onClick={onResist}
              className="flex-1 py-2 bg-amber-500/20 text-amber-400 rounded-lg text-sm"
            >
              Resisted Urge
            </button>
          )}
          <button
            onClick={onSelect}
            className="px-4 py-2 bg-zinc-800 text-zinc-400 rounded-lg text-sm"
          >
            Details
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// CREATE PATHWAY FORM
// ============================================================================

function CreatePathwayForm({
  onSave,
  onCancel
}: {
  onSave: (pathway: Omit<NeuralPathway, 'id' | 'createdAt' | 'history' | 'strength' | 'repetitions' | 'streak' | 'longestStreak'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState('')
  const [type, setType] = useState<'build' | 'break'>('build')
  const [cue, setCue] = useState('')
  const [routine, setRoutine] = useState('')
  const [reward, setReward] = useState('')
  const [replacement, setReplacement] = useState('')
  const [identity, setIdentity] = useState('')
  const [difficulty, setDifficulty] = useState<1 | 2 | 3 | 4 | 5>(3)
  
  const applyTemplate = (template: typeof PATHWAY_TEMPLATES[0]) => {
    setName(template.name)
    setCue(template.cue)
    setRoutine(template.routine)
    setReward(template.reward)
    setIdentity(template.identity)
    if (template.type) setType(template.type)
  }
  
  const handleSubmit = () => {
    if (!name.trim() || !cue.trim() || !routine.trim()) return
    
    onSave({
      name,
      type,
      cue,
      routine,
      reward,
      replacement: type === 'break' ? replacement : undefined,
      targetStrength: 80,
      difficulty,
      identity: identity || `I am a person who ${routine.toLowerCase()}`
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Wire New Pathway</h2>
      
      {/* Templates */}
      <div className="mb-6">
        <p className="text-sm text-zinc-400 mb-2">Quick Templates</p>
        <div className="flex flex-wrap gap-2">
          {PATHWAY_TEMPLATES.map(t => (
            <button
              key={t.name}
              onClick={() => applyTemplate(t)}
              className="px-3 py-1.5 bg-zinc-800 text-zinc-400 rounded text-sm hover:bg-zinc-700"
            >
              {t.name}
            </button>
          ))}
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex gap-4">
          <button
            onClick={() => setType('build')}
            className={`flex-1 p-3 rounded-lg transition-all ${
              type === 'build'
                ? 'bg-emerald-500/20 border border-emerald-500/50 text-emerald-400'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            ➕ Build New Habit
          </button>
          <button
            onClick={() => setType('break')}
            className={`flex-1 p-3 rounded-lg transition-all ${
              type === 'break'
                ? 'bg-amber-500/20 border border-amber-500/50 text-amber-400'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            ➖ Break Old Habit
          </button>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Habit Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Morning Meditation, Quit Social Media..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm text-cyan-400 mb-2">Cue (Trigger)</label>
            <input
              type="text"
              value={cue}
              onChange={(e) => setCue(e.target.value)}
              placeholder="What triggers it?"
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-purple-400 mb-2">Routine (Behavior)</label>
            <input
              type="text"
              value={routine}
              onChange={(e) => setRoutine(e.target.value)}
              placeholder="What's the behavior?"
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-emerald-400 mb-2">Reward (Outcome)</label>
            <input
              type="text"
              value={reward}
              onChange={(e) => setReward(e.target.value)}
              placeholder="What's the reward?"
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
        </div>
        
        {type === 'break' && (
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Replacement Behavior</label>
            <input
              type="text"
              value={replacement}
              onChange={(e) => setReplacement(e.target.value)}
              placeholder="What will you do instead?"
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
        )}
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Identity Statement</label>
          <input
            type="text"
            value={identity}
            onChange={(e) => setIdentity(e.target.value)}
            placeholder="I am a person who..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Difficulty (1-5)</label>
          <div className="flex gap-2">
            {([1, 2, 3, 4, 5] as const).map(d => (
              <button
                key={d}
                onClick={() => setDifficulty(d)}
                className={`flex-1 py-2 rounded-lg transition-all ${
                  difficulty === d
                    ? 'bg-purple-500/30 text-purple-400'
                    : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                {'⚡'.repeat(d)}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!name.trim() || !cue.trim() || !routine.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-zinc-900 font-medium rounded-lg disabled:opacity-50"
          >
            Create Pathway
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function NeuralPathwayPage() {
  const [pathways, setPathways] = useState<NeuralPathway[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedPathway, setSelectedPathway] = useState<NeuralPathway | null>(null)
  
  // Load pathways
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-neural-pathways')
      if (saved) setPathways(JSON.parse(saved))
    }
  }, [])
  
  const savePathway = (pathway: Omit<NeuralPathway, 'id' | 'createdAt' | 'history' | 'strength' | 'repetitions' | 'streak' | 'longestStreak'>) => {
    const newPathway: NeuralPathway = {
      ...pathway,
      id: `pathway-${Date.now()}`,
      strength: 5,
      repetitions: 0,
      streak: 0,
      longestStreak: 0,
      history: [],
      createdAt: Date.now()
    }
    
    const updated = [newPathway, ...pathways]
    setPathways(updated)
    localStorage.setItem('cascade-neural-pathways', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const completePathway = (pathwayId: string) => {
    const updated = pathways.map(p => {
      if (p.id !== pathwayId) return p
      
      const newEvent: PathwayEvent = {
        id: `event-${Date.now()}`,
        type: 'completed',
        timestamp: Date.now()
      }
      
      // Check if yesterday was completed for streak
      const yesterday = new Date()
      yesterday.setDate(yesterday.getDate() - 1)
      const yesterdayCompleted = p.history.some(h => 
        h.type === 'completed' && 
        new Date(h.timestamp).toDateString() === yesterday.toDateString()
      )
      
      const newStreak = yesterdayCompleted ? p.streak + 1 : 1
      
      // Calculate strength increase
      const baseIncrease = 2
      const streakBonus = Math.min(newStreak * 0.2, 2)
      const difficultyBonus = p.difficulty * 0.3
      const strengthIncrease = baseIncrease + streakBonus + difficultyBonus
      
      return {
        ...p,
        history: [...p.history, newEvent],
        repetitions: p.repetitions + 1,
        streak: newStreak,
        longestStreak: Math.max(p.longestStreak, newStreak),
        strength: Math.min(100, p.strength + strengthIncrease)
      }
    })
    
    setPathways(updated)
    localStorage.setItem('cascade-neural-pathways', JSON.stringify(updated))
  }
  
  const resistPathway = (pathwayId: string) => {
    const updated = pathways.map(p => {
      if (p.id !== pathwayId) return p
      
      const newEvent: PathwayEvent = {
        id: `event-${Date.now()}`,
        type: 'resisted',
        timestamp: Date.now()
      }
      
      return {
        ...p,
        history: [...p.history, newEvent],
        repetitions: p.repetitions + 1,
        strength: Math.max(0, p.strength - 1.5)  // Weakening old pathway
      }
    })
    
    setPathways(updated)
    localStorage.setItem('cascade-neural-pathways', JSON.stringify(updated))
  }
  
  // Stats
  const stats: PathwayStats = {
    totalPathways: pathways.length,
    avgStrength: pathways.length > 0 
      ? Math.round(pathways.reduce((sum, p) => sum + p.strength, 0) / pathways.length)
      : 0,
    totalRepetitions: pathways.reduce((sum, p) => sum + p.repetitions, 0),
    activeStreaks: pathways.filter(p => p.streak > 0).length
  }
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Neural Pathway Mapper</h1>
        <p className="text-zinc-500">Wire your habits through neuroplasticity</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{stats.totalPathways}</p>
          <p className="text-xs text-zinc-500">Pathways</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{stats.avgStrength}%</p>
          <p className="text-xs text-zinc-500">Avg Strength</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{stats.totalRepetitions}</p>
          <p className="text-xs text-zinc-500">Total Reps</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{stats.activeStreaks}</p>
          <p className="text-xs text-zinc-500">Active Streaks</p>
        </div>
      </div>
      
      {showCreate ? (
        <CreatePathwayForm onSave={savePathway} onCancel={() => setShowCreate(false)} />
      ) : (
        <>
          <button
            onClick={() => setShowCreate(true)}
            className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/30 transition-all"
          >
            + Wire New Pathway
          </button>
          
          {pathways.length === 0 ? (
            <div className="cascade-card p-12 text-center">
              <p className="text-4xl mb-4">🧠</p>
              <p className="text-zinc-400">No pathways yet</p>
              <p className="text-sm text-zinc-600">Start wiring your neural networks</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {pathways.map(pathway => (
                <PathwayCard
                  key={pathway.id}
                  pathway={pathway}
                  onComplete={() => completePathway(pathway.id)}
                  onResist={() => resistPathway(pathway.id)}
                  onSelect={() => setSelectedPathway(pathway)}
                />
              ))}
            </div>
          )}
        </>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🧠 Neuroplasticity</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "Neurons that fire together, wire together." — Donald Hebb
        </p>
        <p className="text-sm text-zinc-500">
          Every behavior strengthens a neural pathway. Repeat a behavior enough times and it becomes 
          automatic — the pathway is wired. The habit loop (cue → routine → reward) is how the brain 
          encodes these patterns. To change behavior, don't fight the old pathway; build a stronger 
          new one that uses the same cue and delivers the same reward.
        </p>
      </div>
    </div>
  )
}
