'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface CoreBelief {
  id: string
  belief: string                    // The belief statement
  category: BeliefCategory
  layer: BeliefLayer               // How deep/foundational
  
  // Archaeology
  origin: string                   // Where/when this formed
  originAge?: string               // Age when formed
  sourceVoice?: string             // Whose voice said this first?
  
  // Evidence examination
  supportingEvidence: string[]     // Evidence FOR this belief
  contradictingEvidence: string[]  // Evidence AGAINST this belief
  
  // Analysis
  emotionalCharge: number          // 1-10 how emotionally loaded
  certainty: number                // 1-10 how certain you are it's true
  impact: BeliefImpact            // How it affects your life
  
  // Inquiry
  examinedDate?: number
  conclusions?: string
  alternativeBeliefs: string[]     // Alternative ways to see this
  
  // Status
  status: 'unexamined' | 'examining' | 'questioned' | 'retained' | 'released' | 'transformed'
  transformedInto?: string         // If transformed, what's the new belief?
  
  linkedBeliefs: string[]          // Related beliefs
  createdAt: number
}

type BeliefCategory = 
  | 'self'           // Beliefs about self
  | 'others'         // Beliefs about others
  | 'world'          // Beliefs about the world
  | 'relationships'  // Beliefs about relationships
  | 'money'          // Beliefs about money/abundance
  | 'success'        // Beliefs about success
  | 'safety'         // Beliefs about safety
  | 'worthiness'     // Beliefs about deserving
  | 'capability'     // Beliefs about what you can do
  | 'spiritual'      // Beliefs about meaning/spirit

type BeliefLayer = 
  | 'surface'        // Easily examined
  | 'intermediate'   // Takes work to see
  | 'core'           // Foundational, hard to access
  | 'bedrock'        // So fundamental you live in it

type BeliefImpact = 'empowering' | 'limiting' | 'neutral' | 'mixed'

// ============================================================================
// CONSTANTS
// ============================================================================

const CATEGORY_INFO: Record<BeliefCategory, { label: string; icon: string; color: string }> = {
  self: { label: 'Self', icon: '🪞', color: 'cyan' },
  others: { label: 'Others', icon: '👥', color: 'pink' },
  world: { label: 'World', icon: '🌍', color: 'blue' },
  relationships: { label: 'Relationships', icon: '💗', color: 'pink' },
  money: { label: 'Money', icon: '💰', color: 'emerald' },
  success: { label: 'Success', icon: '🏆', color: 'amber' },
  safety: { label: 'Safety', icon: '🛡️', color: 'purple' },
  worthiness: { label: 'Worthiness', icon: '✨', color: 'indigo' },
  capability: { label: 'Capability', icon: '💪', color: 'orange' },
  spiritual: { label: 'Spiritual', icon: '🕯️', color: 'violet' }
}

const LAYER_INFO: Record<BeliefLayer, { label: string; depth: number; color: string }> = {
  surface: { label: 'Surface', depth: 1, color: 'cyan' },
  intermediate: { label: 'Intermediate', depth: 2, color: 'purple' },
  core: { label: 'Core', depth: 3, color: 'amber' },
  bedrock: { label: 'Bedrock', depth: 4, color: 'red' }
}

const STATUS_INFO = {
  unexamined: { label: 'Unexamined', icon: '❓', color: 'zinc' },
  examining: { label: 'Examining', icon: '🔍', color: 'amber' },
  questioned: { label: 'Questioned', icon: '❔', color: 'purple' },
  retained: { label: 'Retained', icon: '✓', color: 'emerald' },
  released: { label: 'Released', icon: '🕊️', color: 'cyan' },
  transformed: { label: 'Transformed', icon: '🦋', color: 'pink' }
}

const INQUIRY_QUESTIONS = [
  "Is this belief absolutely true?",
  "Can you know with 100% certainty that it's true?",
  "How do you react when you believe this thought?",
  "Who would you be without this belief?",
  "What's the evidence for this belief?",
  "What's the evidence against this belief?",
  "Where did this belief come from?",
  "Whose voice first said this to you?",
  "Does this belief serve you now?",
  "What would you rather believe instead?"
]

// ============================================================================
// BELIEF CARD
// ============================================================================

function BeliefCard({ 
  belief, 
  onSelect 
}: { 
  belief: CoreBelief
  onSelect: () => void
}) {
  const category = CATEGORY_INFO[belief.category]
  const layer = LAYER_INFO[belief.layer]
  const status = STATUS_INFO[belief.status]
  
  return (
    <div 
      onClick={onSelect}
      className={`cascade-card p-5 cursor-pointer hover:border-${category.color}-500/30 transition-all`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">{category.icon}</span>
          <div className="flex gap-1">
            {Array.from({ length: layer.depth }).map((_, i) => (
              <div key={i} className={`w-2 h-2 rounded-full bg-${layer.color}-500`} />
            ))}
          </div>
        </div>
        <span className={`px-2 py-1 rounded-full text-xs bg-${status.color}-500/20 text-${status.color}-400`}>
          {status.icon} {status.label}
        </span>
      </div>
      
      <p className="text-sm text-zinc-200 mb-3 font-medium">"{belief.belief}"</p>
      
      {/* Impact indicator */}
      <div className={`inline-block px-2 py-0.5 rounded text-xs ${
        belief.impact === 'empowering' ? 'bg-emerald-500/20 text-emerald-400' :
        belief.impact === 'limiting' ? 'bg-red-500/20 text-red-400' :
        belief.impact === 'mixed' ? 'bg-amber-500/20 text-amber-400' :
        'bg-zinc-800 text-zinc-500'
      }`}>
        {belief.impact}
      </div>
      
      {/* Metrics */}
      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-zinc-500">Certainty: </span>
          <span className="text-cyan-400">{belief.certainty}/10</span>
        </div>
        <div>
          <span className="text-zinc-500">Charge: </span>
          <span className="text-amber-400">{belief.emotionalCharge}/10</span>
        </div>
      </div>
      
      {/* Origin hint */}
      {belief.origin && (
        <p className="mt-2 text-xs text-zinc-600 line-clamp-1">
          Origin: {belief.origin}
        </p>
      )}
    </div>
  )
}

// ============================================================================
// EXCAVATION FORM
// ============================================================================

function ExcavationForm({
  onSave,
  onCancel
}: {
  onSave: (belief: Omit<CoreBelief, 'id' | 'createdAt'>) => void
  onCancel: () => void
}) {
  const [belief, setBelief] = useState('')
  const [category, setCategory] = useState<BeliefCategory>('self')
  const [layer, setLayer] = useState<BeliefLayer>('surface')
  const [origin, setOrigin] = useState('')
  const [originAge, setOriginAge] = useState('')
  const [sourceVoice, setSourceVoice] = useState('')
  const [supporting, setSupporting] = useState('')
  const [contradicting, setContradicting] = useState('')
  const [emotionalCharge, setEmotionalCharge] = useState(5)
  const [certainty, setCertainty] = useState(7)
  const [impact, setImpact] = useState<BeliefImpact>('limiting')
  
  const handleSubmit = () => {
    if (!belief.trim()) return
    
    onSave({
      belief,
      category,
      layer,
      origin,
      originAge: originAge || undefined,
      sourceVoice: sourceVoice || undefined,
      supportingEvidence: supporting.split('\n').filter(s => s.trim()),
      contradictingEvidence: contradicting.split('\n').filter(c => c.trim()),
      emotionalCharge,
      certainty,
      impact,
      alternativeBeliefs: [],
      linkedBeliefs: [],
      status: 'unexamined'
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Excavate a Belief</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-2">The Belief</label>
          <textarea
            value={belief}
            onChange={(e) => setBelief(e.target.value)}
            placeholder="I believe that..."
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Category</label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.entries(CATEGORY_INFO) as [BeliefCategory, typeof CATEGORY_INFO[BeliefCategory]][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setCategory(key)}
                  className={`p-2 rounded-lg text-xs ${
                    category === key
                      ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                      : 'bg-zinc-800 hover:bg-zinc-700'
                  }`}
                >
                  {info.icon} {info.label}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Layer (how deep)</label>
            <div className="space-y-2">
              {(Object.entries(LAYER_INFO) as [BeliefLayer, typeof LAYER_INFO[BeliefLayer]][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setLayer(key)}
                  className={`w-full p-2 rounded-lg text-xs flex items-center gap-2 ${
                    layer === key
                      ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                      : 'bg-zinc-800 hover:bg-zinc-700'
                  }`}
                >
                  {Array.from({ length: info.depth }).map((_, i) => (
                    <div key={i} className={`w-2 h-2 rounded-full bg-${info.color}-500`} />
                  ))}
                  {info.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Origin */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Where/When formed</label>
            <input
              type="text"
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              placeholder="Childhood, school..."
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Age formed</label>
            <input
              type="text"
              value={originAge}
              onChange={(e) => setOriginAge(e.target.value)}
              placeholder="5 years old..."
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Whose voice?</label>
            <input
              type="text"
              value={sourceVoice}
              onChange={(e) => setSourceVoice(e.target.value)}
              placeholder="Parent, teacher..."
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
        </div>
        
        {/* Evidence */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Supporting evidence</label>
            <textarea
              value={supporting}
              onChange={(e) => setSupporting(e.target.value)}
              placeholder="Evidence this is true..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Contradicting evidence</label>
            <textarea
              value={contradicting}
              onChange={(e) => setContradicting(e.target.value)}
              placeholder="Evidence this might not be true..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        {/* Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-zinc-400">Emotional Charge</span>
              <span className="text-amber-400 font-bold">{emotionalCharge}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={emotionalCharge}
              onChange={(e) => setEmotionalCharge(parseInt(e.target.value))}
              className="w-full"
            />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-zinc-400">Certainty</span>
              <span className="text-cyan-400 font-bold">{certainty}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={certainty}
              onChange={(e) => setCertainty(parseInt(e.target.value))}
              className="w-full"
            />
          </div>
        </div>
        
        {/* Impact */}
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Impact on your life</label>
          <div className="grid grid-cols-4 gap-2">
            {(['empowering', 'limiting', 'neutral', 'mixed'] as const).map(i => (
              <button
                key={i}
                onClick={() => setImpact(i)}
                className={`p-2 rounded-lg text-xs capitalize ${
                  impact === i
                    ? i === 'empowering' ? 'bg-emerald-500/20 text-emerald-400' :
                      i === 'limiting' ? 'bg-red-500/20 text-red-400' :
                      i === 'mixed' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-zinc-700 text-zinc-400'
                    : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                {i}
              </button>
            ))}
          </div>
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!belief.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-red-500 text-white font-medium rounded-lg disabled:opacity-50"
          >
            Excavate
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// BELIEF EXAMINATION
// ============================================================================

function BeliefExamination({
  belief,
  onClose,
  onUpdate
}: {
  belief: CoreBelief
  onClose: () => void
  onUpdate: (updates: Partial<CoreBelief>) => void
}) {
  const [activeQuestion, setActiveQuestion] = useState(0)
  const [alternative, setAlternative] = useState('')
  const [conclusions, setConclusions] = useState(belief.conclusions || '')
  
  const category = CATEGORY_INFO[belief.category]
  const layer = LAYER_INFO[belief.layer]
  const status = STATUS_INFO[belief.status]
  
  const addAlternative = () => {
    if (!alternative.trim()) return
    onUpdate({ 
      alternativeBeliefs: [...belief.alternativeBeliefs, alternative],
      status: 'examining'
    })
    setAlternative('')
  }
  
  const updateStatus = (newStatus: CoreBelief['status']) => {
    onUpdate({ status: newStatus, examinedDate: Date.now() })
  }
  
  const saveConclusions = () => {
    onUpdate({ conclusions, status: 'questioned' })
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{category.icon}</span>
          <div>
            <p className="text-xs text-zinc-500">{category.label} • {layer.label}</p>
            <span className={`px-2 py-0.5 rounded text-xs bg-${status.color}-500/20 text-${status.color}-400`}>
              {status.label}
            </span>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      {/* The belief */}
      <div className="p-4 bg-zinc-800/50 rounded-lg mb-6">
        <p className="text-lg text-zinc-200 font-medium">"{belief.belief}"</p>
        {belief.origin && (
          <p className="text-sm text-zinc-500 mt-2">
            Origin: {belief.origin} {belief.originAge && `(age ${belief.originAge})`}
            {belief.sourceVoice && ` — voice of ${belief.sourceVoice}`}
          </p>
        )}
      </div>
      
      {/* Inquiry questions carousel */}
      <div className="mb-6">
        <p className="text-xs text-zinc-500 mb-2">Inquiry Question {activeQuestion + 1}/{INQUIRY_QUESTIONS.length}</p>
        <div className="p-4 bg-purple-500/10 rounded-lg">
          <p className="text-sm text-purple-300 italic">{INQUIRY_QUESTIONS[activeQuestion]}</p>
        </div>
        <div className="flex justify-between mt-2">
          <button
            onClick={() => setActiveQuestion(Math.max(0, activeQuestion - 1))}
            disabled={activeQuestion === 0}
            className="text-xs text-zinc-500 disabled:opacity-50"
          >
            ← Previous
          </button>
          <button
            onClick={() => setActiveQuestion(Math.min(INQUIRY_QUESTIONS.length - 1, activeQuestion + 1))}
            disabled={activeQuestion === INQUIRY_QUESTIONS.length - 1}
            className="text-xs text-zinc-500 disabled:opacity-50"
          >
            Next →
          </button>
        </div>
      </div>
      
      {/* Evidence comparison */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-3 bg-emerald-500/5 rounded-lg">
          <p className="text-xs text-emerald-400 mb-2">Supporting Evidence</p>
          {belief.supportingEvidence.length === 0 ? (
            <p className="text-xs text-zinc-600">None recorded</p>
          ) : (
            belief.supportingEvidence.map((e, i) => (
              <p key={i} className="text-sm text-zinc-300">• {e}</p>
            ))
          )}
        </div>
        <div className="p-3 bg-red-500/5 rounded-lg">
          <p className="text-xs text-red-400 mb-2">Contradicting Evidence</p>
          {belief.contradictingEvidence.length === 0 ? (
            <p className="text-xs text-zinc-600">None recorded</p>
          ) : (
            belief.contradictingEvidence.map((e, i) => (
              <p key={i} className="text-sm text-zinc-300">• {e}</p>
            ))
          )}
        </div>
      </div>
      
      {/* Alternative beliefs */}
      <div className="mb-6">
        <p className="text-sm text-zinc-400 mb-2">Alternative ways to see this:</p>
        {belief.alternativeBeliefs.length > 0 && (
          <div className="space-y-2 mb-2">
            {belief.alternativeBeliefs.map((alt, i) => (
              <div key={i} className="p-2 bg-cyan-500/10 rounded text-sm text-cyan-300">
                "{alt}"
              </div>
            ))}
          </div>
        )}
        <div className="flex gap-2">
          <input
            type="text"
            value={alternative}
            onChange={(e) => setAlternative(e.target.value)}
            placeholder="What else could be true?"
            className="flex-1 px-3 py-2 bg-zinc-800 border border-zinc-700 rounded text-sm text-zinc-200"
          />
          <button onClick={addAlternative} className="px-4 py-2 bg-cyan-500/20 text-cyan-400 rounded text-sm">
            Add
          </button>
        </div>
      </div>
      
      {/* Conclusions */}
      <div className="mb-6">
        <p className="text-sm text-zinc-400 mb-2">Your conclusions:</p>
        <textarea
          value={conclusions}
          onChange={(e) => setConclusions(e.target.value)}
          placeholder="After examining this belief, I now see..."
          rows={3}
          className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-sm text-zinc-200 resize-none mb-2"
        />
        <button onClick={saveConclusions} className="text-xs text-cyan-400">
          Save conclusions
        </button>
      </div>
      
      {/* Status actions */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={() => updateStatus('retained')}
          className="p-3 bg-emerald-500/20 text-emerald-400 rounded-lg text-sm"
        >
          ✓ Retain (true/useful)
        </button>
        <button
          onClick={() => updateStatus('released')}
          className="p-3 bg-cyan-500/20 text-cyan-400 rounded-lg text-sm"
        >
          🕊️ Release
        </button>
        <button
          onClick={() => updateStatus('transformed')}
          className="p-3 bg-pink-500/20 text-pink-400 rounded-lg text-sm"
        >
          🦋 Transform
        </button>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function BeliefArchaeologyPage() {
  const [beliefs, setBeliefs] = useState<CoreBelief[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedBelief, setSelectedBelief] = useState<CoreBelief | null>(null)
  const [filter, setFilter] = useState<'all' | BeliefImpact | CoreBelief['status']>('all')
  
  // Load beliefs
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-beliefs')
      if (saved) setBeliefs(JSON.parse(saved))
    }
  }, [])
  
  const saveBelief = (belief: Omit<CoreBelief, 'id' | 'createdAt'>) => {
    const newBelief: CoreBelief = {
      ...belief,
      id: `belief-${Date.now()}`,
      createdAt: Date.now()
    }
    
    const updated = [newBelief, ...beliefs]
    setBeliefs(updated)
    localStorage.setItem('cascade-beliefs', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const updateBelief = (id: string, updates: Partial<CoreBelief>) => {
    const updated = beliefs.map(b => b.id === id ? { ...b, ...updates } : b)
    setBeliefs(updated)
    localStorage.setItem('cascade-beliefs', JSON.stringify(updated))
    
    if (selectedBelief?.id === id) {
      setSelectedBelief(updated.find(b => b.id === id) || null)
    }
  }
  
  // Filter
  let filteredBeliefs = beliefs
  if (filter === 'limiting' || filter === 'empowering' || filter === 'neutral' || filter === 'mixed') {
    filteredBeliefs = beliefs.filter(b => b.impact === filter)
  } else if (['unexamined', 'examining', 'questioned', 'retained', 'released', 'transformed'].includes(filter)) {
    filteredBeliefs = beliefs.filter(b => b.status === filter)
  }
  
  // Stats
  const limitingCount = beliefs.filter(b => b.impact === 'limiting').length
  const examinedCount = beliefs.filter(b => b.status !== 'unexamined').length
  const transformedCount = beliefs.filter(b => b.status === 'transformed' || b.status === 'released').length
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Belief Archaeology</h1>
        <p className="text-zinc-500">Excavate and examine your core beliefs</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{beliefs.length}</p>
          <p className="text-xs text-zinc-500">Beliefs Found</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-red-400">{limitingCount}</p>
          <p className="text-xs text-zinc-500">Limiting</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{examinedCount}</p>
          <p className="text-xs text-zinc-500">Examined</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{transformedCount}</p>
          <p className="text-xs text-zinc-500">Transformed</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Main content */}
        <div>
          {showCreate ? (
            <ExcavationForm onSave={saveBelief} onCancel={() => setShowCreate(false)} />
          ) : selectedBelief ? (
            <BeliefExamination
              belief={selectedBelief}
              onClose={() => setSelectedBelief(null)}
              onUpdate={(updates) => updateBelief(selectedBelief.id, updates)}
            />
          ) : (
            <>
              <button
                onClick={() => setShowCreate(true)}
                className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-amber-400 hover:border-amber-500/30 transition-all"
              >
                + Excavate a Belief
              </button>
              
              {/* Filter */}
              <div className="flex flex-wrap gap-2 mb-4">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-3 py-1 rounded-full text-xs ${
                    filter === 'all' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilter('limiting')}
                  className={`px-3 py-1 rounded-full text-xs ${
                    filter === 'limiting' ? 'bg-red-500/20 text-red-400' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  Limiting
                </button>
                <button
                  onClick={() => setFilter('unexamined')}
                  className={`px-3 py-1 rounded-full text-xs ${
                    filter === 'unexamined' ? 'bg-zinc-700 text-zinc-400' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  Unexamined
                </button>
                <button
                  onClick={() => setFilter('transformed')}
                  className={`px-3 py-1 rounded-full text-xs ${
                    filter === 'transformed' ? 'bg-pink-500/20 text-pink-400' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  Transformed
                </button>
              </div>
              
              {filteredBeliefs.length === 0 ? (
                <div className="cascade-card p-12 text-center">
                  <p className="text-4xl mb-4">🏛️</p>
                  <p className="text-zinc-400">No beliefs excavated yet</p>
                  <p className="text-sm text-zinc-600">Start digging</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {filteredBeliefs.map(belief => (
                    <BeliefCard
                      key={belief.id}
                      belief={belief}
                      onSelect={() => setSelectedBelief(belief)}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
        
        {/* Layer visualization */}
        <div className="space-y-6">
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">Belief Strata</h3>
            {(Object.entries(LAYER_INFO) as [BeliefLayer, typeof LAYER_INFO[BeliefLayer]][]).map(([layer, info]) => {
              const layerBeliefs = beliefs.filter(b => b.layer === layer)
              return (
                <div key={layer} className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    {Array.from({ length: info.depth }).map((_, i) => (
                      <div key={i} className={`w-3 h-3 rounded-full bg-${info.color}-500`} />
                    ))}
                    <span className="text-sm text-zinc-400">{info.label}</span>
                    <span className="text-xs text-zinc-600 ml-auto">{layerBeliefs.length}</span>
                  </div>
                  <div className={`h-2 bg-zinc-800 rounded-full overflow-hidden`}>
                    <div 
                      className={`h-full bg-${info.color}-500`}
                      style={{ width: `${beliefs.length > 0 ? (layerBeliefs.length / beliefs.length) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              )
            })}
          </div>
          
          {/* Philosophy */}
          <div className="cascade-card p-6 bg-gradient-to-br from-amber-500/5 to-red-500/5">
            <h3 className="text-lg font-medium text-zinc-200 mb-3">🏛️ On Belief Archaeology</h3>
            <p className="text-sm text-zinc-400 mb-3">
              "A belief is not merely an idea the mind possesses; it is an idea that 
              possesses the mind." — Robert Oxton Bolton
            </p>
            <p className="text-sm text-zinc-500">
              Your beliefs form the bedrock of your reality. Most were formed in childhood, 
              before you could evaluate them. They now run silently, shaping what you see as 
              possible. By excavating these beliefs, examining their origins and evidence, 
              you can decide which to keep and which to release. The deepest beliefs are the 
              hardest to see — you don't have them, you live in them.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
