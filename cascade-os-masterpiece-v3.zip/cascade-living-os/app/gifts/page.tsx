'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface Gift {
  id: string
  name: string
  category: GiftCategory
  description: string
  
  // Evidence
  evidence: string[]         // Times this gift showed up
  feedback: string[]         // What others have said
  
  // Development
  developmentLevel: 'dormant' | 'emerging' | 'developing' | 'strong' | 'mastered'
  practiceAreas: string[]    // How to develop further
  blockers: string[]         // What blocks this gift
  
  // Application
  applications: string[]     // How you've used it
  potentialUses: string[]    // Unexplored applications
  
  // Energy
  energyEffect: 'energizing' | 'neutral' | 'draining' // How using it feels
  flowTrigger: boolean       // Does this put you in flow?
  
  // Integration
  linkedGifts: string[]      // Gifts that combine well
  shadowSide?: string        // The shadow of this gift
  
  createdAt: number
  lastUsed?: number
}

type GiftCategory = 
  | 'cognitive'      // Thinking abilities
  | 'creative'       // Creative abilities
  | 'relational'     // People skills
  | 'physical'       // Body-based skills
  | 'intuitive'      // Intuitive abilities
  | 'practical'      // Practical skills
  | 'leadership'     // Leadership abilities
  | 'healing'        // Healing/helping abilities
  | 'spiritual'      // Spiritual gifts
  | 'unique'         // Unique combination

// ============================================================================
// CONSTANTS
// ============================================================================

const CATEGORY_INFO: Record<GiftCategory, { label: string; icon: string; color: string; examples: string[] }> = {
  cognitive: { 
    label: 'Cognitive', 
    icon: '🧠', 
    color: 'cyan',
    examples: ['Pattern recognition', 'Strategic thinking', 'Analysis', 'Memory', 'Learning speed']
  },
  creative: { 
    label: 'Creative', 
    icon: '🎨', 
    color: 'purple',
    examples: ['Visual art', 'Writing', 'Music', 'Innovation', 'Problem-solving']
  },
  relational: { 
    label: 'Relational', 
    icon: '💗', 
    color: 'pink',
    examples: ['Empathy', 'Communication', 'Conflict resolution', 'Teaching', 'Inspiring']
  },
  physical: { 
    label: 'Physical', 
    icon: '💪', 
    color: 'orange',
    examples: ['Athletics', 'Coordination', 'Endurance', 'Hands-on skills', 'Presence']
  },
  intuitive: { 
    label: 'Intuitive', 
    icon: '✨', 
    color: 'indigo',
    examples: ['Gut feelings', 'Reading people', 'Sensing energy', 'Timing', 'Dreams']
  },
  practical: { 
    label: 'Practical', 
    icon: '🔧', 
    color: 'emerald',
    examples: ['Organization', 'Efficiency', 'Fixing things', 'Planning', 'Execution']
  },
  leadership: { 
    label: 'Leadership', 
    icon: '👑', 
    color: 'amber',
    examples: ['Vision', 'Decision-making', 'Courage', 'Responsibility', 'Presence']
  },
  healing: { 
    label: 'Healing', 
    icon: '💚', 
    color: 'green',
    examples: ['Listening', 'Holding space', 'Touch', 'Words', 'Energy']
  },
  spiritual: { 
    label: 'Spiritual', 
    icon: '🕯️', 
    color: 'violet',
    examples: ['Presence', 'Wisdom', 'Connection', 'Transmission', 'Ceremony']
  },
  unique: { 
    label: 'Unique', 
    icon: '🌟', 
    color: 'amber',
    examples: ['Your special combination', 'What only you can do']
  }
}

const LEVEL_INFO = {
  dormant: { label: 'Dormant', color: 'zinc', progress: 10 },
  emerging: { label: 'Emerging', color: 'purple', progress: 30 },
  developing: { label: 'Developing', color: 'cyan', progress: 50 },
  strong: { label: 'Strong', color: 'emerald', progress: 75 },
  mastered: { label: 'Mastered', color: 'amber', progress: 100 }
}

// ============================================================================
// GIFT CARD
// ============================================================================

function GiftCard({ 
  gift, 
  onSelect 
}: { 
  gift: Gift
  onSelect: () => void
}) {
  const category = CATEGORY_INFO[gift.category]
  const level = LEVEL_INFO[gift.developmentLevel]
  
  return (
    <div 
      onClick={onSelect}
      className={`cascade-card p-5 cursor-pointer hover:border-${category.color}-500/30 transition-all`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{category.icon}</span>
          <div>
            <h3 className="font-medium text-zinc-200">{gift.name}</h3>
            <p className="text-xs text-zinc-500">{category.label}</p>
          </div>
        </div>
        <div className="text-right">
          <span className={`px-2 py-1 rounded text-xs bg-${level.color}-500/20 text-${level.color}-400`}>
            {level.label}
          </span>
        </div>
      </div>
      
      <p className="text-sm text-zinc-400 line-clamp-2 mb-3">{gift.description}</p>
      
      {/* Progress bar */}
      <div className="mb-3">
        <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
          <div 
            className={`h-full bg-gradient-to-r from-${category.color}-500 to-${level.color}-400`}
            style={{ width: `${level.progress}%` }}
          />
        </div>
      </div>
      
      {/* Indicators */}
      <div className="flex gap-2">
        {gift.flowTrigger && (
          <span className="px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded text-xs">
            🌊 Flow trigger
          </span>
        )}
        {gift.energyEffect === 'energizing' && (
          <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded text-xs">
            ⚡ Energizing
          </span>
        )}
        {gift.evidence.length > 0 && (
          <span className="px-2 py-0.5 bg-zinc-800 text-zinc-500 rounded text-xs">
            {gift.evidence.length} examples
          </span>
        )}
      </div>
    </div>
  )
}

// ============================================================================
// CREATE GIFT FORM
// ============================================================================

function CreateGiftForm({
  onSave,
  onCancel
}: {
  onSave: (gift: Omit<Gift, 'id' | 'createdAt'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState('')
  const [category, setCategory] = useState<GiftCategory>('cognitive')
  const [description, setDescription] = useState('')
  const [evidence, setEvidence] = useState('')
  const [feedback, setFeedback] = useState('')
  const [developmentLevel, setDevelopmentLevel] = useState<Gift['developmentLevel']>('developing')
  const [applications, setApplications] = useState('')
  const [energyEffect, setEnergyEffect] = useState<Gift['energyEffect']>('energizing')
  const [flowTrigger, setFlowTrigger] = useState(false)
  const [shadowSide, setShadowSide] = useState('')
  
  const handleSubmit = () => {
    if (!name.trim()) return
    
    onSave({
      name,
      category,
      description,
      evidence: evidence.split('\n').filter(e => e.trim()),
      feedback: feedback.split('\n').filter(f => f.trim()),
      developmentLevel,
      practiceAreas: [],
      blockers: [],
      applications: applications.split('\n').filter(a => a.trim()),
      potentialUses: [],
      energyEffect,
      flowTrigger,
      linkedGifts: [],
      shadowSide: shadowSide || undefined
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Discover a Gift</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Gift Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Pattern Recognition, Deep Listening..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Category</label>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            {(Object.entries(CATEGORY_INFO) as [GiftCategory, typeof CATEGORY_INFO[GiftCategory]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setCategory(key)}
                className={`p-2 rounded-lg text-xs ${
                  category === key
                    ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                    : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
                title={info.examples.join(', ')}
              >
                <span className="text-lg block">{info.icon}</span>
                <span className="text-zinc-400">{info.label}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe this gift..."
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Development Level</label>
          <div className="grid grid-cols-5 gap-2">
            {(Object.entries(LEVEL_INFO) as [Gift['developmentLevel'], typeof LEVEL_INFO[Gift['developmentLevel']]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setDevelopmentLevel(key)}
                className={`p-2 rounded-lg text-xs ${
                  developmentLevel === key
                    ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                    : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
              >
                {info.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Evidence (times it showed up)</label>
            <textarea
              value={evidence}
              onChange={(e) => setEvidence(e.target.value)}
              placeholder="One example per line..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Feedback from others</label>
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="What have others said about this gift?"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">How you've applied it</label>
          <textarea
            value={applications}
            onChange={(e) => setApplications(e.target.value)}
            placeholder="Ways you've used this gift..."
            rows={2}
            className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Energy Effect</label>
            <div className="grid grid-cols-3 gap-2">
              {(['energizing', 'neutral', 'draining'] as const).map(effect => (
                <button
                  key={effect}
                  onClick={() => setEnergyEffect(effect)}
                  className={`p-2 rounded-lg text-xs capitalize ${
                    energyEffect === effect
                      ? effect === 'energizing' ? 'bg-emerald-500/20 text-emerald-400' :
                        effect === 'draining' ? 'bg-red-500/20 text-red-400' :
                        'bg-zinc-700 text-zinc-400'
                      : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {effect === 'energizing' && '⚡ '}
                  {effect === 'draining' && '😴 '}
                  {effect === 'neutral' && '➖ '}
                  {effect}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Flow Trigger</label>
            <button
              onClick={() => setFlowTrigger(!flowTrigger)}
              className={`w-full p-3 rounded-lg text-sm ${
                flowTrigger
                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
                  : 'bg-zinc-800 text-zinc-500'
              }`}
            >
              🌊 {flowTrigger ? 'Yes - puts me in flow' : 'Does this put you in flow?'}
            </button>
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Shadow Side (optional)</label>
          <input
            type="text"
            value={shadowSide}
            onChange={(e) => setShadowSide(e.target.value)}
            placeholder="The downside or overuse of this gift..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!name.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-purple-500 text-white font-medium rounded-lg disabled:opacity-50"
          >
            Add Gift
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function GiftInventoryPage() {
  const [gifts, setGifts] = useState<Gift[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedGift, setSelectedGift] = useState<Gift | null>(null)
  const [filterCategory, setFilterCategory] = useState<GiftCategory | 'all'>('all')
  
  // Load gifts
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-gifts')
      if (saved) setGifts(JSON.parse(saved))
    }
  }, [])
  
  const saveGift = (gift: Omit<Gift, 'id' | 'createdAt'>) => {
    const newGift: Gift = {
      ...gift,
      id: `gift-${Date.now()}`,
      createdAt: Date.now()
    }
    
    const updated = [newGift, ...gifts]
    setGifts(updated)
    localStorage.setItem('cascade-gifts', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const filteredGifts = filterCategory === 'all' 
    ? gifts 
    : gifts.filter(g => g.category === filterCategory)
  
  // Stats
  const masteredCount = gifts.filter(g => g.developmentLevel === 'mastered' || g.developmentLevel === 'strong').length
  const flowTriggerCount = gifts.filter(g => g.flowTrigger).length
  const energizingCount = gifts.filter(g => g.energyEffect === 'energizing').length
  
  // Category distribution
  const categoryDistribution = Object.keys(CATEGORY_INFO).map(cat => ({
    category: cat as GiftCategory,
    count: gifts.filter(g => g.category === cat).length
  })).filter(c => c.count > 0)
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Gift Inventory</h1>
        <p className="text-zinc-500">Catalog your unique gifts and superpowers</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{gifts.length}</p>
          <p className="text-xs text-zinc-500">Gifts Discovered</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{masteredCount}</p>
          <p className="text-xs text-zinc-500">Strong/Mastered</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{flowTriggerCount}</p>
          <p className="text-xs text-zinc-500">Flow Triggers</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{energizingCount}</p>
          <p className="text-xs text-zinc-500">Energizing</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content */}
        <div className="lg:col-span-2">
          {showCreate ? (
            <CreateGiftForm onSave={saveGift} onCancel={() => setShowCreate(false)} />
          ) : (
            <>
              <button
                onClick={() => setShowCreate(true)}
                className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-amber-400 hover:border-amber-500/30 transition-all"
              >
                + Discover a Gift
              </button>
              
              {/* Category filter */}
              <div className="flex flex-wrap gap-2 mb-4">
                <button
                  onClick={() => setFilterCategory('all')}
                  className={`px-3 py-1 rounded-full text-xs ${
                    filterCategory === 'all' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  All
                </button>
                {(Object.entries(CATEGORY_INFO) as [GiftCategory, typeof CATEGORY_INFO[GiftCategory]][]).map(([key, info]) => (
                  <button
                    key={key}
                    onClick={() => setFilterCategory(key)}
                    className={`px-3 py-1 rounded-full text-xs ${
                      filterCategory === key ? `bg-${info.color}-500/20 text-${info.color}-400` : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {info.icon} {info.label}
                  </button>
                ))}
              </div>
              
              {filteredGifts.length === 0 ? (
                <div className="cascade-card p-12 text-center">
                  <p className="text-4xl mb-4">🎁</p>
                  <p className="text-zinc-400">No gifts cataloged yet</p>
                  <p className="text-sm text-zinc-600">What are you naturally good at?</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredGifts.map(gift => (
                    <GiftCard
                      key={gift.id}
                      gift={gift}
                      onSelect={() => setSelectedGift(gift)}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Gift Profile */}
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">🎁 Gift Profile</h3>
            {categoryDistribution.length === 0 ? (
              <p className="text-sm text-zinc-500">Add gifts to see your profile</p>
            ) : (
              <div className="space-y-3">
                {categoryDistribution.sort((a, b) => b.count - a.count).map(({ category, count }) => {
                  const info = CATEGORY_INFO[category]
                  return (
                    <div key={category}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-zinc-400">{info.icon} {info.label}</span>
                        <span className={`text-${info.color}-400`}>{count}</span>
                      </div>
                      <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full bg-${info.color}-500`}
                          style={{ width: `${(count / gifts.length) * 100}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
          
          {/* Prompts */}
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">💡 Discovery Prompts</h3>
            <div className="space-y-2 text-sm text-zinc-400">
              <p>• What do people often ask your help with?</p>
              <p>• What comes naturally to you that others struggle with?</p>
              <p>• What activities make you lose track of time?</p>
              <p>• What did you love doing as a child?</p>
              <p>• What would you do even if you weren't paid?</p>
            </div>
          </div>
          
          {/* Philosophy */}
          <div className="cascade-card p-6 bg-gradient-to-br from-amber-500/5 to-purple-500/5">
            <h3 className="text-lg font-medium text-zinc-200 mb-3">🌟 On Gifts</h3>
            <p className="text-sm text-zinc-400 mb-3">
              "Your playing small does not serve the world." — Marianne Williamson
            </p>
            <p className="text-sm text-zinc-500">
              You have unique gifts that the world needs. Some are obvious, some are hidden. 
              Some are developed, some are dormant. By cataloging your gifts, you can 
              consciously develop them, use them in service, and combine them in ways that 
              only you can. Every gift has a shadow — knowing both empowers wise use.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
