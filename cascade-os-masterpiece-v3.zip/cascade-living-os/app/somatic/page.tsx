'use client'

import { useState, useEffect, useRef } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface BodyRegion {
  id: string
  name: string
  x: number
  y: number
  width: number
  height: number
}

interface SomaticEntry {
  id: string
  regions: {
    regionId: string
    sensation: SensationType
    intensity: number // 1-10
    quality: string[]
    message?: string
  }[]
  overallState: 'grounded' | 'activated' | 'dissociated' | 'flowing'
  breathQuality: number // 1-10
  notes?: string
  timestamp: number
}

type SensationType = 
  | 'tension' | 'pain' | 'warmth' | 'cold' | 'tingling' 
  | 'numbness' | 'pressure' | 'expansion' | 'contraction' | 'pulsing'
  | 'heaviness' | 'lightness' | 'vibration' | 'stillness' | 'flow'

interface BodyPattern {
  pattern: string
  regions: string[]
  frequency: number
  interpretation: string
}

// ============================================================================
// CONSTANTS
// ============================================================================

const BODY_REGIONS: BodyRegion[] = [
  { id: 'head', name: 'Head', x: 45, y: 2, width: 10, height: 8 },
  { id: 'throat', name: 'Throat', x: 46, y: 11, width: 8, height: 4 },
  { id: 'shoulders', name: 'Shoulders', x: 30, y: 15, width: 40, height: 6 },
  { id: 'chest', name: 'Chest', x: 38, y: 22, width: 24, height: 12 },
  { id: 'heart', name: 'Heart', x: 45, y: 25, width: 10, height: 8 },
  { id: 'solar', name: 'Solar Plexus', x: 42, y: 35, width: 16, height: 8 },
  { id: 'belly', name: 'Belly', x: 40, y: 44, width: 20, height: 10 },
  { id: 'pelvis', name: 'Pelvis', x: 38, y: 55, width: 24, height: 10 },
  { id: 'left-arm', name: 'Left Arm', x: 20, y: 20, width: 12, height: 35 },
  { id: 'right-arm', name: 'Right Arm', x: 68, y: 20, width: 12, height: 35 },
  { id: 'left-hand', name: 'Left Hand', x: 15, y: 55, width: 10, height: 10 },
  { id: 'right-hand', name: 'Right Hand', x: 75, y: 55, width: 10, height: 10 },
  { id: 'left-leg', name: 'Left Leg', x: 38, y: 66, width: 12, height: 28 },
  { id: 'right-leg', name: 'Right Leg', x: 50, y: 66, width: 12, height: 28 },
  { id: 'left-foot', name: 'Left Foot', x: 35, y: 92, width: 12, height: 6 },
  { id: 'right-foot', name: 'Right Foot', x: 53, y: 92, width: 12, height: 6 },
]

const SENSATIONS: { type: SensationType; icon: string; color: string }[] = [
  { type: 'tension', icon: '💪', color: 'red' },
  { type: 'pain', icon: '⚡', color: 'red' },
  { type: 'warmth', icon: '🔥', color: 'orange' },
  { type: 'cold', icon: '❄️', color: 'blue' },
  { type: 'tingling', icon: '✨', color: 'purple' },
  { type: 'numbness', icon: '🔇', color: 'zinc' },
  { type: 'pressure', icon: '⬇️', color: 'amber' },
  { type: 'expansion', icon: '🌟', color: 'cyan' },
  { type: 'contraction', icon: '🔘', color: 'pink' },
  { type: 'pulsing', icon: '💓', color: 'pink' },
  { type: 'heaviness', icon: '🪨', color: 'zinc' },
  { type: 'lightness', icon: '🪶', color: 'emerald' },
  { type: 'vibration', icon: '〰️', color: 'purple' },
  { type: 'stillness', icon: '🧘', color: 'cyan' },
  { type: 'flow', icon: '🌊', color: 'blue' },
]

const QUALITIES = [
  'sharp', 'dull', 'spreading', 'localized', 'deep', 'surface',
  'pulsating', 'constant', 'intermittent', 'moving', 'stuck', 'releasing'
]

// ============================================================================
// BODY MAP VISUALIZATION
// ============================================================================

function BodyMap({ 
  selectedRegions,
  onRegionClick,
  regionData
}: { 
  selectedRegions: string[]
  onRegionClick: (regionId: string) => void
  regionData: Record<string, { sensation: SensationType; intensity: number }>
}) {
  const getRegionColor = (regionId: string) => {
    const data = regionData[regionId]
    if (!data) return 'rgba(63, 63, 70, 0.3)'
    
    const sensation = SENSATIONS.find(s => s.type === data.sensation)
    const alpha = 0.3 + (data.intensity / 10) * 0.6
    
    const colors: Record<string, string> = {
      red: `rgba(239, 68, 68, ${alpha})`,
      orange: `rgba(249, 115, 22, ${alpha})`,
      blue: `rgba(59, 130, 246, ${alpha})`,
      purple: `rgba(168, 85, 247, ${alpha})`,
      zinc: `rgba(161, 161, 170, ${alpha})`,
      amber: `rgba(245, 158, 11, ${alpha})`,
      cyan: `rgba(6, 182, 212, ${alpha})`,
      pink: `rgba(236, 72, 153, ${alpha})`,
      emerald: `rgba(16, 185, 129, ${alpha})`
    }
    
    return colors[sensation?.color || 'zinc']
  }
  
  return (
    <div className="relative w-full max-w-md mx-auto aspect-[1/2]">
      {/* Body outline SVG */}
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {/* Simple body silhouette */}
        <ellipse cx="50" cy="6" rx="8" ry="6" fill="none" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <line x1="50" y1="12" x2="50" y2="15" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <ellipse cx="50" cy="35" rx="15" ry="20" fill="none" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <ellipse cx="50" cy="60" rx="12" ry="8" fill="none" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <line x1="35" y1="18" x2="20" y2="55" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <line x1="65" y1="18" x2="80" y2="55" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <line x1="42" y1="68" x2="40" y2="95" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
        <line x1="58" y1="68" x2="60" y2="95" stroke="rgb(63, 63, 70)" strokeWidth="0.5" />
      </svg>
      
      {/* Clickable regions */}
      {BODY_REGIONS.map(region => (
        <button
          key={region.id}
          onClick={() => onRegionClick(region.id)}
          className={`absolute rounded-lg transition-all hover:scale-105 ${
            selectedRegions.includes(region.id) ? 'ring-2 ring-cyan-400' : ''
          }`}
          style={{
            left: `${region.x}%`,
            top: `${region.y}%`,
            width: `${region.width}%`,
            height: `${region.height}%`,
            backgroundColor: getRegionColor(region.id)
          }}
          title={region.name}
        />
      ))}
    </div>
  )
}

// ============================================================================
// REGION EDITOR
// ============================================================================

function RegionEditor({
  region,
  data,
  onUpdate,
  onClose
}: {
  region: BodyRegion
  data: { sensation: SensationType; intensity: number; quality: string[]; message?: string } | null
  onUpdate: (data: { sensation: SensationType; intensity: number; quality: string[]; message?: string }) => void
  onClose: () => void
}) {
  const [sensation, setSensation] = useState<SensationType>(data?.sensation || 'tension')
  const [intensity, setIntensity] = useState(data?.intensity || 5)
  const [qualities, setQualities] = useState<string[]>(data?.quality || [])
  const [message, setMessage] = useState(data?.message || '')
  
  const toggleQuality = (q: string) => {
    setQualities(prev => 
      prev.includes(q) ? prev.filter(x => x !== q) : [...prev, q]
    )
  }
  
  const handleSave = () => {
    onUpdate({ sensation, intensity, quality: qualities, message: message || undefined })
    onClose()
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-zinc-200">{region.name}</h3>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      {/* Sensation Type */}
      <div className="mb-4">
        <p className="text-sm text-zinc-400 mb-2">Sensation</p>
        <div className="grid grid-cols-5 gap-2">
          {SENSATIONS.map(s => (
            <button
              key={s.type}
              onClick={() => setSensation(s.type)}
              className={`p-2 rounded-lg text-center transition-all ${
                sensation === s.type
                  ? `bg-${s.color}-500/30 border border-${s.color}-500/50`
                  : 'bg-zinc-800 hover:bg-zinc-700'
              }`}
            >
              <span className="text-lg block">{s.icon}</span>
              <span className="text-xs text-zinc-400">{s.type}</span>
            </button>
          ))}
        </div>
      </div>
      
      {/* Intensity */}
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-zinc-400">Intensity</span>
          <span className="text-cyan-400 font-bold">{intensity}/10</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={intensity}
          onChange={(e) => setIntensity(parseInt(e.target.value))}
          className="w-full"
        />
      </div>
      
      {/* Qualities */}
      <div className="mb-4">
        <p className="text-sm text-zinc-400 mb-2">Quality</p>
        <div className="flex flex-wrap gap-2">
          {QUALITIES.map(q => (
            <button
              key={q}
              onClick={() => toggleQuality(q)}
              className={`px-3 py-1 rounded-full text-sm transition-all ${
                qualities.includes(q)
                  ? 'bg-purple-500/30 text-purple-300 border border-purple-500/50'
                  : 'bg-zinc-800 text-zinc-500 hover:bg-zinc-700'
              }`}
            >
              {q}
            </button>
          ))}
        </div>
      </div>
      
      {/* Message from body */}
      <div className="mb-4">
        <p className="text-sm text-zinc-400 mb-2">What is this sensation telling you?</p>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Listen to your body's wisdom..."
          rows={2}
          className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
        />
      </div>
      
      <button
        onClick={handleSave}
        className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-zinc-900 font-medium rounded-lg"
      >
        Save Sensation
      </button>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function SomaticPage() {
  const [entries, setEntries] = useState<SomaticEntry[]>([])
  const [selectedRegions, setSelectedRegions] = useState<string[]>([])
  const [editingRegion, setEditingRegion] = useState<string | null>(null)
  const [regionData, setRegionData] = useState<Record<string, {
    sensation: SensationType
    intensity: number
    quality: string[]
    message?: string
  }>>({})
  const [overallState, setOverallState] = useState<SomaticEntry['overallState']>('grounded')
  const [breathQuality, setBreathQuality] = useState(7)
  const [notes, setNotes] = useState('')
  
  // Load entries
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-somatic')
      if (saved) setEntries(JSON.parse(saved))
    }
  }, [])
  
  const handleRegionClick = (regionId: string) => {
    setEditingRegion(regionId)
    if (!selectedRegions.includes(regionId)) {
      setSelectedRegions([...selectedRegions, regionId])
    }
  }
  
  const handleRegionUpdate = (data: { sensation: SensationType; intensity: number; quality: string[]; message?: string }) => {
    if (editingRegion) {
      setRegionData(prev => ({ ...prev, [editingRegion]: data }))
    }
  }
  
  const saveEntry = () => {
    const regions = Object.entries(regionData).map(([regionId, data]) => ({
      regionId,
      ...data
    }))
    
    if (regions.length === 0) return
    
    const newEntry: SomaticEntry = {
      id: `somatic-${Date.now()}`,
      regions,
      overallState,
      breathQuality,
      notes: notes || undefined,
      timestamp: Date.now()
    }
    
    const updated = [newEntry, ...entries]
    setEntries(updated)
    localStorage.setItem('cascade-somatic', JSON.stringify(updated))
    
    // Reset
    setSelectedRegions([])
    setRegionData({})
    setNotes('')
  }
  
  const clearSelection = () => {
    setSelectedRegions([])
    setRegionData({})
  }
  
  // Stats
  const avgBreath = entries.length > 0
    ? (entries.reduce((sum, e) => sum + e.breathQuality, 0) / entries.length).toFixed(1)
    : 0
  const mostTenseRegion = entries.length > 0
    ? entries.flatMap(e => e.regions)
        .filter(r => r.sensation === 'tension' || r.sensation === 'pain')
        .reduce((acc, r) => {
          acc[r.regionId] = (acc[r.regionId] || 0) + 1
          return acc
        }, {} as Record<string, number>)
    : {}
  const topTense = Object.entries(mostTenseRegion).sort((a, b) => b[1] - a[1])[0]
  
  const editingRegionData = editingRegion ? BODY_REGIONS.find(r => r.id === editingRegion) : null
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Somatic Intelligence</h1>
        <p className="text-zinc-500">Listen to your body's wisdom</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{entries.length}</p>
          <p className="text-xs text-zinc-500">Body Scans</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{avgBreath}</p>
          <p className="text-xs text-zinc-500">Avg Breath Quality</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">
            {topTense ? BODY_REGIONS.find(r => r.id === topTense[0])?.name || '-' : '-'}
          </p>
          <p className="text-xs text-zinc-500">Most Tense Area</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Body Map */}
        <div className="cascade-card p-6">
          <h3 className="text-lg font-medium text-zinc-200 mb-4">Body Map</h3>
          <p className="text-sm text-zinc-500 mb-4">Click on regions to log sensations</p>
          
          <BodyMap
            selectedRegions={selectedRegions}
            onRegionClick={handleRegionClick}
            regionData={regionData}
          />
          
          {selectedRegions.length > 0 && (
            <div className="mt-4 flex gap-2">
              <button
                onClick={clearSelection}
                className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded-lg"
              >
                Clear
              </button>
              <button
                onClick={saveEntry}
                className="flex-1 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg"
              >
                Save Scan
              </button>
            </div>
          )}
        </div>
        
        {/* Editor or Controls */}
        <div className="space-y-6">
          {editingRegion && editingRegionData ? (
            <RegionEditor
              region={editingRegionData}
              data={regionData[editingRegion] || null}
              onUpdate={handleRegionUpdate}
              onClose={() => setEditingRegion(null)}
            />
          ) : (
            <>
              {/* Overall State */}
              <div className="cascade-card p-6">
                <h3 className="text-lg font-medium text-zinc-200 mb-4">Overall State</h3>
                <div className="grid grid-cols-2 gap-2">
                  {(['grounded', 'activated', 'dissociated', 'flowing'] as const).map(state => (
                    <button
                      key={state}
                      onClick={() => setOverallState(state)}
                      className={`p-3 rounded-lg text-sm capitalize transition-all ${
                        overallState === state
                          ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                          : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                      }`}
                    >
                      {state === 'grounded' && '🌳 '}
                      {state === 'activated' && '⚡ '}
                      {state === 'dissociated' && '☁️ '}
                      {state === 'flowing' && '🌊 '}
                      {state}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Breath Quality */}
              <div className="cascade-card p-6">
                <h3 className="text-lg font-medium text-zinc-200 mb-4">Breath Quality</h3>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-zinc-400">Shallow</span>
                  <span className="text-lg font-bold text-purple-400">{breathQuality}</span>
                  <span className="text-sm text-zinc-400">Deep</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={breathQuality}
                  onChange={(e) => setBreathQuality(parseInt(e.target.value))}
                  className="w-full"
                />
              </div>
              
              {/* Notes */}
              <div className="cascade-card p-6">
                <h3 className="text-lg font-medium text-zinc-200 mb-4">Notes</h3>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Any additional observations..."
                  rows={3}
                  className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
                />
              </div>
            </>
          )}
          
          {/* Recent Scans */}
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">Recent Scans</h3>
            {entries.length === 0 ? (
              <p className="text-sm text-zinc-500">No body scans yet</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {entries.slice(0, 5).map(entry => (
                  <div key={entry.id} className="p-3 bg-zinc-800/50 rounded-lg">
                    <div className="flex justify-between text-xs text-zinc-500 mb-1">
                      <span>{new Date(entry.timestamp).toLocaleDateString()}</span>
                      <span className="capitalize">{entry.overallState}</span>
                    </div>
                    <div className="flex gap-1">
                      {entry.regions.slice(0, 4).map(r => (
                        <span key={r.regionId} className="text-lg">
                          {SENSATIONS.find(s => s.type === r.sensation)?.icon}
                        </span>
                      ))}
                      {entry.regions.length > 4 && (
                        <span className="text-xs text-zinc-500">+{entry.regions.length - 4}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🧘 Somatic Wisdom</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "The body keeps the score." — Bessel van der Kolk
        </p>
        <p className="text-sm text-zinc-500">
          Your body is constantly communicating. Tension, warmth, tingling — each sensation 
          carries information. By developing somatic awareness, you access wisdom that the 
          thinking mind cannot reach. The body doesn't lie.
        </p>
      </div>
    </div>
  )
}
