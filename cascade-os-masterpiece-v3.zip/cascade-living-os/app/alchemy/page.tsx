'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface AlchemicalStage {
  id: number
  name: string
  latinName: string
  color: string
  element: string
  symbol: string
  description: string
  process: string
  psychological: string
  signs: string[]
  practices: string[]
  shadow: string
}

interface TransformationEntry {
  id: string
  stageId: number
  title: string
  description: string
  whatDied?: string
  whatBorn?: string
  insights: string[]
  practices: string[]
  timestamp: number
}

interface AlchemicalJourney {
  id: string
  name: string
  intention: string
  currentStage: number
  entries: TransformationEntry[]
  startedAt: number
  completedAt?: number
}

// ============================================================================
// THE SEVEN ALCHEMICAL STAGES
// ============================================================================

const ALCHEMICAL_STAGES: AlchemicalStage[] = [
  {
    id: 1,
    name: 'Calcination',
    latinName: 'Calcinatio',
    color: 'red',
    element: 'Fire',
    symbol: '🔥',
    description: 'The burning away of ego attachments and false identities.',
    process: 'Fire burns everything non-essential. What remains is the true essence.',
    psychological: 'Destruction of ego defenses. Humiliation, defeat, or loss of what we thought we were.',
    signs: ['Ego death', 'Loss of identity', 'Humbling experiences', 'Breaking down', 'Destruction of illusions'],
    practices: ['Fasting', 'Intense exercise', 'Facing fears', 'Admitting defeat', 'Letting go'],
    shadow: 'Destruction without purpose, rage, nihilism'
  },
  {
    id: 2,
    name: 'Dissolution',
    latinName: 'Solutio',
    color: 'blue',
    element: 'Water',
    symbol: '💧',
    description: 'The dissolving of rigidity through emotion and feeling.',
    process: 'Water dissolves what fire left behind. The ash becomes fluid.',
    psychological: 'Opening to emotions. Tears, grief, and catharsis dissolve hardened structures.',
    signs: ['Deep emotions', 'Tears and grief', 'Letting go control', 'Fluidity', 'Surrender'],
    practices: ['Crying', 'Water rituals', 'Emotional release', 'Floating', 'Accepting uncertainty'],
    shadow: 'Drowning in emotion, losing all structure, chaos'
  },
  {
    id: 3,
    name: 'Separation',
    latinName: 'Separatio',
    color: 'amber',
    element: 'Air',
    symbol: '💨',
    description: 'The sorting of what is essential from what is not.',
    process: 'Air separates and sorts. Discernment emerges.',
    psychological: 'Critical analysis. Distinguishing authentic self from conditioned self.',
    signs: ['Clarity', 'Discernment', 'Setting boundaries', 'Recognizing patterns', 'Discrimination'],
    practices: ['Analysis', 'Journaling', 'Therapy', 'Shadow work', 'Sorting priorities'],
    shadow: 'Over-analysis, cold detachment, splitting'
  },
  {
    id: 4,
    name: 'Conjunction',
    latinName: 'Coniunctio',
    color: 'emerald',
    element: 'Earth',
    symbol: '🌍',
    description: 'The sacred marriage of opposites.',
    process: 'Earth grounds and integrates. The separated elements unite.',
    psychological: 'Integration of opposites. Masculine/feminine, light/shadow, conscious/unconscious.',
    signs: ['Integration', 'Wholeness', 'Inner marriage', 'Balance', 'Embodiment'],
    practices: ['Meditation', 'Breathwork', 'Sacred sexuality', 'Grounding', 'Body awareness'],
    shadow: 'Premature synthesis, spiritual bypassing, false wholeness'
  },
  {
    id: 5,
    name: 'Fermentation',
    latinName: 'Fermentatio',
    color: 'purple',
    element: 'Spirit',
    symbol: '🍇',
    description: 'The death and rebirth that produces new life.',
    process: 'Decay gives rise to new life. The old nourishes the new.',
    psychological: 'Spiritual awakening. New inspiration and vitality emerge from the integrated self.',
    signs: ['Inspiration', 'Rebirth', 'New energy', 'Spiritual experiences', 'Creative surge'],
    practices: ['Prayer', 'Ritual', 'Creativity', 'Allowing inspiration', 'Surrender to process'],
    shadow: 'Inflation, spiritual emergency, manic states'
  },
  {
    id: 6,
    name: 'Distillation',
    latinName: 'Destillatio',
    color: 'cyan',
    element: 'Light',
    symbol: '✨',
    description: 'The purification and refinement of essence.',
    process: 'Heat purifies. Only the purest essence rises and condenses.',
    psychological: 'Refinement of insight and awareness. Distilling wisdom from experience.',
    signs: ['Purity', 'Clarity', 'Refined awareness', 'Higher perception', 'Wisdom crystallizing'],
    practices: ['Advanced meditation', 'Contemplation', 'Fasting', 'Silence', 'Hermitage'],
    shadow: 'Perfectionism, spiritual pride, over-refinement'
  },
  {
    id: 7,
    name: 'Coagulation',
    latinName: 'Coagulatio',
    color: 'gold',
    element: 'Gold',
    symbol: '✧',
    description: 'The final solidification of the Philosophers Stone.',
    process: 'Spirit becomes matter. The gold is fixed and eternal.',
    psychological: 'Embodied enlightenment. Living wisdom in the world.',
    signs: ['Embodiment', 'Service', 'Presence', 'Teaching', 'Radiance', 'Equanimity'],
    practices: ['Living the truth', 'Service', 'Teaching', 'Being presence', 'Walking the path'],
    shadow: 'Rigidity, attachment to attainment, loss of beginner mind'
  }
]

// ============================================================================
// STAGE VISUALIZATION
// ============================================================================

function StageVisualization({ 
  currentStage,
  entries,
  onStageClick 
}: { 
  currentStage: number
  entries: TransformationEntry[]
  onStageClick: (stageId: number) => void
}) {
  return (
    <div className="relative">
      {/* Vertical progression */}
      <div className="space-y-4">
        {ALCHEMICAL_STAGES.map((stage, i) => {
          const hasEntries = entries.some(e => e.stageId === stage.id)
          const isCurrent = currentStage === stage.id
          const isPast = stage.id < currentStage
          const stageEntryCount = entries.filter(e => e.stageId === stage.id).length
          
          return (
            <button
              key={stage.id}
              onClick={() => onStageClick(stage.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-lg transition-all ${
                isCurrent 
                  ? `bg-${stage.color}-500/20 border border-${stage.color}-500/50 ring-2 ring-${stage.color}-500/30` 
                  : isPast
                    ? 'bg-zinc-800/50'
                    : 'bg-zinc-900/50 opacity-60'
              }`}
            >
              {/* Stage number and symbol */}
              <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl ${
                isCurrent ? `bg-${stage.color}-500/30` : 'bg-zinc-800'
              }`}>
                {stage.symbol}
              </div>
              
              {/* Stage info */}
              <div className="flex-1 text-left">
                <div className="flex items-center gap-2">
                  <span className={`text-${stage.color}-400 font-bold`}>{stage.id}.</span>
                  <span className={`font-medium ${isCurrent ? `text-${stage.color}-400` : 'text-zinc-300'}`}>
                    {stage.name}
                  </span>
                  <span className="text-xs text-zinc-500 italic">{stage.latinName}</span>
                </div>
                <p className="text-xs text-zinc-500 mt-1">{stage.element} • {stage.process.slice(0, 50)}...</p>
              </div>
              
              {/* Status */}
              <div className="text-right">
                {hasEntries && (
                  <span className="text-xs text-amber-400">{stageEntryCount} entries</span>
                )}
                {isCurrent && (
                  <span className={`block text-xs text-${stage.color}-400`}>Current</span>
                )}
                {isPast && !isCurrent && (
                  <span className="block text-xs text-emerald-400">✓</span>
                )}
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

// ============================================================================
// STAGE DETAIL
// ============================================================================

function StageDetail({
  stage,
  entries,
  onAddEntry,
  onClose
}: {
  stage: AlchemicalStage
  entries: TransformationEntry[]
  onAddEntry: (entry: Omit<TransformationEntry, 'id' | 'timestamp'>) => void
  onClose: () => void
}) {
  const [showForm, setShowForm] = useState(false)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [whatDied, setWhatDied] = useState('')
  const [whatBorn, setWhatBorn] = useState('')
  const [insights, setInsights] = useState('')
  
  const stageEntries = entries.filter(e => e.stageId === stage.id)
  
  const handleSubmit = () => {
    if (!description.trim()) return
    
    onAddEntry({
      stageId: stage.id,
      title: title || `${stage.name} Entry`,
      description,
      whatDied: whatDied || undefined,
      whatBorn: whatBorn || undefined,
      insights: insights.split('\n').filter(i => i.trim()),
      practices: []
    })
    
    setShowForm(false)
    setTitle('')
    setDescription('')
    setWhatDied('')
    setWhatBorn('')
    setInsights('')
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center text-3xl bg-${stage.color}-500/20`}>
            {stage.symbol}
          </div>
          <div>
            <h2 className={`text-2xl font-bold text-${stage.color}-400`}>{stage.name}</h2>
            <p className="text-sm text-zinc-500 italic">{stage.latinName} • {stage.element}</p>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      <p className="text-zinc-300 mb-4">{stage.description}</p>
      
      {/* Process */}
      <div className={`p-4 mb-6 bg-${stage.color}-500/10 rounded-lg`}>
        <p className={`text-sm text-${stage.color}-400 mb-1`}>The Process</p>
        <p className="text-zinc-200">{stage.process}</p>
      </div>
      
      {/* Psychological Meaning */}
      <div className="p-4 mb-6 bg-purple-500/10 rounded-lg">
        <p className="text-sm text-purple-400 mb-1">Psychological Meaning</p>
        <p className="text-zinc-200">{stage.psychological}</p>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        {/* Signs */}
        <div className="p-4 bg-zinc-800/50 rounded-lg">
          <p className="text-sm text-cyan-400 mb-2">Signs You're in This Stage</p>
          <ul className="space-y-1">
            {stage.signs.map((sign, i) => (
              <li key={i} className="text-sm text-zinc-300">• {sign}</li>
            ))}
          </ul>
        </div>
        
        {/* Practices */}
        <div className="p-4 bg-zinc-800/50 rounded-lg">
          <p className="text-sm text-emerald-400 mb-2">Practices for This Stage</p>
          <ul className="space-y-1">
            {stage.practices.map((practice, i) => (
              <li key={i} className="text-sm text-zinc-300">• {practice}</li>
            ))}
          </ul>
        </div>
      </div>
      
      {/* Shadow */}
      <div className="p-4 mb-6 bg-red-500/10 rounded-lg">
        <p className="text-sm text-red-400 mb-1">Shadow of This Stage</p>
        <p className="text-sm text-zinc-300">{stage.shadow}</p>
      </div>
      
      {/* Entry Form */}
      {showForm ? (
        <div className="space-y-4 mb-6 p-4 bg-zinc-800/50 rounded-lg">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Entry title..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe your experience in this stage..."
            rows={3}
            className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              value={whatDied}
              onChange={(e) => setWhatDied(e.target.value)}
              placeholder="What died/transformed?"
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
            <input
              type="text"
              value={whatBorn}
              onChange={(e) => setWhatBorn(e.target.value)}
              placeholder="What was born/emerged?"
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
            />
          </div>
          <textarea
            value={insights}
            onChange={(e) => setInsights(e.target.value)}
            placeholder="Insights (one per line)..."
            rows={2}
            className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
          />
          <div className="flex gap-2">
            <button onClick={() => setShowForm(false)} className="flex-1 py-2 bg-zinc-700 text-zinc-300 rounded-lg">
              Cancel
            </button>
            <button onClick={handleSubmit} className={`flex-1 py-2 bg-${stage.color}-500 text-white rounded-lg`}>
              Save Entry
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className={`w-full py-3 mb-6 cascade-card text-center text-zinc-400 hover:text-${stage.color}-400`}
        >
          + Add Entry for {stage.name}
        </button>
      )}
      
      {/* Stage Entries */}
      {stageEntries.length > 0 && (
        <div>
          <p className="text-sm text-zinc-400 mb-2">Your journey through {stage.name}:</p>
          <div className="space-y-2">
            {stageEntries.map(entry => (
              <div key={entry.id} className="p-3 bg-zinc-800/50 rounded-lg">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>{entry.title}</span>
                  <span>{new Date(entry.timestamp).toLocaleDateString()}</span>
                </div>
                <p className="text-sm text-zinc-300 line-clamp-2">{entry.description}</p>
                {(entry.whatDied || entry.whatBorn) && (
                  <div className="flex gap-4 mt-2 text-xs">
                    {entry.whatDied && <span className="text-red-400">Died: {entry.whatDied}</span>}
                    {entry.whatBorn && <span className="text-emerald-400">Born: {entry.whatBorn}</span>}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function AlchemyPage() {
  const [journeys, setJourneys] = useState<AlchemicalJourney[]>([])
  const [activeJourney, setActiveJourney] = useState<AlchemicalJourney | null>(null)
  const [selectedStage, setSelectedStage] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [newJourneyName, setNewJourneyName] = useState('')
  const [newJourneyIntention, setNewJourneyIntention] = useState('')
  
  // Load journeys
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-alchemy')
      if (saved) {
        const parsed = JSON.parse(saved)
        setJourneys(parsed)
        if (parsed.length > 0 && !parsed[0].completedAt) {
          setActiveJourney(parsed[0])
        }
      }
    }
  }, [])
  
  const createJourney = () => {
    if (!newJourneyName.trim()) return
    
    const newJourney: AlchemicalJourney = {
      id: `alchemy-${Date.now()}`,
      name: newJourneyName,
      intention: newJourneyIntention,
      currentStage: 1,
      entries: [],
      startedAt: Date.now()
    }
    
    const updated = [newJourney, ...journeys]
    setJourneys(updated)
    setActiveJourney(newJourney)
    localStorage.setItem('cascade-alchemy', JSON.stringify(updated))
    setShowCreate(false)
    setNewJourneyName('')
    setNewJourneyIntention('')
  }
  
  const addEntry = (entry: Omit<TransformationEntry, 'id' | 'timestamp'>) => {
    if (!activeJourney) return
    
    const newEntry: TransformationEntry = {
      ...entry,
      id: `entry-${Date.now()}`,
      timestamp: Date.now()
    }
    
    const updatedJourney = {
      ...activeJourney,
      entries: [...activeJourney.entries, newEntry]
    }
    
    const updatedJourneys = journeys.map(j => 
      j.id === activeJourney.id ? updatedJourney : j
    )
    
    setActiveJourney(updatedJourney)
    setJourneys(updatedJourneys)
    localStorage.setItem('cascade-alchemy', JSON.stringify(updatedJourneys))
  }
  
  const advanceStage = () => {
    if (!activeJourney || activeJourney.currentStage >= 7) return
    
    const updatedJourney = {
      ...activeJourney,
      currentStage: activeJourney.currentStage + 1,
      completedAt: activeJourney.currentStage === 6 ? Date.now() : undefined
    }
    
    const updatedJourneys = journeys.map(j => 
      j.id === activeJourney.id ? updatedJourney : j
    )
    
    setActiveJourney(updatedJourney)
    setJourneys(updatedJourneys)
    localStorage.setItem('cascade-alchemy', JSON.stringify(updatedJourneys))
  }
  
  const currentStageData = activeJourney 
    ? ALCHEMICAL_STAGES[activeJourney.currentStage - 1] 
    : null
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Alchemical Transformation</h1>
        <p className="text-zinc-500">Track your transformation through the seven classical stages</p>
      </header>
      
      {!activeJourney && !showCreate ? (
        <div className="cascade-card p-12 text-center">
          <p className="text-4xl mb-4">⚗️</p>
          <p className="text-zinc-400 mb-4">No active transformation</p>
          <button
            onClick={() => setShowCreate(true)}
            className="px-6 py-3 bg-gradient-to-r from-amber-500 to-red-500 text-white font-medium rounded-lg"
          >
            Begin the Great Work
          </button>
        </div>
      ) : showCreate ? (
        <div className="cascade-card p-6 max-w-lg mx-auto">
          <h2 className="text-xl font-bold text-zinc-100 mb-6">Begin Alchemical Journey</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-400 mb-2">Transformation Name</label>
              <input
                type="text"
                value={newJourneyName}
                onChange={(e) => setNewJourneyName(e.target.value)}
                placeholder="e.g., Career Transmutation, Relationship Alchemy..."
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-400 mb-2">Intention - What lead are you turning to gold?</label>
              <textarea
                value={newJourneyIntention}
                onChange={(e) => setNewJourneyIntention(e.target.value)}
                placeholder="What do you seek to transform?"
                rows={3}
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
              />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowCreate(false)} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
                Cancel
              </button>
              <button onClick={createJourney} className="flex-1 py-3 bg-amber-500 text-white rounded-lg">
                Begin Great Work
              </button>
            </div>
          </div>
        </div>
      ) : activeJourney && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Stage Progression */}
          <div className="cascade-card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-medium text-zinc-200">{activeJourney.name}</h3>
                <p className="text-sm text-zinc-500">Started {new Date(activeJourney.startedAt).toLocaleDateString()}</p>
              </div>
              {activeJourney.currentStage < 7 && (
                <button
                  onClick={advanceStage}
                  className="px-4 py-2 bg-amber-500/20 text-amber-400 rounded-lg text-sm"
                >
                  Advance Stage →
                </button>
              )}
            </div>
            
            {activeJourney.intention && (
              <div className="mb-4 p-3 bg-zinc-800/50 rounded-lg">
                <p className="text-xs text-zinc-500 mb-1">Intention:</p>
                <p className="text-sm text-zinc-300 italic">"{activeJourney.intention}"</p>
              </div>
            )}
            
            <StageVisualization
              currentStage={activeJourney.currentStage}
              entries={activeJourney.entries}
              onStageClick={setSelectedStage}
            />
          </div>
          
          {/* Stage Detail */}
          {selectedStage ? (
            <StageDetail
              stage={ALCHEMICAL_STAGES[selectedStage - 1]}
              entries={activeJourney.entries}
              onAddEntry={addEntry}
              onClose={() => setSelectedStage(null)}
            />
          ) : currentStageData && (
            <StageDetail
              stage={currentStageData}
              entries={activeJourney.entries}
              onAddEntry={addEntry}
              onClose={() => {}}
            />
          )}
        </div>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-amber-500/5 to-red-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">⚗️ The Great Work</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "V.I.T.R.I.O.L. - Visit the interior of the earth, and by rectifying, you will find the hidden stone."
        </p>
        <p className="text-sm text-zinc-500">
          The alchemists spoke of transforming lead into gold, but the real work was always internal. 
          Every stage of the alchemical process maps to stages of psychological transformation. 
          By tracking your journey through these archetypal stages, you gain perspective on where 
          you are in the process of becoming who you truly are.
        </p>
      </div>
    </div>
  )
}
