'use client'

import { useState, useEffect, useCallback } from 'react'

// ============================================================================
// TYPES
// ============================================================================

type NervousSystemState = 
  | 'ventral_vagal'   // Safe & social (green)
  | 'sympathetic'     // Fight/flight (yellow/orange)
  | 'dorsal_vagal'    // Freeze/shutdown (blue/gray)
  | 'blended_play'    // Ventral + sympathetic (playful)
  | 'blended_stillness' // Ventral + dorsal (peaceful rest)

interface StateEntry {
  id: string
  state: NervousSystemState
  intensity: number  // 1-10
  triggers?: string[]
  bodySensations: string[]
  thoughts: string[]
  behaviors: string[]
  regulation?: string  // What helped return to ventral
  context?: string
  timestamp: number
}

interface RegulationTool {
  id: string
  name: string
  description: string
  category: 'breath' | 'movement' | 'social' | 'sensory' | 'cognitive'
  forStates: NervousSystemState[]
  duration: string
  instructions: string[]
}

interface StatePattern {
  state: NervousSystemState
  count: number
  avgIntensity: number
  commonTriggers: string[]
  effectiveRegulations: string[]
}

// ============================================================================
// CONSTANTS
// ============================================================================

const STATE_INFO: Record<NervousSystemState, {
  name: string
  color: string
  icon: string
  description: string
  sensations: string[]
  thoughts: string[]
  behaviors: string[]
}> = {
  ventral_vagal: {
    name: 'Ventral Vagal',
    color: 'emerald',
    icon: '💚',
    description: 'Safe, social, connected. The optimal state for engagement and growth.',
    sensations: ['Relaxed muscles', 'Easy breathing', 'Warm', 'Open chest', 'Grounded feet'],
    thoughts: ['I am safe', 'I can handle this', 'I feel connected', 'Things will work out'],
    behaviors: ['Eye contact', 'Soft voice', 'Open posture', 'Curious', 'Playful']
  },
  sympathetic: {
    name: 'Sympathetic',
    color: 'amber',
    icon: '⚡',
    description: 'Fight or flight. Mobilized for action, heightened alertness.',
    sensations: ['Racing heart', 'Tight chest', 'Shallow breath', 'Tension', 'Heat'],
    thoughts: ['I need to act', 'Something is wrong', 'I must escape', 'Danger'],
    behaviors: ['Restless', 'Aggressive', 'Anxious', 'Scanning', 'Defensive']
  },
  dorsal_vagal: {
    name: 'Dorsal Vagal',
    color: 'blue',
    icon: '🧊',
    description: 'Freeze or shutdown. Conservation mode, disconnection.',
    sensations: ['Numb', 'Heavy', 'Cold', 'Foggy', 'Disconnected', 'Exhausted'],
    thoughts: ['I can\'t', 'Nothing matters', 'I\'m helpless', 'I want to disappear'],
    behaviors: ['Withdrawn', 'Collapsed', 'Dissociated', 'Flat affect', 'Isolation']
  },
  blended_play: {
    name: 'Play State',
    color: 'pink',
    icon: '🎮',
    description: 'Ventral + sympathetic. Safe activation for play, competition, passion.',
    sensations: ['Energized', 'Excited', 'Light', 'Alive', 'Buzzing'],
    thoughts: ['This is fun', 'I\'m excited', 'Let\'s go!', 'I\'m in the zone'],
    behaviors: ['Playful aggression', 'Laughter', 'Movement', 'Competition', 'Dancing']
  },
  blended_stillness: {
    name: 'Stillness State',
    color: 'indigo',
    icon: '🧘',
    description: 'Ventral + dorsal. Safe immobilization for intimacy, rest, meditation.',
    sensations: ['Peaceful', 'Still', 'Soft', 'Quiet', 'Melting'],
    thoughts: ['I am held', 'Deep peace', 'Safe to rest', 'Connected in stillness'],
    behaviors: ['Cuddling', 'Meditation', 'Deep rest', 'Intimacy', 'Surrender']
  }
}

const REGULATION_TOOLS: RegulationTool[] = [
  {
    id: 'voo-breath',
    name: 'Voo Breath',
    description: 'Activate the ventral vagus through deep vibration',
    category: 'breath',
    forStates: ['sympathetic', 'dorsal_vagal'],
    duration: '2-5 min',
    instructions: [
      'Take a deep breath in',
      'On the exhale, make a long "Voooo" sound',
      'Feel the vibration in your chest and belly',
      'Repeat 5-10 times',
      'Notice what shifts'
    ]
  },
  {
    id: 'physiological-sigh',
    name: 'Physiological Sigh',
    description: 'Rapid calm-down through double inhale',
    category: 'breath',
    forStates: ['sympathetic'],
    duration: '1 min',
    instructions: [
      'Inhale through nose',
      'Take a second short inhale on top',
      'Long slow exhale through mouth',
      'Repeat 3-5 times',
      'Feel heart rate slow'
    ]
  },
  {
    id: 'cold-water',
    name: 'Cold Water on Face',
    description: 'Trigger the dive reflex to activate vagus',
    category: 'sensory',
    forStates: ['sympathetic'],
    duration: '30 sec',
    instructions: [
      'Get very cold water',
      'Splash on face, especially forehead and cheeks',
      'Or hold cold pack to face',
      'Hold breath briefly',
      'Notice the shift'
    ]
  },
  {
    id: 'shake-it-off',
    name: 'Shake It Off',
    description: 'Discharge trapped energy through movement',
    category: 'movement',
    forStates: ['sympathetic', 'dorsal_vagal'],
    duration: '2-3 min',
    instructions: [
      'Stand with feet hip-width apart',
      'Begin shaking hands and arms',
      'Let shaking spread to whole body',
      'Shake vigorously for 2-3 minutes',
      'Slow down gradually and notice'
    ]
  },
  {
    id: 'orient-to-room',
    name: 'Orient to Present',
    description: 'Use vision to signal safety to nervous system',
    category: 'sensory',
    forStates: ['sympathetic', 'dorsal_vagal'],
    duration: '1-2 min',
    instructions: [
      'Slowly turn your head to look around',
      'Name 5 things you can see',
      'Really look at colors, textures',
      'Let your eyes land on something pleasant',
      'Notice your body settling'
    ]
  },
  {
    id: 'social-engagement',
    name: 'Safe Social Connection',
    description: 'Activate ventral through co-regulation',
    category: 'social',
    forStates: ['sympathetic', 'dorsal_vagal'],
    duration: '5+ min',
    instructions: [
      'Connect with a safe person',
      'Make eye contact',
      'Listen to their voice',
      'Allow yourself to receive their presence',
      'Notice the regulation happening'
    ]
  },
  {
    id: 'gentle-movement',
    name: 'Gentle Movement',
    description: 'Slowly mobilize out of freeze',
    category: 'movement',
    forStates: ['dorsal_vagal'],
    duration: '5-10 min',
    instructions: [
      'Start with small movements - fingers, toes',
      'Gradually increase - rotate wrists, ankles',
      'Rock gently side to side',
      'Slow walking, feeling feet',
      'Move at the pace that feels safe'
    ]
  },
  {
    id: 'humming',
    name: 'Humming/Singing',
    description: 'Stimulate vagus through vocalization',
    category: 'breath',
    forStates: ['sympathetic', 'dorsal_vagal'],
    duration: '2-5 min',
    instructions: [
      'Hum your favorite tune',
      'Or sing, chant, or make any sounds',
      'Feel the vibration in throat and chest',
      'Let the sound be as long as feels good',
      'Notice shifts in your body'
    ]
  }
]

// ============================================================================
// STATE LADDER VISUALIZATION
// ============================================================================

function StateLadder({ 
  currentState,
  onStateSelect 
}: { 
  currentState: NervousSystemState
  onStateSelect: (state: NervousSystemState) => void
}) {
  const states: NervousSystemState[] = [
    'ventral_vagal',
    'blended_play',
    'sympathetic',
    'blended_stillness',
    'dorsal_vagal'
  ]
  
  return (
    <div className="relative py-4">
      {/* Ladder line */}
      <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-emerald-500 via-amber-500 to-blue-500 -translate-x-1/2" />
      
      {states.map((state, i) => {
        const info = STATE_INFO[state]
        const isActive = currentState === state
        
        return (
          <button
            key={state}
            onClick={() => onStateSelect(state)}
            className={`relative w-full flex items-center gap-4 p-4 my-2 rounded-lg transition-all ${
              isActive 
                ? `bg-${info.color}-500/20 border border-${info.color}-500/50` 
                : 'hover:bg-zinc-800'
            }`}
          >
            {/* Indicator dot */}
            <div 
              className={`absolute left-1/2 -translate-x-1/2 w-4 h-4 rounded-full ${
                isActive ? `bg-${info.color}-500 ring-4 ring-${info.color}-500/30` : 'bg-zinc-700'
              }`}
            />
            
            {/* Left content */}
            <div className={`flex-1 text-right pr-8 ${i % 2 === 0 ? '' : 'invisible'}`}>
              <p className={`font-medium ${isActive ? `text-${info.color}-400` : 'text-zinc-400'}`}>
                {info.icon} {info.name}
              </p>
              <p className="text-xs text-zinc-500 line-clamp-1">{info.description}</p>
            </div>
            
            {/* Right content */}
            <div className={`flex-1 text-left pl-8 ${i % 2 === 1 ? '' : 'invisible'}`}>
              <p className={`font-medium ${isActive ? `text-${info.color}-400` : 'text-zinc-400'}`}>
                {info.icon} {info.name}
              </p>
              <p className="text-xs text-zinc-500 line-clamp-1">{info.description}</p>
            </div>
          </button>
        )
      })}
    </div>
  )
}

// ============================================================================
// REGULATION TOOL CARD
// ============================================================================

function ToolCard({ 
  tool, 
  onUse 
}: { 
  tool: RegulationTool
  onUse: () => void 
}) {
  const [expanded, setExpanded] = useState(false)
  
  const categoryColors = {
    breath: 'cyan',
    movement: 'amber',
    social: 'pink',
    sensory: 'purple',
    cognitive: 'emerald'
  }
  
  return (
    <div className={`cascade-card p-4 border-l-4 border-${categoryColors[tool.category]}-500`}>
      <div className="flex items-start justify-between mb-2">
        <div>
          <h4 className="font-medium text-zinc-200">{tool.name}</h4>
          <p className="text-xs text-zinc-500">{tool.duration}</p>
        </div>
        <span className={`text-xs px-2 py-0.5 rounded bg-${categoryColors[tool.category]}-500/20 text-${categoryColors[tool.category]}-400`}>
          {tool.category}
        </span>
      </div>
      
      <p className="text-sm text-zinc-400 mb-3">{tool.description}</p>
      
      {expanded && (
        <div className="mb-3 p-3 bg-zinc-800/50 rounded-lg">
          <p className="text-xs text-zinc-500 mb-2">Instructions:</p>
          <ol className="space-y-1">
            {tool.instructions.map((step, i) => (
              <li key={i} className="text-sm text-zinc-300">{i + 1}. {step}</li>
            ))}
          </ol>
        </div>
      )}
      
      <div className="flex gap-2">
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-sm"
        >
          {expanded ? 'Hide' : 'Show'} Instructions
        </button>
        <button
          onClick={onUse}
          className={`flex-1 py-2 bg-${categoryColors[tool.category]}-500/20 text-${categoryColors[tool.category]}-400 rounded text-sm`}
        >
          Use This
        </button>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function PolyvagalPage() {
  const [entries, setEntries] = useState<StateEntry[]>([])
  const [currentState, setCurrentState] = useState<NervousSystemState>('ventral_vagal')
  const [intensity, setIntensity] = useState(5)
  const [context, setContext] = useState('')
  const [showLog, setShowLog] = useState(false)
  
  // Load entries
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-polyvagal')
      if (saved) {
        const parsed = JSON.parse(saved)
        setEntries(parsed)
        // Set current state from most recent entry
        if (parsed.length > 0) {
          setCurrentState(parsed[0].state)
        }
      }
    }
  }, [])
  
  const logState = useCallback(() => {
    const info = STATE_INFO[currentState]
    const newEntry: StateEntry = {
      id: `pv-${Date.now()}`,
      state: currentState,
      intensity,
      bodySensations: info.sensations.slice(0, 2),
      thoughts: info.thoughts.slice(0, 1),
      behaviors: info.behaviors.slice(0, 1),
      context: context || undefined,
      timestamp: Date.now()
    }
    
    const updated = [newEntry, ...entries]
    setEntries(updated)
    localStorage.setItem('cascade-polyvagal', JSON.stringify(updated))
    setContext('')
    setShowLog(false)
  }, [currentState, intensity, context, entries])
  
  const logRegulation = (toolName: string) => {
    if (entries.length === 0) return
    
    const lastEntry = entries[0]
    const updatedEntry = {
      ...lastEntry,
      regulation: toolName
    }
    
    const updated = [updatedEntry, ...entries.slice(1)]
    setEntries(updated)
    localStorage.setItem('cascade-polyvagal', JSON.stringify(updated))
  }
  
  // Get tools for current state
  const relevantTools = REGULATION_TOOLS.filter(t => 
    t.forStates.includes(currentState)
  )
  
  // Stats
  const stateInfo = STATE_INFO[currentState]
  const recentStates = entries.slice(0, 20)
  const ventralPercent = recentStates.length > 0
    ? Math.round(recentStates.filter(e => e.state === 'ventral_vagal' || e.state === 'blended_play' || e.state === 'blended_stillness').length / recentStates.length * 100)
    : 0
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Polyvagal Dashboard</h1>
        <p className="text-zinc-500">Understand and regulate your nervous system</p>
      </header>
      
      {/* Current State Display */}
      <div className={`cascade-card p-6 mb-8 bg-gradient-to-r from-${stateInfo.color}-500/10 to-transparent border-l-4 border-${stateInfo.color}-500`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-zinc-500 mb-1">Current State</p>
            <h2 className={`text-2xl font-bold text-${stateInfo.color}-400`}>
              {stateInfo.icon} {stateInfo.name}
            </h2>
            <p className="text-sm text-zinc-400 mt-1">{stateInfo.description}</p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-zinc-200">{ventralPercent}%</p>
            <p className="text-xs text-zinc-500">Ventral Time (last 20)</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* State Ladder */}
        <div className="cascade-card p-6">
          <h3 className="text-lg font-medium text-zinc-200 mb-4">State Ladder</h3>
          <StateLadder 
            currentState={currentState} 
            onStateSelect={setCurrentState}
          />
          
          {/* Log Button */}
          {showLog ? (
            <div className="mt-4 space-y-3">
              <div>
                <label className="block text-sm text-zinc-400 mb-1">Intensity</label>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={intensity}
                  onChange={(e) => setIntensity(parseInt(e.target.value))}
                  className="w-full"
                />
                <p className="text-center text-sm text-zinc-400">{intensity}/10</p>
              </div>
              <input
                type="text"
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="What triggered this? (optional)"
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 text-sm"
              />
              <div className="flex gap-2">
                <button
                  onClick={() => setShowLog(false)}
                  className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded-lg text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={logState}
                  className={`flex-1 py-2 bg-${stateInfo.color}-500 text-white rounded-lg text-sm`}
                >
                  Log State
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowLog(true)}
              className="w-full mt-4 py-3 cascade-card text-center text-zinc-400 hover:text-cyan-400"
            >
              + Log Current State
            </button>
          )}
        </div>
        
        {/* Regulation Tools */}
        <div className="lg:col-span-2 space-y-6">
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">
              Regulation Tools for {stateInfo.name}
            </h3>
            
            {relevantTools.length === 0 ? (
              <p className="text-sm text-zinc-500">
                You're in a good state! Regulation tools are shown when in sympathetic or dorsal states.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {relevantTools.map(tool => (
                  <ToolCard 
                    key={tool.id} 
                    tool={tool} 
                    onUse={() => logRegulation(tool.name)}
                  />
                ))}
              </div>
            )}
          </div>
          
          {/* State Characteristics */}
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">
              {stateInfo.name} Characteristics
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <p className="text-xs text-zinc-500 mb-2">Body Sensations</p>
                <div className="space-y-1">
                  {stateInfo.sensations.slice(0, 3).map((s, i) => (
                    <p key={i} className="text-sm text-zinc-300">• {s}</p>
                  ))}
                </div>
              </div>
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <p className="text-xs text-zinc-500 mb-2">Thoughts</p>
                <div className="space-y-1">
                  {stateInfo.thoughts.slice(0, 3).map((t, i) => (
                    <p key={i} className="text-sm text-zinc-300">• {t}</p>
                  ))}
                </div>
              </div>
              <div className="p-3 bg-zinc-800/50 rounded-lg">
                <p className="text-xs text-zinc-500 mb-2">Behaviors</p>
                <div className="space-y-1">
                  {stateInfo.behaviors.slice(0, 3).map((b, i) => (
                    <p key={i} className="text-sm text-zinc-300">• {b}</p>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Recent History */}
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">Recent States</h3>
            {entries.length === 0 ? (
              <p className="text-sm text-zinc-500">No states logged yet</p>
            ) : (
              <div className="flex gap-1 flex-wrap">
                {entries.slice(0, 30).map(entry => {
                  const info = STATE_INFO[entry.state]
                  return (
                    <div
                      key={entry.id}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center bg-${info.color}-500/30`}
                      title={`${info.name} - ${new Date(entry.timestamp).toLocaleString()}`}
                    >
                      <span className="text-sm">{info.icon}</span>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-emerald-500/5 to-blue-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🧠 Polyvagal Theory</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "Safety is the treatment." — Stephen Porges
        </p>
        <p className="text-sm text-zinc-500">
          Your autonomic nervous system constantly scans for safety or danger (neuroception). 
          Understanding which state you're in — and having tools to shift states — is foundational 
          to well-being. The goal isn't to always be calm, but to have flexibility to move up and 
          down the ladder as life requires, and to return to ventral when the challenge passes.
        </p>
      </div>
    </div>
  )
}
