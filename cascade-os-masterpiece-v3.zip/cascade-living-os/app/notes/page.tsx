'use client'

import { useState, useEffect, useRef } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface FieldNote {
  id: string
  content: string
  type: NoteType
  tags: string[]
  source?: 'meditation' | 'conversation' | 'reading' | 'dream' | 'walk' | 'shower' | 'random' | 'other'
  energy: number  // 1-10 how energized/inspired
  clarity: number // 1-10 how clear
  actionable: boolean
  linkedTo?: string[]  // IDs of related notes
  expanded?: string    // Expanded thoughts later
  timestamp: number
  starred: boolean
}

type NoteType = 
  | 'insight'      // Sudden understanding
  | 'download'     // Received information
  | 'question'     // Important question
  | 'connection'   // Link between ideas
  | 'warning'      // Intuitive caution
  | 'direction'    // Guidance received
  | 'memory'       // Important memory surfaced
  | 'idea'         // Creative idea
  | 'pattern'      // Pattern noticed
  | 'feeling'      // Important feeling

// ============================================================================
// CONSTANTS
// ============================================================================

const NOTE_TYPES: Record<NoteType, { label: string; icon: string; color: string }> = {
  insight: { label: 'Insight', icon: '💡', color: 'amber' },
  download: { label: 'Download', icon: '⚡', color: 'purple' },
  question: { label: 'Question', icon: '❓', color: 'cyan' },
  connection: { label: 'Connection', icon: '🔗', color: 'blue' },
  warning: { label: 'Warning', icon: '⚠️', color: 'red' },
  direction: { label: 'Direction', icon: '🧭', color: 'emerald' },
  memory: { label: 'Memory', icon: '📸', color: 'pink' },
  idea: { label: 'Idea', icon: '🎯', color: 'orange' },
  pattern: { label: 'Pattern', icon: '🔮', color: 'indigo' },
  feeling: { label: 'Feeling', icon: '💗', color: 'rose' }
}

const SOURCE_INFO: Record<NonNullable<FieldNote['source']>, { icon: string }> = {
  meditation: { icon: '🧘' },
  conversation: { icon: '💬' },
  reading: { icon: '📖' },
  dream: { icon: '🌙' },
  walk: { icon: '🚶' },
  shower: { icon: '🚿' },
  random: { icon: '✨' },
  other: { icon: '📝' }
}

// ============================================================================
// QUICK CAPTURE
// ============================================================================

function QuickCapture({ onSave }: { onSave: (note: Omit<FieldNote, 'id' | 'timestamp' | 'starred'>) => void }) {
  const [content, setContent] = useState('')
  const [type, setType] = useState<NoteType>('insight')
  const [expanded, setExpanded] = useState(false)
  const [energy, setEnergy] = useState(7)
  const [clarity, setClarity] = useState(7)
  const [source, setSource] = useState<FieldNote['source']>('random')
  const [tags, setTags] = useState('')
  const [actionable, setActionable] = useState(false)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  
  useEffect(() => {
    inputRef.current?.focus()
  }, [])
  
  const handleSave = () => {
    if (!content.trim()) return
    
    onSave({
      content,
      type,
      energy,
      clarity,
      source,
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      actionable
    })
    
    setContent('')
    setTags('')
    setExpanded(false)
    inputRef.current?.focus()
  }
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.metaKey) {
      handleSave()
    }
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-2xl">{NOTE_TYPES[type].icon}</span>
        <h2 className="text-lg font-medium text-zinc-200">Quick Capture</h2>
        <span className="text-xs text-zinc-500 ml-auto">⌘+Enter to save</span>
      </div>
      
      {/* Main input */}
      <textarea
        ref={inputRef}
        value={content}
        onChange={(e) => setContent(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Capture the insight before it fades..."
        rows={3}
        className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none mb-4"
      />
      
      {/* Type selection */}
      <div className="flex flex-wrap gap-2 mb-4">
        {(Object.entries(NOTE_TYPES) as [NoteType, typeof NOTE_TYPES[NoteType]][]).map(([key, info]) => (
          <button
            key={key}
            onClick={() => setType(key)}
            className={`px-3 py-1.5 rounded-full text-sm transition-all ${
              type === key
                ? `bg-${info.color}-500/20 text-${info.color}-400 border border-${info.color}-500/50`
                : 'bg-zinc-800 text-zinc-500 hover:bg-zinc-700'
            }`}
          >
            {info.icon} {info.label}
          </button>
        ))}
      </div>
      
      {/* Expand for more options */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="text-xs text-zinc-500 mb-4"
      >
        {expanded ? '− Less options' : '+ More options'}
      </button>
      
      {expanded && (
        <div className="space-y-4 mb-4 p-4 bg-zinc-800/50 rounded-lg">
          {/* Source */}
          <div>
            <p className="text-xs text-zinc-400 mb-2">Source</p>
            <div className="flex flex-wrap gap-2">
              {(Object.entries(SOURCE_INFO) as [NonNullable<FieldNote['source']>, { icon: string }][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setSource(key)}
                  className={`px-2 py-1 rounded text-xs ${
                    source === key ? 'bg-cyan-500/20 text-cyan-400' : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {info.icon} {key}
                </button>
              ))}
            </div>
          </div>
          
          {/* Energy & Clarity */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400">Energy</span>
                <span className="text-amber-400">{energy}</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={energy}
                onChange={(e) => setEnergy(parseInt(e.target.value))}
                className="w-full"
              />
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400">Clarity</span>
                <span className="text-cyan-400">{clarity}</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={clarity}
                onChange={(e) => setClarity(parseInt(e.target.value))}
                className="w-full"
              />
            </div>
          </div>
          
          {/* Tags */}
          <div>
            <p className="text-xs text-zinc-400 mb-2">Tags (comma separated)</p>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="creativity, work, relationship..."
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded text-zinc-200 text-sm"
            />
          </div>
          
          {/* Actionable */}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={actionable}
              onChange={(e) => setActionable(e.target.checked)}
              className="rounded"
            />
            <span className="text-sm text-zinc-400">This is actionable</span>
          </label>
        </div>
      )}
      
      <button
        onClick={handleSave}
        disabled={!content.trim()}
        className="w-full py-3 bg-gradient-to-r from-amber-500 to-purple-500 text-zinc-900 font-medium rounded-lg disabled:opacity-50"
      >
        Capture
      </button>
    </div>
  )
}

// ============================================================================
// NOTE CARD
// ============================================================================

function NoteCard({ 
  note, 
  onToggleStar,
  onExpand 
}: { 
  note: FieldNote
  onToggleStar: () => void
  onExpand: () => void
}) {
  const typeInfo = NOTE_TYPES[note.type]
  
  return (
    <div className={`cascade-card p-4 hover:border-${typeInfo.color}-500/20 transition-all`}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-lg">{typeInfo.icon}</span>
          <span className={`text-xs text-${typeInfo.color}-400`}>{typeInfo.label}</span>
          {note.source && (
            <span className="text-xs text-zinc-600">{SOURCE_INFO[note.source].icon}</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleStar}
            className={`text-lg ${note.starred ? 'text-amber-400' : 'text-zinc-600 hover:text-amber-400'}`}
          >
            {note.starred ? '★' : '☆'}
          </button>
          <span className="text-xs text-zinc-600">
            {new Date(note.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
      
      <p className="text-sm text-zinc-300 mb-3">{note.content}</p>
      
      {/* Metrics */}
      <div className="flex items-center gap-4 mb-2">
        <div className="flex items-center gap-1">
          <span className="text-xs text-zinc-500">Energy:</span>
          <div className="flex">
            {Array.from({ length: Math.ceil(note.energy / 2) }).map((_, i) => (
              <span key={i} className="text-amber-400 text-xs">⚡</span>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-xs text-zinc-500">Clarity:</span>
          <div className="flex">
            {Array.from({ length: Math.ceil(note.clarity / 2) }).map((_, i) => (
              <span key={i} className="text-cyan-400 text-xs">◆</span>
            ))}
          </div>
        </div>
        {note.actionable && (
          <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded text-xs">
            Actionable
          </span>
        )}
      </div>
      
      {/* Tags */}
      {note.tags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {note.tags.map(tag => (
            <span key={tag} className="px-2 py-0.5 bg-zinc-800 text-zinc-500 rounded text-xs">
              #{tag}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function FieldNotesPage() {
  const [notes, setNotes] = useState<FieldNote[]>([])
  const [filter, setFilter] = useState<NoteType | 'all' | 'starred'>('all')
  const [searchQuery, setSearchQuery] = useState('')
  
  // Load notes
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-field-notes')
      if (saved) setNotes(JSON.parse(saved))
    }
  }, [])
  
  const saveNote = (note: Omit<FieldNote, 'id' | 'timestamp' | 'starred'>) => {
    const newNote: FieldNote = {
      ...note,
      id: `note-${Date.now()}`,
      timestamp: Date.now(),
      starred: false
    }
    
    const updated = [newNote, ...notes]
    setNotes(updated)
    localStorage.setItem('cascade-field-notes', JSON.stringify(updated))
  }
  
  const toggleStar = (id: string) => {
    const updated = notes.map(n => 
      n.id === id ? { ...n, starred: !n.starred } : n
    )
    setNotes(updated)
    localStorage.setItem('cascade-field-notes', JSON.stringify(updated))
  }
  
  // Filter notes
  let filteredNotes = notes
  if (filter === 'starred') {
    filteredNotes = notes.filter(n => n.starred)
  } else if (filter !== 'all') {
    filteredNotes = notes.filter(n => n.type === filter)
  }
  
  if (searchQuery) {
    const query = searchQuery.toLowerCase()
    filteredNotes = filteredNotes.filter(n => 
      n.content.toLowerCase().includes(query) ||
      n.tags.some(t => t.toLowerCase().includes(query))
    )
  }
  
  // Group by date
  const groupedNotes: Record<string, FieldNote[]> = {}
  filteredNotes.forEach(note => {
    const date = new Date(note.timestamp).toLocaleDateString()
    if (!groupedNotes[date]) groupedNotes[date] = []
    groupedNotes[date].push(note)
  })
  
  // Stats
  const todayCount = notes.filter(n => 
    new Date(n.timestamp).toDateString() === new Date().toDateString()
  ).length
  const avgEnergy = notes.length > 0
    ? (notes.reduce((sum, n) => sum + n.energy, 0) / notes.length).toFixed(1)
    : 0
  const topType = Object.entries(
    notes.reduce((acc, n) => {
      acc[n.type] = (acc[n.type] || 0) + 1
      return acc
    }, {} as Record<string, number>)
  ).sort((a, b) => b[1] - a[1])[0]
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Field Notes</h1>
        <p className="text-zinc-500">Capture insights before they fade</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{notes.length}</p>
          <p className="text-xs text-zinc-500">Total Notes</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{todayCount}</p>
          <p className="text-xs text-zinc-500">Today</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{avgEnergy}</p>
          <p className="text-xs text-zinc-500">Avg Energy</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-2xl">{topType ? NOTE_TYPES[topType[0] as NoteType]?.icon : '?'}</p>
          <p className="text-xs text-zinc-500">Most Common</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Capture */}
        <div className="lg:col-span-1">
          <QuickCapture onSave={saveNote} />
        </div>
        
        {/* Notes List */}
        <div className="lg:col-span-2">
          {/* Search & Filter */}
          <div className="mb-4 space-y-3">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notes..."
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
            
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setFilter('all')}
                className={`px-3 py-1 rounded-full text-sm ${
                  filter === 'all' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilter('starred')}
                className={`px-3 py-1 rounded-full text-sm ${
                  filter === 'starred' ? 'bg-amber-500/20 text-amber-400' : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                ★ Starred
              </button>
              {(Object.entries(NOTE_TYPES) as [NoteType, typeof NOTE_TYPES[NoteType]][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={`px-3 py-1 rounded-full text-sm ${
                    filter === key ? `bg-${info.color}-500/20 text-${info.color}-400` : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {info.icon}
                </button>
              ))}
            </div>
          </div>
          
          {/* Notes by date */}
          {Object.keys(groupedNotes).length === 0 ? (
            <div className="cascade-card p-12 text-center">
              <p className="text-4xl mb-4">📝</p>
              <p className="text-zinc-400">No field notes yet</p>
              <p className="text-sm text-zinc-600">Capture your first insight</p>
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(groupedNotes).map(([date, dateNotes]) => (
                <div key={date}>
                  <p className="text-sm text-zinc-500 mb-2">{date}</p>
                  <div className="space-y-3">
                    {dateNotes.map(note => (
                      <NoteCard
                        key={note.id}
                        note={note}
                        onToggleStar={() => toggleStar(note.id)}
                        onExpand={() => {}}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
