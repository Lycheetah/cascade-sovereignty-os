'use client'

import { useState, useEffect, useMemo } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface Prediction {
  id: string
  question: string         // What are you predicting?
  prediction: string       // Your prediction
  confidence: number       // 1-10 how confident
  basis: PredictionBasis   // What is this prediction based on?
  category: PredictionCategory
  timeframe: string        // When will we know?
  dueDate: number
  
  // Resolution
  resolved: boolean
  outcome?: string
  accuracy?: number        // 0-100 how accurate
  resolvedAt?: number
  
  // Learning
  lessonsLearned?: string
  calibrationNotes?: string
  
  createdAt: number
}

type PredictionBasis = 
  | 'intuition'    // Gut feeling
  | 'analysis'     // Logical analysis
  | 'pattern'      // Pattern recognition
  | 'information'  // Based on specific info
  | 'experience'   // Past experience
  | 'mixed'        // Combination

type PredictionCategory = 
  | 'personal'     // Personal life outcomes
  | 'relationship' // Relationship predictions
  | 'work'         // Professional predictions
  | 'world'        // World events
  | 'market'       // Market/financial
  | 'creative'     // Creative outcomes
  | 'other'

interface CalibrationStats {
  totalPredictions: number
  resolved: number
  avgConfidence: number
  avgAccuracy: number
  calibrationScore: number  // How well confidence matches accuracy
  overconfident: number     // Times too confident
  underconfident: number    // Times too unconfident
  wellCalibrated: number    // Times roughly right
}

// ============================================================================
// CONSTANTS
// ============================================================================

const BASIS_INFO: Record<PredictionBasis, { label: string; icon: string; color: string }> = {
  intuition: { label: 'Intuition', icon: '✨', color: 'purple' },
  analysis: { label: 'Analysis', icon: '🔬', color: 'cyan' },
  pattern: { label: 'Pattern', icon: '🔮', color: 'indigo' },
  information: { label: 'Information', icon: '📊', color: 'blue' },
  experience: { label: 'Experience', icon: '📚', color: 'amber' },
  mixed: { label: 'Mixed', icon: '🎯', color: 'emerald' }
}

const CATEGORY_INFO: Record<PredictionCategory, { label: string; icon: string }> = {
  personal: { label: 'Personal', icon: '👤' },
  relationship: { label: 'Relationship', icon: '💗' },
  work: { label: 'Work', icon: '💼' },
  world: { label: 'World', icon: '🌍' },
  market: { label: 'Market', icon: '📈' },
  creative: { label: 'Creative', icon: '🎨' },
  other: { label: 'Other', icon: '✧' }
}

// ============================================================================
// PREDICTION CARD
// ============================================================================

function PredictionCard({ 
  prediction, 
  onResolve,
  onSelect 
}: { 
  prediction: Prediction
  onResolve: () => void
  onSelect: () => void
}) {
  const basis = BASIS_INFO[prediction.basis]
  const category = CATEGORY_INFO[prediction.category]
  const isOverdue = !prediction.resolved && prediction.dueDate < Date.now()
  const daysLeft = Math.ceil((prediction.dueDate - Date.now()) / (1000 * 60 * 60 * 24))
  
  return (
    <div className={`cascade-card p-5 ${prediction.resolved ? 'opacity-80' : ''}`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">{category.icon}</span>
          <span className={`text-xs px-2 py-0.5 rounded-full bg-${basis.color}-500/20 text-${basis.color}-400`}>
            {basis.icon} {basis.label}
          </span>
        </div>
        {prediction.resolved ? (
          <span className={`text-xs px-2 py-0.5 rounded-full ${
            (prediction.accuracy || 0) >= 70 ? 'bg-emerald-500/20 text-emerald-400' :
            (prediction.accuracy || 0) >= 40 ? 'bg-amber-500/20 text-amber-400' :
            'bg-red-500/20 text-red-400'
          }`}>
            {prediction.accuracy}% accurate
          </span>
        ) : (
          <span className={`text-xs px-2 py-0.5 rounded-full ${
            isOverdue ? 'bg-red-500/20 text-red-400' :
            daysLeft <= 3 ? 'bg-amber-500/20 text-amber-400' :
            'bg-zinc-800 text-zinc-500'
          }`}>
            {isOverdue ? 'Overdue' : `${daysLeft}d left`}
          </span>
        )}
      </div>
      
      <p className="text-sm text-zinc-300 mb-2">{prediction.question}</p>
      
      <div className="p-2 bg-zinc-800/50 rounded mb-3">
        <p className="text-xs text-zinc-500 mb-1">Prediction:</p>
        <p className="text-sm text-zinc-200">{prediction.prediction}</p>
      </div>
      
      {/* Confidence */}
      <div className="flex items-center gap-2 mb-3">
        <span className="text-xs text-zinc-500">Confidence:</span>
        <div className="flex-1 h-2 bg-zinc-800 rounded-full overflow-hidden">
          <div 
            className={`h-full ${
              prediction.confidence >= 7 ? 'bg-emerald-500' :
              prediction.confidence >= 4 ? 'bg-amber-500' :
              'bg-red-500'
            }`}
            style={{ width: `${prediction.confidence * 10}%` }}
          />
        </div>
        <span className="text-xs font-bold text-zinc-400">{prediction.confidence}/10</span>
      </div>
      
      {/* Outcome if resolved */}
      {prediction.resolved && prediction.outcome && (
        <div className="p-2 bg-cyan-500/10 rounded mb-3">
          <p className="text-xs text-cyan-400 mb-1">Outcome:</p>
          <p className="text-sm text-zinc-300">{prediction.outcome}</p>
        </div>
      )}
      
      {/* Actions */}
      <div className="flex gap-2">
        {!prediction.resolved && (
          <button
            onClick={onResolve}
            className="flex-1 py-2 bg-cyan-500/20 text-cyan-400 rounded text-sm hover:bg-cyan-500/30"
          >
            Resolve
          </button>
        )}
        <button
          onClick={onSelect}
          className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-sm hover:bg-zinc-700"
        >
          Details
        </button>
      </div>
    </div>
  )
}

// ============================================================================
// CALIBRATION DISPLAY
// ============================================================================

function CalibrationDisplay({ stats }: { stats: CalibrationStats }) {
  return (
    <div className="cascade-card p-6">
      <h3 className="text-lg font-medium text-zinc-200 mb-4">📊 Calibration</h3>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="text-center">
          <p className="text-3xl font-bold text-cyan-400">{stats.avgConfidence.toFixed(0)}%</p>
          <p className="text-xs text-zinc-500">Avg Confidence</p>
        </div>
        <div className="text-center">
          <p className="text-3xl font-bold text-purple-400">{stats.avgAccuracy.toFixed(0)}%</p>
          <p className="text-xs text-zinc-500">Avg Accuracy</p>
        </div>
      </div>
      
      {/* Calibration visualization */}
      <div className="relative h-16 bg-zinc-800 rounded-lg overflow-hidden mb-4">
        <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-red-500/50 to-transparent w-1/3" />
        <div className="absolute inset-y-0 right-0 bg-gradient-to-l from-amber-500/50 to-transparent w-1/3" />
        <div className="absolute inset-y-0 left-1/3 right-1/3 bg-emerald-500/20" />
        
        {/* Marker */}
        <div 
          className="absolute top-1/2 -translate-y-1/2 w-2 h-8 bg-white rounded-full"
          style={{ 
            left: `${Math.min(95, Math.max(5, stats.calibrationScore))}%`,
          }}
        />
        
        <div className="absolute bottom-1 left-4 text-xs text-zinc-500">Overconfident</div>
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 text-xs text-emerald-400">Calibrated</div>
        <div className="absolute bottom-1 right-4 text-xs text-zinc-500">Underconfident</div>
      </div>
      
      {/* Breakdown */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="p-2 bg-red-500/10 rounded">
          <p className="font-bold text-red-400">{stats.overconfident}</p>
          <p className="text-zinc-500">Overconfident</p>
        </div>
        <div className="p-2 bg-emerald-500/10 rounded">
          <p className="font-bold text-emerald-400">{stats.wellCalibrated}</p>
          <p className="text-zinc-500">Calibrated</p>
        </div>
        <div className="p-2 bg-amber-500/10 rounded">
          <p className="font-bold text-amber-400">{stats.underconfident}</p>
          <p className="text-zinc-500">Underconfident</p>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// CREATE PREDICTION FORM
// ============================================================================

function CreatePredictionForm({
  onSave,
  onCancel
}: {
  onSave: (prediction: Omit<Prediction, 'id' | 'createdAt' | 'resolved'>) => void
  onCancel: () => void
}) {
  const [question, setQuestion] = useState('')
  const [prediction, setPrediction] = useState('')
  const [confidence, setConfidence] = useState(5)
  const [basis, setBasis] = useState<PredictionBasis>('intuition')
  const [category, setCategory] = useState<PredictionCategory>('personal')
  const [timeframe, setTimeframe] = useState('')
  const [dueDate, setDueDate] = useState('')
  
  const handleSubmit = () => {
    if (!question.trim() || !prediction.trim() || !dueDate) return
    
    onSave({
      question,
      prediction,
      confidence,
      basis,
      category,
      timeframe,
      dueDate: new Date(dueDate).getTime()
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Make a Prediction</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-2">What are you predicting?</label>
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Will X happen? What will be the outcome of Y?"
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Your Prediction</label>
          <textarea
            value={prediction}
            onChange={(e) => setPrediction(e.target.value)}
            placeholder="I predict that..."
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Category</label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.entries(CATEGORY_INFO) as [PredictionCategory, typeof CATEGORY_INFO[PredictionCategory]][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setCategory(key)}
                  className={`p-2 rounded-lg text-xs ${
                    category === key
                      ? 'bg-cyan-500/20 border border-cyan-500/50'
                      : 'bg-zinc-800 hover:bg-zinc-700'
                  }`}
                >
                  {info.icon} {info.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Basis</label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.entries(BASIS_INFO) as [PredictionBasis, typeof BASIS_INFO[PredictionBasis]][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setBasis(key)}
                  className={`p-2 rounded-lg text-xs ${
                    basis === key
                      ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                      : 'bg-zinc-800 hover:bg-zinc-700'
                  }`}
                >
                  {info.icon} {info.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Confidence (1-10)</label>
          <input
            type="range"
            min="1"
            max="10"
            value={confidence}
            onChange={(e) => setConfidence(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-zinc-600">
            <span>Wild guess</span>
            <span className={`font-bold ${
              confidence >= 7 ? 'text-emerald-400' :
              confidence >= 4 ? 'text-amber-400' :
              'text-red-400'
            }`}>{confidence}/10</span>
            <span>Highly confident</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Timeframe</label>
            <input
              type="text"
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              placeholder="By end of Q1, Within 2 weeks..."
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Resolution Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!question.trim() || !prediction.trim() || !dueDate}
            className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-zinc-900 font-medium rounded-lg disabled:opacity-50"
          >
            Record Prediction
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// RESOLVE FORM
// ============================================================================

function ResolveForm({
  prediction,
  onSave,
  onCancel
}: {
  prediction: Prediction
  onSave: (outcome: string, accuracy: number, lessons?: string) => void
  onCancel: () => void
}) {
  const [outcome, setOutcome] = useState('')
  const [accuracy, setAccuracy] = useState(50)
  const [lessons, setLessons] = useState('')
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-4">Resolve Prediction</h2>
      
      <div className="p-3 bg-zinc-800/50 rounded mb-4">
        <p className="text-xs text-zinc-500 mb-1">You predicted:</p>
        <p className="text-sm text-zinc-300">{prediction.prediction}</p>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-zinc-400 mb-2">What actually happened?</label>
          <textarea
            value={outcome}
            onChange={(e) => setOutcome(e.target.value)}
            placeholder="The actual outcome was..."
            rows={3}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Accuracy (0-100%)</label>
          <input
            type="range"
            min="0"
            max="100"
            value={accuracy}
            onChange={(e) => setAccuracy(parseInt(e.target.value))}
            className="w-full"
          />
          <p className="text-center text-lg font-bold text-cyan-400">{accuracy}%</p>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Lessons Learned (optional)</label>
          <textarea
            value={lessons}
            onChange={(e) => setLessons(e.target.value)}
            placeholder="What did you learn from this prediction?"
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={() => onSave(outcome, accuracy, lessons || undefined)}
            disabled={!outcome.trim()}
            className="flex-1 py-3 bg-emerald-500/20 text-emerald-400 rounded-lg disabled:opacity-50"
          >
            Resolve
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function RealityTestingPage() {
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [resolvingPrediction, setResolvingPrediction] = useState<Prediction | null>(null)
  const [filter, setFilter] = useState<'all' | 'pending' | 'resolved'>('all')
  
  // Load predictions
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-predictions')
      if (saved) setPredictions(JSON.parse(saved))
    }
  }, [])
  
  const savePrediction = (prediction: Omit<Prediction, 'id' | 'createdAt' | 'resolved'>) => {
    const newPrediction: Prediction = {
      ...prediction,
      id: `pred-${Date.now()}`,
      resolved: false,
      createdAt: Date.now()
    }
    
    const updated = [newPrediction, ...predictions]
    setPredictions(updated)
    localStorage.setItem('cascade-predictions', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const resolvePrediction = (id: string, outcome: string, accuracy: number, lessons?: string) => {
    const updated = predictions.map(p => {
      if (p.id === id) {
        return {
          ...p,
          resolved: true,
          outcome,
          accuracy,
          lessonsLearned: lessons,
          resolvedAt: Date.now()
        }
      }
      return p
    })
    setPredictions(updated)
    localStorage.setItem('cascade-predictions', JSON.stringify(updated))
    setResolvingPrediction(null)
  }
  
  // Calculate calibration stats
  const calibrationStats = useMemo((): CalibrationStats => {
    const resolved = predictions.filter(p => p.resolved)
    const avgConfidence = resolved.length > 0
      ? resolved.reduce((sum, p) => sum + p.confidence * 10, 0) / resolved.length
      : 0
    const avgAccuracy = resolved.length > 0
      ? resolved.reduce((sum, p) => sum + (p.accuracy || 0), 0) / resolved.length
      : 0
    
    let overconfident = 0
    let underconfident = 0
    let wellCalibrated = 0
    
    resolved.forEach(p => {
      const confPercent = p.confidence * 10
      const acc = p.accuracy || 0
      const diff = confPercent - acc
      
      if (diff > 20) overconfident++
      else if (diff < -20) underconfident++
      else wellCalibrated++
    })
    
    // Calibration score: 50 is perfect, <50 overconfident, >50 underconfident
    const calibrationScore = resolved.length > 0
      ? 50 + (avgAccuracy - avgConfidence) / 2
      : 50
    
    return {
      totalPredictions: predictions.length,
      resolved: resolved.length,
      avgConfidence,
      avgAccuracy,
      calibrationScore: Math.max(0, Math.min(100, calibrationScore)),
      overconfident,
      underconfident,
      wellCalibrated
    }
  }, [predictions])
  
  const filteredPredictions = filter === 'all' ? predictions :
    filter === 'pending' ? predictions.filter(p => !p.resolved) :
    predictions.filter(p => p.resolved)
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Reality Testing</h1>
        <p className="text-zinc-500">Calibrate your perception through prediction tracking</p>
      </header>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content */}
        <div className="lg:col-span-2">
          {showCreate ? (
            <CreatePredictionForm onSave={savePrediction} onCancel={() => setShowCreate(false)} />
          ) : resolvingPrediction ? (
            <ResolveForm
              prediction={resolvingPrediction}
              onSave={(outcome, accuracy, lessons) => 
                resolvePrediction(resolvingPrediction.id, outcome, accuracy, lessons)
              }
              onCancel={() => setResolvingPrediction(null)}
            />
          ) : (
            <>
              <button
                onClick={() => setShowCreate(true)}
                className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/30 transition-all"
              >
                + Make a Prediction
              </button>
              
              {/* Filter */}
              <div className="flex gap-2 mb-4">
                {(['all', 'pending', 'resolved'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-4 py-2 rounded-lg text-sm capitalize ${
                      filter === f ? 'bg-cyan-500/20 text-cyan-400' : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
              
              {filteredPredictions.length === 0 ? (
                <div className="cascade-card p-12 text-center">
                  <p className="text-4xl mb-4">🎯</p>
                  <p className="text-zinc-400">No predictions yet</p>
                  <p className="text-sm text-zinc-600">Test your reality perception</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredPredictions.map(prediction => (
                    <PredictionCard
                      key={prediction.id}
                      prediction={prediction}
                      onResolve={() => setResolvingPrediction(prediction)}
                      onSelect={() => {}}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          <CalibrationDisplay stats={calibrationStats} />
          
          {/* Stats */}
          <div className="cascade-card p-6">
            <h3 className="text-lg font-medium text-zinc-200 mb-4">📈 Stats</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-zinc-500">Total Predictions</span>
                <span className="font-bold text-cyan-400">{calibrationStats.totalPredictions}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Resolved</span>
                <span className="font-bold text-emerald-400">{calibrationStats.resolved}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Pending</span>
                <span className="font-bold text-amber-400">
                  {calibrationStats.totalPredictions - calibrationStats.resolved}
                </span>
              </div>
            </div>
          </div>
          
          {/* Philosophy */}
          <div className="cascade-card p-6 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
            <h3 className="text-lg font-medium text-zinc-200 mb-3">🎯 On Reality Testing</h3>
            <p className="text-sm text-zinc-400 mb-3">
              "The first principle is that you must not fool yourself—and you are the easiest person to fool." — Richard Feynman
            </p>
            <p className="text-sm text-zinc-500">
              By recording predictions and comparing them to outcomes, you calibrate your 
              perception of reality. Overconfidence and underconfidence both distort 
              decision-making. Perfect calibration means your confidence matches your accuracy.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
