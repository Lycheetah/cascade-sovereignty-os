'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface InnerPart {
  id: string
  name: string
  role: PartRole
  description: string
  age?: number | string  // Age when this part formed
  appearance?: string   // How you visualize this part
  voice?: string        // What this part says
  needs: string[]       // What this part needs
  fears: string[]       // What this part fears
  gifts: string[]       // What this part offers when balanced
  triggers: string[]
  relationshipWithSelf: number  // 1-10 how connected
  lastDialogue?: number
  dialogueHistory: PartDialogue[]
  color: string
  emoji: string
  createdAt: number
}

type PartRole = 
  | 'protector'   // Guards against pain
  | 'manager'     // Keeps life organized
  | 'firefighter' // Emergency responses
  | 'exile'       // Holds pain/trauma
  | 'inner_child' // Young wounded self
  | 'critic'      // Critical voice
  | 'achiever'    // Drives accomplishment
  | 'pleaser'     // Seeks approval
  | 'rebel'       // Resists authority
  | 'sage'        // Inner wisdom
  | 'other'

interface PartDialogue {
  id: string
  partId: string
  selfMessage: string
  partResponse: string
  outcome: 'healing' | 'understanding' | 'resistance' | 'integration'
  insights?: string
  timestamp: number
}

interface CouncilSession {
  id: string
  topic: string
  partsInvolved: string[]
  transcript: {
    speaker: string  // 'self' or part id
    message: string
  }[]
  resolution?: string
  timestamp: number
}

// ============================================================================
// CONSTANTS
// ============================================================================

const PART_ROLES: Record<PartRole, { label: string; icon: string; color: string; description: string }> = {
  protector: { label: 'Protector', icon: '🛡️', color: 'blue', description: 'Guards against emotional pain' },
  manager: { label: 'Manager', icon: '📋', color: 'cyan', description: 'Keeps life organized and controlled' },
  firefighter: { label: 'Firefighter', icon: '🧯', color: 'red', description: 'Emergency responses to overwhelm' },
  exile: { label: 'Exile', icon: '🔒', color: 'purple', description: 'Holds pain and vulnerability' },
  inner_child: { label: 'Inner Child', icon: '👶', color: 'pink', description: 'Young wounded aspects' },
  critic: { label: 'Critic', icon: '👁️', color: 'amber', description: 'Critical inner voice' },
  achiever: { label: 'Achiever', icon: '🏆', color: 'emerald', description: 'Drives accomplishment' },
  pleaser: { label: 'Pleaser', icon: '🤝', color: 'teal', description: 'Seeks approval and harmony' },
  rebel: { label: 'Rebel', icon: '🔥', color: 'orange', description: 'Resists authority and rules' },
  sage: { label: 'Sage', icon: '🧙', color: 'indigo', description: 'Source of inner wisdom' },
  other: { label: 'Other', icon: '✧', color: 'zinc', description: 'Unique aspect' }
}

const DIALOGUE_PROMPTS = [
  "What do you need from me right now?",
  "What are you trying to protect me from?",
  "How old are you? When did you first appear?",
  "What do you fear will happen if you stop?",
  "What gift do you bring when you're balanced?",
  "How can I help you feel safe?",
  "What would help you trust me more?",
  "Is there something you've been wanting to tell me?"
]

// ============================================================================
// PART CARD
// ============================================================================

function PartCard({ 
  part, 
  onSelect,
  onDialogue
}: { 
  part: InnerPart
  onSelect: () => void
  onDialogue: () => void
}) {
  const role = PART_ROLES[part.role]
  
  return (
    <div className={`cascade-card p-5 hover:border-${role.color}-500/30 transition-all`}>
      <div className="flex items-start gap-3 mb-3">
        <div 
          className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl bg-${role.color}-500/20`}
          style={{ backgroundColor: part.color ? `${part.color}20` : undefined }}
        >
          {part.emoji || role.icon}
        </div>
        <div className="flex-1">
          <h3 className="font-medium text-zinc-200">{part.name}</h3>
          <p className={`text-xs text-${role.color}-400`}>{role.label}</p>
        </div>
        <div className="text-right">
          <p className="text-sm font-bold text-cyan-400">{part.relationshipWithSelf}/10</p>
          <p className="text-xs text-zinc-500">Connection</p>
        </div>
      </div>
      
      <p className="text-sm text-zinc-400 line-clamp-2 mb-3">{part.description}</p>
      
      {/* Voice */}
      {part.voice && (
        <div className="p-2 bg-zinc-800/50 rounded-lg mb-3">
          <p className="text-xs text-zinc-500 mb-1">This part says:</p>
          <p className="text-sm text-zinc-300 italic">"{part.voice}"</p>
        </div>
      )}
      
      {/* Needs preview */}
      {part.needs.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {part.needs.slice(0, 3).map((need, i) => (
            <span key={i} className={`px-2 py-0.5 bg-${role.color}-500/10 text-${role.color}-400 rounded text-xs`}>
              {need}
            </span>
          ))}
        </div>
      )}
      
      {/* Actions */}
      <div className="flex gap-2">
        <button
          onClick={onSelect}
          className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded-lg text-sm hover:bg-zinc-700"
        >
          Details
        </button>
        <button
          onClick={onDialogue}
          className={`flex-1 py-2 bg-${role.color}-500/20 text-${role.color}-400 rounded-lg text-sm hover:bg-${role.color}-500/30`}
        >
          Dialogue
        </button>
      </div>
    </div>
  )
}

// ============================================================================
// DIALOGUE INTERFACE
// ============================================================================

function DialogueInterface({
  part,
  onSave,
  onClose
}: {
  part: InnerPart
  onSave: (dialogue: Omit<PartDialogue, 'id' | 'timestamp'>) => void
  onClose: () => void
}) {
  const [selfMessage, setSelfMessage] = useState('')
  const [partResponse, setPartResponse] = useState('')
  const [outcome, setOutcome] = useState<PartDialogue['outcome']>('understanding')
  const [insights, setInsights] = useState('')
  const [promptIndex, setPromptIndex] = useState(0)
  
  const role = PART_ROLES[part.role]
  
  const usePrompt = () => {
    setSelfMessage(DIALOGUE_PROMPTS[promptIndex])
    setPromptIndex((promptIndex + 1) % DIALOGUE_PROMPTS.length)
  }
  
  const handleSave = () => {
    if (!selfMessage.trim() || !partResponse.trim()) return
    
    onSave({
      partId: part.id,
      selfMessage,
      partResponse,
      outcome,
      insights: insights || undefined
    })
    
    // Reset
    setSelfMessage('')
    setPartResponse('')
    setInsights('')
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xl bg-${role.color}-500/20`}>
            {part.emoji || role.icon}
          </div>
          <div>
            <h3 className="text-lg font-medium text-zinc-200">Dialogue with {part.name}</h3>
            <p className="text-xs text-zinc-500">Inner Family Systems conversation</p>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      {/* Prompt helper */}
      <div className="mb-4 p-3 bg-purple-500/10 rounded-lg">
        <div className="flex items-center justify-between">
          <p className="text-sm text-purple-400 italic">"{DIALOGUE_PROMPTS[promptIndex]}"</p>
          <button onClick={usePrompt} className="text-xs text-purple-400 hover:text-purple-300">
            Use →
          </button>
        </div>
      </div>
      
      {/* Your message */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">You (Self) say:</label>
        <textarea
          value={selfMessage}
          onChange={(e) => setSelfMessage(e.target.value)}
          placeholder="Speak to this part with curiosity and compassion..."
          rows={2}
          className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
        />
      </div>
      
      {/* Part's response */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">{part.name} responds:</label>
        <textarea
          value={partResponse}
          onChange={(e) => setPartResponse(e.target.value)}
          placeholder="Listen within... what does this part want to say?"
          rows={3}
          className={`w-full px-4 py-3 bg-${role.color}-500/5 border border-${role.color}-500/20 rounded-lg text-zinc-200 resize-none`}
        />
      </div>
      
      {/* Outcome */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">Outcome</label>
        <div className="grid grid-cols-4 gap-2">
          {(['healing', 'understanding', 'resistance', 'integration'] as const).map(o => (
            <button
              key={o}
              onClick={() => setOutcome(o)}
              className={`p-2 rounded-lg text-xs capitalize transition-all ${
                outcome === o
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                  : 'bg-zinc-800 text-zinc-500 hover:bg-zinc-700'
              }`}
            >
              {o === 'healing' && '💚 '}
              {o === 'understanding' && '💡 '}
              {o === 'resistance' && '🔒 '}
              {o === 'integration' && '✧ '}
              {o}
            </button>
          ))}
        </div>
      </div>
      
      {/* Insights */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">Insights (optional)</label>
        <textarea
          value={insights}
          onChange={(e) => setInsights(e.target.value)}
          placeholder="What did you learn from this dialogue?"
          rows={2}
          className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
        />
      </div>
      
      <button
        onClick={handleSave}
        disabled={!selfMessage.trim() || !partResponse.trim()}
        className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-zinc-900 font-medium rounded-lg disabled:opacity-50"
      >
        Save Dialogue
      </button>
      
      {/* Dialogue History */}
      {part.dialogueHistory.length > 0 && (
        <div className="mt-6">
          <p className="text-sm text-zinc-400 mb-2">Previous Dialogues</p>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {part.dialogueHistory.slice(-3).reverse().map(d => (
              <div key={d.id} className="p-2 bg-zinc-800/50 rounded-lg text-xs">
                <p className="text-zinc-500">{new Date(d.timestamp).toLocaleDateString()}</p>
                <p className="text-zinc-300 italic">"{d.partResponse.slice(0, 60)}..."</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================================
// CREATE PART FORM
// ============================================================================

function CreatePartForm({
  onSave,
  onCancel
}: {
  onSave: (part: Omit<InnerPart, 'id' | 'createdAt' | 'dialogueHistory'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState('')
  const [role, setRole] = useState<PartRole>('protector')
  const [description, setDescription] = useState('')
  const [voice, setVoice] = useState('')
  const [age, setAge] = useState('')
  const [needs, setNeeds] = useState('')
  const [fears, setFears] = useState('')
  const [gifts, setGifts] = useState('')
  const [emoji, setEmoji] = useState('')
  
  const handleSubmit = () => {
    if (!name.trim() || !description.trim()) return
    
    onSave({
      name,
      role,
      description,
      voice: voice || undefined,
      age: age || undefined,
      needs: needs.split('\n').filter(n => n.trim()),
      fears: fears.split('\n').filter(f => f.trim()),
      gifts: gifts.split('\n').filter(g => g.trim()),
      triggers: [],
      relationshipWithSelf: 5,
      emoji: emoji || PART_ROLES[role].icon,
      color: ''
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Meet a New Part</h2>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., The Inner Critic, Little Me, The Controller..."
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Emoji (optional)</label>
            <input
              type="text"
              value={emoji}
              onChange={(e) => setEmoji(e.target.value)}
              placeholder="🛡️"
              maxLength={2}
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Role</label>
          <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
            {(Object.entries(PART_ROLES) as [PartRole, typeof PART_ROLES[PartRole]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setRole(key)}
                className={`p-2 rounded-lg text-xs transition-all ${
                  role === key
                    ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                    : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
              >
                <span className="text-lg block">{info.icon}</span>
                <span className="text-zinc-400">{info.label}</span>
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe this part... What does it do? Why is it here?"
            rows={2}
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">What does this part say? (Its voice)</label>
          <input
            type="text"
            value={voice}
            onChange={(e) => setVoice(e.target.value)}
            placeholder="e.g., 'You're not good enough', 'Be careful', 'You need to work harder'..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">How old is this part?</label>
          <input
            type="text"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="e.g., 5 years old, teenage, young adult..."
            className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
          />
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Needs (one per line)</label>
            <textarea
              value={needs}
              onChange={(e) => setNeeds(e.target.value)}
              placeholder="Safety&#10;Recognition&#10;Love"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Fears (one per line)</label>
            <textarea
              value={fears}
              onChange={(e) => setFears(e.target.value)}
              placeholder="Rejection&#10;Failure&#10;Abandonment"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Gifts (one per line)</label>
            <textarea
              value={gifts}
              onChange={(e) => setGifts(e.target.value)}
              placeholder="Discernment&#10;Drive&#10;Protection"
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!name.trim() || !description.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 text-zinc-900 font-medium rounded-lg disabled:opacity-50"
          >
            Welcome This Part
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function InnerCouncilPage() {
  const [parts, setParts] = useState<InnerPart[]>([])
  const [selectedPart, setSelectedPart] = useState<InnerPart | null>(null)
  const [dialoguePart, setDialoguePart] = useState<InnerPart | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  
  // Load parts
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-inner-parts')
      if (saved) setParts(JSON.parse(saved))
    }
  }, [])
  
  const savePart = (part: Omit<InnerPart, 'id' | 'createdAt' | 'dialogueHistory'>) => {
    const newPart: InnerPart = {
      ...part,
      id: `part-${Date.now()}`,
      dialogueHistory: [],
      createdAt: Date.now()
    }
    
    const updated = [newPart, ...parts]
    setParts(updated)
    localStorage.setItem('cascade-inner-parts', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const saveDialogue = (dialogue: Omit<PartDialogue, 'id' | 'timestamp'>) => {
    const newDialogue: PartDialogue = {
      ...dialogue,
      id: `dialogue-${Date.now()}`,
      timestamp: Date.now()
    }
    
    const updated = parts.map(p => {
      if (p.id === dialogue.partId) {
        // Adjust relationship based on outcome
        let relationshipDelta = 0
        switch (dialogue.outcome) {
          case 'healing': relationshipDelta = 1; break
          case 'understanding': relationshipDelta = 0.5; break
          case 'integration': relationshipDelta = 1.5; break
          case 'resistance': relationshipDelta = -0.5; break
        }
        
        return {
          ...p,
          dialogueHistory: [...p.dialogueHistory, newDialogue],
          lastDialogue: Date.now(),
          relationshipWithSelf: Math.min(10, Math.max(1, p.relationshipWithSelf + relationshipDelta))
        }
      }
      return p
    })
    
    setParts(updated)
    localStorage.setItem('cascade-inner-parts', JSON.stringify(updated))
  }
  
  // Stats
  const avgConnection = parts.length > 0
    ? (parts.reduce((sum, p) => sum + p.relationshipWithSelf, 0) / parts.length).toFixed(1)
    : 0
  const totalDialogues = parts.reduce((sum, p) => sum + p.dialogueHistory.length, 0)
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Inner Council</h1>
        <p className="text-zinc-500">Know your parts, lead your self</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{parts.length}</p>
          <p className="text-xs text-zinc-500">Parts Known</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-purple-400">{avgConnection}</p>
          <p className="text-xs text-zinc-500">Avg Connection</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{totalDialogues}</p>
          <p className="text-xs text-zinc-500">Dialogues</p>
        </div>
      </div>
      
      {showCreate ? (
        <CreatePartForm onSave={savePart} onCancel={() => setShowCreate(false)} />
      ) : dialoguePart ? (
        <DialogueInterface
          part={dialoguePart}
          onSave={saveDialogue}
          onClose={() => setDialoguePart(null)}
        />
      ) : (
        <>
          <button
            onClick={() => setShowCreate(true)}
            className="w-full mb-6 py-4 cascade-card text-center text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/30 transition-all"
          >
            + Meet a New Part
          </button>
          
          {parts.length === 0 ? (
            <div className="cascade-card p-12 text-center">
              <p className="text-4xl mb-4">👥</p>
              <p className="text-zinc-400">No inner parts identified yet</p>
              <p className="text-sm text-zinc-600">Begin exploring your inner family</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {parts.map(part => (
                <PartCard
                  key={part.id}
                  part={part}
                  onSelect={() => setSelectedPart(part)}
                  onDialogue={() => setDialoguePart(part)}
                />
              ))}
            </div>
          )}
        </>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-cyan-500/5 to-purple-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">👥 Internal Family Systems</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "All parts are welcome. All parts have positive intent." — Richard Schwartz
        </p>
        <p className="text-sm text-zinc-500">
          We are not a single unified self, but a community of parts. Each part — the critic, 
          the protector, the wounded child — formed to help us survive. By meeting these parts 
          with curiosity and compassion rather than judgment, we can help them release their 
          extreme roles and find balance. You are the Self who leads this inner family.
        </p>
      </div>
    </div>
  )
}
