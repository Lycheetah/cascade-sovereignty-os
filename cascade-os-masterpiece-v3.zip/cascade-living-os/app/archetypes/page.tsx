'use client'

import { useState, useEffect } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface ArchetypeEntry {
  id: string
  archetypeId: string
  expression: 'light' | 'shadow' | 'integrated'
  intensity: number  // 1-10
  context: string
  manifestations: string[]
  insights?: string
  timestamp: number
}

interface ActiveArchetype {
  archetypeId: string
  dominance: number  // How active this archetype is (calculated)
  recentExpression: 'light' | 'shadow' | 'integrated'
  entryCount: number
}

// ============================================================================
// ARCHETYPE DATABASE
// ============================================================================

const ARCHETYPES = {
  hero: {
    name: 'The Hero',
    symbol: '⚔️',
    domain: 'Courage & Transformation',
    light: 'Courage, determination, self-sacrifice for greater good',
    shadow: 'Arrogance, recklessness, savior complex',
    integrated: 'Balanced courage, knowing when to fight and when to yield',
    questions: ['What battle am I being called to?', 'Am I fighting for ego or for truth?'],
    color: 'red'
  },
  sage: {
    name: 'The Sage',
    symbol: '📚',
    domain: 'Wisdom & Understanding',
    light: 'Wisdom, knowledge-seeking, truth-telling',
    shadow: 'Detachment, ivory tower thinking, analysis paralysis',
    integrated: 'Wisdom in service of life, grounded understanding',
    questions: ['What truth am I avoiding?', 'Is my knowledge serving life?'],
    color: 'purple'
  },
  magician: {
    name: 'The Magician',
    symbol: '✨',
    domain: 'Transformation & Power',
    light: 'Transformation, healing, manifestation',
    shadow: 'Manipulation, deception, power abuse',
    integrated: 'Aligned power, transformation in service of wholeness',
    questions: ['Am I using my power ethically?', 'What am I trying to transform?'],
    color: 'indigo'
  },
  lover: {
    name: 'The Lover',
    symbol: '💗',
    domain: 'Connection & Passion',
    light: 'Passion, connection, appreciation of beauty',
    shadow: 'Obsession, addiction, loss of self in other',
    integrated: 'Deep connection while maintaining self, passionate presence',
    questions: ['What do I truly love?', 'Am I losing myself?'],
    color: 'pink'
  },
  king: {
    name: 'The Sovereign',
    symbol: '👑',
    domain: 'Order & Blessing',
    light: 'Order, blessing, rightful authority, generativity',
    shadow: 'Tyranny, weakness, abdication of responsibility',
    integrated: 'Benevolent leadership, creating conditions for others to thrive',
    questions: ['What is my realm?', 'Am I blessing or cursing?'],
    color: 'amber'
  },
  warrior: {
    name: 'The Warrior',
    symbol: '🛡️',
    domain: 'Discipline & Protection',
    light: 'Discipline, protection, clear boundaries',
    shadow: 'Cruelty, destruction, violence without purpose',
    integrated: 'Fierce compassion, strength in service of love',
    questions: ['What am I protecting?', 'Is my aggression serving life?'],
    color: 'orange'
  },
  caregiver: {
    name: 'The Caregiver',
    symbol: '🤲',
    domain: 'Nurturing & Support',
    light: 'Nurturing, compassion, selfless service',
    shadow: 'Martyrdom, enabling, codependency',
    integrated: 'Nourishing others while maintaining self-care',
    questions: ['Am I giving from fullness or emptiness?', 'Who nurtures me?'],
    color: 'emerald'
  },
  explorer: {
    name: 'The Explorer',
    symbol: '🧭',
    domain: 'Freedom & Discovery',
    light: 'Freedom, adventure, self-discovery',
    shadow: 'Restlessness, inability to commit, escapism',
    integrated: 'Grounded exploration, adventure with purpose',
    questions: ['What am I searching for?', 'Am I running toward or away?'],
    color: 'cyan'
  },
  rebel: {
    name: 'The Rebel',
    symbol: '🔥',
    domain: 'Liberation & Revolution',
    light: 'Liberation, breaking unjust systems, authenticity',
    shadow: 'Destruction without creation, rebellion for its own sake',
    integrated: 'Revolutionary energy channeled toward justice and truth',
    questions: ['What needs to be destroyed?', 'What will I build in its place?'],
    color: 'red'
  },
  creator: {
    name: 'The Creator',
    symbol: '🎨',
    domain: 'Innovation & Expression',
    light: 'Creativity, innovation, self-expression',
    shadow: 'Perfectionism, creative blocks, self-indulgence',
    integrated: 'Sustainable creativity, creating in service of beauty and truth',
    questions: ['What wants to be born through me?', 'Am I serving the work?'],
    color: 'violet'
  },
  innocent: {
    name: 'The Innocent',
    symbol: '🌸',
    domain: 'Trust & Optimism',
    light: 'Faith, optimism, purity of heart',
    shadow: 'Naivety, denial, blind trust',
    integrated: 'Wise innocence, trust grounded in discernment',
    questions: ['Where is my faith placed?', 'What am I refusing to see?'],
    color: 'pink'
  },
  orphan: {
    name: 'The Orphan',
    symbol: '🌧️',
    domain: 'Belonging & Resilience',
    light: 'Resilience, empathy, solidarity with suffering',
    shadow: 'Victimhood, cynicism, learned helplessness',
    integrated: 'Resilient hope, transforming wounds into wisdom',
    questions: ['Where do I feel abandoned?', 'How has my suffering made me wise?'],
    color: 'slate'
  },
  trickster: {
    name: 'The Trickster',
    symbol: '🃏',
    domain: 'Chaos & Transformation',
    light: 'Humor, breaking patterns, sacred chaos',
    shadow: 'Cruelty, deception, chaos for its own sake',
    integrated: 'Playful wisdom, using humor to reveal truth',
    questions: ['What pattern needs disrupting?', 'Is my chaos serving growth?'],
    color: 'yellow'
  }
}

type ArchetypeId = keyof typeof ARCHETYPES

// ============================================================================
// ARCHETYPE CARD
// ============================================================================

function ArchetypeCard({
  archetypeId,
  activeData,
  onLog
}: {
  archetypeId: ArchetypeId
  activeData?: ActiveArchetype
  onLog: () => void
}) {
  const arch = ARCHETYPES[archetypeId]
  
  return (
    <div className={`cascade-card p-5 hover:border-${arch.color}-500/30 transition-all`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{arch.symbol}</span>
          <div>
            <h3 className="font-medium text-zinc-200">{arch.name}</h3>
            <p className="text-xs text-zinc-500">{arch.domain}</p>
          </div>
        </div>
        {activeData && (
          <div className={`px-2 py-1 rounded-full text-xs ${
            activeData.recentExpression === 'light' ? 'bg-emerald-500/20 text-emerald-400' :
            activeData.recentExpression === 'shadow' ? 'bg-red-500/20 text-red-400' :
            'bg-purple-500/20 text-purple-400'
          }`}>
            {activeData.recentExpression}
          </div>
        )}
      </div>
      
      {/* Light/Shadow */}
      <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
        <div className="p-2 bg-emerald-500/5 rounded">
          <p className="text-emerald-400 mb-1">Light</p>
          <p className="text-zinc-400 line-clamp-2">{arch.light}</p>
        </div>
        <div className="p-2 bg-red-500/5 rounded">
          <p className="text-red-400 mb-1">Shadow</p>
          <p className="text-zinc-400 line-clamp-2">{arch.shadow}</p>
        </div>
      </div>
      
      {/* Activity indicator */}
      {activeData && (
        <div className="mb-3">
          <div className="flex justify-between text-xs mb-1">
            <span className="text-zinc-500">Dominance</span>
            <span className={`text-${arch.color}-400`}>{activeData.dominance}%</span>
          </div>
          <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <div 
              className={`h-full bg-${arch.color}-500`}
              style={{ width: `${activeData.dominance}%` }}
            />
          </div>
        </div>
      )}
      
      <button
        onClick={onLog}
        className={`w-full py-2 bg-${arch.color}-500/20 text-${arch.color}-400 rounded-lg text-sm hover:bg-${arch.color}-500/30`}
      >
        Log Expression
      </button>
    </div>
  )
}

// ============================================================================
// LOG FORM
// ============================================================================

function LogArchetypeForm({
  archetypeId,
  onSave,
  onClose
}: {
  archetypeId: ArchetypeId
  onSave: (entry: Omit<ArchetypeEntry, 'id' | 'timestamp'>) => void
  onClose: () => void
}) {
  const arch = ARCHETYPES[archetypeId]
  const [expression, setExpression] = useState<'light' | 'shadow' | 'integrated'>('light')
  const [intensity, setIntensity] = useState(5)
  const [context, setContext] = useState('')
  const [manifestations, setManifestations] = useState('')
  const [insights, setInsights] = useState('')
  
  const handleSave = () => {
    if (!context.trim()) return
    
    onSave({
      archetypeId,
      expression,
      intensity,
      context,
      manifestations: manifestations.split('\n').filter(m => m.trim()),
      insights: insights || undefined
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{arch.symbol}</span>
          <div>
            <h3 className="text-lg font-medium text-zinc-200">{arch.name}</h3>
            <p className="text-xs text-zinc-500">Log archetypal expression</p>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      {/* Inquiry Questions */}
      <div className="p-3 bg-purple-500/10 rounded-lg mb-4">
        <p className="text-xs text-purple-400 mb-1">Inquiry</p>
        {arch.questions.map((q, i) => (
          <p key={i} className="text-sm text-zinc-300 italic">• {q}</p>
        ))}
      </div>
      
      {/* Expression Type */}
      <div className="mb-4">
        <p className="text-sm text-zinc-400 mb-2">Expression</p>
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setExpression('light')}
            className={`p-3 rounded-lg text-sm ${
              expression === 'light'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            ☀️ Light
          </button>
          <button
            onClick={() => setExpression('shadow')}
            className={`p-3 rounded-lg text-sm ${
              expression === 'shadow'
                ? 'bg-red-500/20 text-red-400 border border-red-500/50'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            🌑 Shadow
          </button>
          <button
            onClick={() => setExpression('integrated')}
            className={`p-3 rounded-lg text-sm ${
              expression === 'integrated'
                ? 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            ✧ Integrated
          </button>
        </div>
      </div>
      
      {/* Intensity */}
      <div className="mb-4">
        <div className="flex justify-between text-sm mb-1">
          <span className="text-zinc-400">Intensity</span>
          <span className={`text-${arch.color}-400 font-bold`}>{intensity}/10</span>
        </div>
        <input
          type="range"
          min="1"
          max="10"
          value={intensity}
          onChange={(e) => setIntensity(parseInt(e.target.value))}
          className="w-full"
        />
      </div>
      
      {/* Context */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">Context / Situation</label>
        <textarea
          value={context}
          onChange={(e) => setContext(e.target.value)}
          placeholder="When/where did this archetype show up?"
          rows={2}
          className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
        />
      </div>
      
      {/* Manifestations */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">How did it manifest? (one per line)</label>
        <textarea
          value={manifestations}
          onChange={(e) => setManifestations(e.target.value)}
          placeholder="Specific behaviors, thoughts, feelings..."
          rows={3}
          className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
        />
      </div>
      
      {/* Insights */}
      <div className="mb-4">
        <label className="block text-sm text-zinc-400 mb-2">Insights (optional)</label>
        <textarea
          value={insights}
          onChange={(e) => setInsights(e.target.value)}
          placeholder="What did you learn?"
          rows={2}
          className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none"
        />
      </div>
      
      <button
        onClick={handleSave}
        disabled={!context.trim()}
        className={`w-full py-3 bg-gradient-to-r from-${arch.color}-500 to-purple-500 text-white font-medium rounded-lg disabled:opacity-50`}
      >
        Log Expression
      </button>
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function ArchetypesPage() {
  const [entries, setEntries] = useState<ArchetypeEntry[]>([])
  const [loggingArchetype, setLoggingArchetype] = useState<ArchetypeId | null>(null)
  const [activeArchetypes, setActiveArchetypes] = useState<Record<string, ActiveArchetype>>({})
  
  // Load entries
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-archetypes')
      if (saved) {
        const parsed = JSON.parse(saved)
        setEntries(parsed)
        calculateActive(parsed)
      }
    }
  }, [])
  
  const calculateActive = (entryList: ArchetypeEntry[]) => {
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000
    const recentEntries = entryList.filter(e => e.timestamp > thirtyDaysAgo)
    
    const active: Record<string, ActiveArchetype> = {}
    const totalIntensity = recentEntries.reduce((sum, e) => sum + e.intensity, 0) || 1
    
    recentEntries.forEach(entry => {
      if (!active[entry.archetypeId]) {
        active[entry.archetypeId] = {
          archetypeId: entry.archetypeId,
          dominance: 0,
          recentExpression: entry.expression,
          entryCount: 0
        }
      }
      active[entry.archetypeId].dominance += (entry.intensity / totalIntensity) * 100
      active[entry.archetypeId].entryCount++
      if (entry.timestamp > (active[entry.archetypeId] as any).lastTimestamp || 0) {
        active[entry.archetypeId].recentExpression = entry.expression
        ;(active[entry.archetypeId] as any).lastTimestamp = entry.timestamp
      }
    })
    
    setActiveArchetypes(active)
  }
  
  const saveEntry = (entry: Omit<ArchetypeEntry, 'id' | 'timestamp'>) => {
    const newEntry: ArchetypeEntry = {
      ...entry,
      id: `arch-${Date.now()}`,
      timestamp: Date.now()
    }
    
    const updated = [newEntry, ...entries]
    setEntries(updated)
    localStorage.setItem('cascade-archetypes', JSON.stringify(updated))
    calculateActive(updated)
    setLoggingArchetype(null)
  }
  
  // Stats
  const dominantArchetype = Object.values(activeArchetypes)
    .sort((a, b) => b.dominance - a.dominance)[0]
  const lightCount = entries.filter(e => e.expression === 'light').length
  const shadowCount = entries.filter(e => e.expression === 'shadow').length
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Archetypes</h1>
        <p className="text-zinc-500">Track the universal patterns moving through you</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{entries.length}</p>
          <p className="text-xs text-zinc-500">Expressions Logged</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-2xl">{dominantArchetype ? ARCHETYPES[dominantArchetype.archetypeId as ArchetypeId]?.symbol : '?'}</p>
          <p className="text-xs text-zinc-500">Dominant</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{lightCount}</p>
          <p className="text-xs text-zinc-500">Light</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-red-400">{shadowCount}</p>
          <p className="text-xs text-zinc-500">Shadow</p>
        </div>
      </div>
      
      {loggingArchetype ? (
        <LogArchetypeForm
          archetypeId={loggingArchetype}
          onSave={saveEntry}
          onClose={() => setLoggingArchetype(null)}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(Object.keys(ARCHETYPES) as ArchetypeId[]).map(id => (
            <ArchetypeCard
              key={id}
              archetypeId={id}
              activeData={activeArchetypes[id]}
              onLog={() => setLoggingArchetype(id)}
            />
          ))}
        </div>
      )}
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-purple-500/5 to-amber-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">🏛️ On Archetypes</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "The archetype is a tendency to form such representations of a motif—representations 
          that can vary a great deal in detail without losing their basic pattern." — Carl Jung
        </p>
        <p className="text-sm text-zinc-500">
          Archetypes are universal patterns of human experience. They live in the collective 
          unconscious and express through us in both light and shadow forms. By tracking which 
          archetypes are active, you gain insight into the deeper currents moving through your 
          life. The goal is not to eliminate shadow expressions, but to integrate them.
        </p>
      </div>
    </div>
  )
}
