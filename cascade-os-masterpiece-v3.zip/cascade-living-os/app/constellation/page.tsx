'use client'

import { useState, useEffect, useRef } from 'react'

// ============================================================================
// TYPES
// ============================================================================

interface Relationship {
  id: string
  name: string
  type: RelationshipType
  
  // Position in constellation (polar coordinates from center = you)
  distance: number       // 1-5 (1 = closest)
  angle: number          // 0-360 degrees
  
  // Qualities
  qualities: RelationshipQuality[]
  energyFlow: 'gives' | 'takes' | 'mutual' | 'blocked'
  currentState: 'thriving' | 'stable' | 'strained' | 'healing' | 'dormant'
  
  // History
  history?: string
  lessons: string[]
  patterns: string[]     // Recurring patterns
  triggers?: string[]    // What triggers you in this relationship
  
  // Dynamics
  needs: string[]        // What you need from them
  offers: string[]       // What you offer them
  boundaries: string[]   // Boundaries set/needed
  
  // Tracking
  lastContact?: number
  interactionLog: RelationshipInteraction[]
  
  color: string
  emoji: string
  createdAt: number
}

interface RelationshipInteraction {
  id: string
  type: 'connection' | 'conflict' | 'repair' | 'milestone' | 'boundary' | 'gift'
  description: string
  impact: 'positive' | 'negative' | 'neutral'
  insights?: string
  timestamp: number
}

type RelationshipType = 
  | 'partner' | 'family' | 'friend' | 'colleague' 
  | 'mentor' | 'mentee' | 'acquaintance' | 'ancestor'
  | 'inner'  // Inner relationship (with self, with parts)

type RelationshipQuality = 
  | 'trust' | 'intimacy' | 'support' | 'growth' 
  | 'challenge' | 'joy' | 'healing' | 'creative'
  | 'spiritual' | 'practical' | 'intellectual' | 'playful'

// ============================================================================
// CONSTANTS
// ============================================================================

const RELATIONSHIP_TYPES: Record<RelationshipType, { label: string; icon: string; color: string }> = {
  partner: { label: 'Partner', icon: '💕', color: 'pink' },
  family: { label: 'Family', icon: '👨‍👩‍👧', color: 'amber' },
  friend: { label: 'Friend', icon: '🤝', color: 'cyan' },
  colleague: { label: 'Colleague', icon: '💼', color: 'blue' },
  mentor: { label: 'Mentor', icon: '🎓', color: 'purple' },
  mentee: { label: 'Mentee', icon: '🌱', color: 'emerald' },
  acquaintance: { label: 'Acquaintance', icon: '👋', color: 'zinc' },
  ancestor: { label: 'Ancestor', icon: '🕯️', color: 'amber' },
  inner: { label: 'Inner', icon: '🔮', color: 'indigo' }
}

const QUALITIES: { id: RelationshipQuality; label: string; icon: string }[] = [
  { id: 'trust', label: 'Trust', icon: '🛡️' },
  { id: 'intimacy', label: 'Intimacy', icon: '💗' },
  { id: 'support', label: 'Support', icon: '🤲' },
  { id: 'growth', label: 'Growth', icon: '🌱' },
  { id: 'challenge', label: 'Challenge', icon: '⚔️' },
  { id: 'joy', label: 'Joy', icon: '😊' },
  { id: 'healing', label: 'Healing', icon: '💚' },
  { id: 'creative', label: 'Creative', icon: '🎨' },
  { id: 'spiritual', label: 'Spiritual', icon: '✨' },
  { id: 'practical', label: 'Practical', icon: '🔧' },
  { id: 'intellectual', label: 'Intellectual', icon: '🧠' },
  { id: 'playful', label: 'Playful', icon: '🎭' }
]

const STATE_INFO = {
  thriving: { label: 'Thriving', color: 'emerald', icon: '🌟' },
  stable: { label: 'Stable', color: 'cyan', icon: '⚖️' },
  strained: { label: 'Strained', color: 'amber', icon: '⚠️' },
  healing: { label: 'Healing', color: 'purple', icon: '💜' },
  dormant: { label: 'Dormant', color: 'zinc', icon: '💤' }
}

// ============================================================================
// CONSTELLATION VISUALIZATION
// ============================================================================

function ConstellationView({ 
  relationships,
  onSelect
}: { 
  relationships: Relationship[]
  onSelect: (r: Relationship) => void
}) {
  const centerX = 200
  const centerY = 200
  const maxRadius = 180
  
  const getPosition = (r: Relationship) => {
    const radius = (r.distance / 5) * maxRadius
    const rad = (r.angle * Math.PI) / 180
    return {
      x: centerX + radius * Math.cos(rad),
      y: centerY + radius * Math.sin(rad)
    }
  }
  
  const getEnergyColor = (flow: Relationship['energyFlow']) => {
    switch (flow) {
      case 'gives': return '#10b981'   // emerald
      case 'takes': return '#ef4444'   // red
      case 'mutual': return '#06b6d4'  // cyan
      case 'blocked': return '#71717a' // zinc
    }
  }
  
  return (
    <svg viewBox="0 0 400 400" className="w-full max-w-lg mx-auto">
      {/* Background circles */}
      {[1, 2, 3, 4, 5].map(d => (
        <circle
          key={d}
          cx={centerX}
          cy={centerY}
          r={(d / 5) * maxRadius}
          fill="none"
          stroke="rgb(39, 39, 42)"
          strokeWidth="1"
          strokeDasharray={d === 5 ? "4 4" : "none"}
        />
      ))}
      
      {/* Connection lines */}
      {relationships.map(r => {
        const pos = getPosition(r)
        return (
          <line
            key={`line-${r.id}`}
            x1={centerX}
            y1={centerY}
            x2={pos.x}
            y2={pos.y}
            stroke={getEnergyColor(r.energyFlow)}
            strokeWidth="1"
            strokeOpacity="0.3"
          />
        )
      })}
      
      {/* Center (You) */}
      <circle
        cx={centerX}
        cy={centerY}
        r="20"
        fill="url(#centerGradient)"
        className="drop-shadow-lg"
      />
      <text
        x={centerX}
        y={centerY}
        textAnchor="middle"
        dominantBaseline="middle"
        className="text-sm fill-zinc-100"
      >
        You
      </text>
      
      {/* Relationship nodes */}
      {relationships.map(r => {
        const pos = getPosition(r)
        const state = STATE_INFO[r.currentState]
        return (
          <g key={r.id} onClick={() => onSelect(r)} className="cursor-pointer">
            <circle
              cx={pos.x}
              cy={pos.y}
              r="16"
              fill={`rgb(39, 39, 42)`}
              stroke={getEnergyColor(r.energyFlow)}
              strokeWidth="2"
              className="hover:stroke-white transition-all"
            />
            <text
              x={pos.x}
              y={pos.y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-sm pointer-events-none"
            >
              {r.emoji}
            </text>
            <text
              x={pos.x}
              y={pos.y + 26}
              textAnchor="middle"
              className="text-xs fill-zinc-400 pointer-events-none"
            >
              {r.name.slice(0, 10)}
            </text>
          </g>
        )
      })}
      
      {/* Gradient definitions */}
      <defs>
        <radialGradient id="centerGradient">
          <stop offset="0%" stopColor="rgb(6, 182, 212)" />
          <stop offset="100%" stopColor="rgb(168, 85, 247)" />
        </radialGradient>
      </defs>
    </svg>
  )
}

// ============================================================================
// CREATE RELATIONSHIP FORM
// ============================================================================

function CreateRelationshipForm({
  onSave,
  onCancel
}: {
  onSave: (r: Omit<Relationship, 'id' | 'createdAt' | 'interactionLog'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState('')
  const [type, setType] = useState<RelationshipType>('friend')
  const [distance, setDistance] = useState(3)
  const [angle, setAngle] = useState(Math.floor(Math.random() * 360))
  const [qualities, setQualities] = useState<RelationshipQuality[]>([])
  const [energyFlow, setEnergyFlow] = useState<Relationship['energyFlow']>('mutual')
  const [currentState, setCurrentState] = useState<Relationship['currentState']>('stable')
  const [needs, setNeeds] = useState('')
  const [offers, setOffers] = useState('')
  const [patterns, setPatterns] = useState('')
  const [emoji, setEmoji] = useState('👤')
  
  const toggleQuality = (q: RelationshipQuality) => {
    setQualities(prev => 
      prev.includes(q) ? prev.filter(x => x !== q) : [...prev, q]
    )
  }
  
  const handleSubmit = () => {
    if (!name.trim()) return
    
    onSave({
      name,
      type,
      distance,
      angle,
      qualities,
      energyFlow,
      currentState,
      needs: needs.split('\n').filter(n => n.trim()),
      offers: offers.split('\n').filter(o => o.trim()),
      patterns: patterns.split('\n').filter(p => p.trim()),
      lessons: [],
      boundaries: [],
      color: RELATIONSHIP_TYPES[type].color,
      emoji
    })
  }
  
  return (
    <div className="cascade-card p-6">
      <h2 className="text-xl font-bold text-zinc-100 mb-6">Add Relationship</h2>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Person's name..."
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Emoji</label>
            <input
              type="text"
              value={emoji}
              onChange={(e) => setEmoji(e.target.value)}
              maxLength={2}
              className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Type</label>
          <div className="grid grid-cols-3 gap-2">
            {(Object.entries(RELATIONSHIP_TYPES) as [RelationshipType, typeof RELATIONSHIP_TYPES[RelationshipType]][]).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setType(key)}
                className={`p-2 rounded-lg text-xs ${
                  type === key
                    ? `bg-${info.color}-500/20 border border-${info.color}-500/50`
                    : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
              >
                {info.icon} {info.label}
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Closeness (1 = closest, 5 = furthest)</label>
          <input
            type="range"
            min="1"
            max="5"
            value={distance}
            onChange={(e) => setDistance(parseInt(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-zinc-600">
            <span>Intimate</span>
            <span className="text-cyan-400 font-bold">{distance}</span>
            <span>Distant</span>
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Qualities</label>
          <div className="flex flex-wrap gap-2">
            {QUALITIES.map(q => (
              <button
                key={q.id}
                onClick={() => toggleQuality(q.id)}
                className={`px-3 py-1 rounded-full text-xs ${
                  qualities.includes(q.id)
                    ? 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
                    : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                {q.icon} {q.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Energy Flow</label>
            <div className="grid grid-cols-2 gap-2">
              {(['mutual', 'gives', 'takes', 'blocked'] as const).map(flow => (
                <button
                  key={flow}
                  onClick={() => setEnergyFlow(flow)}
                  className={`p-2 rounded-lg text-xs capitalize ${
                    energyFlow === flow
                      ? flow === 'mutual' ? 'bg-cyan-500/20 text-cyan-400' :
                        flow === 'gives' ? 'bg-emerald-500/20 text-emerald-400' :
                        flow === 'takes' ? 'bg-red-500/20 text-red-400' :
                        'bg-zinc-700 text-zinc-400'
                      : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {flow === 'mutual' && '↔️ '}
                  {flow === 'gives' && '→ '}
                  {flow === 'takes' && '← '}
                  {flow === 'blocked' && '✕ '}
                  {flow}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">Current State</label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.entries(STATE_INFO) as [Relationship['currentState'], typeof STATE_INFO[keyof typeof STATE_INFO]][]).map(([key, info]) => (
                <button
                  key={key}
                  onClick={() => setCurrentState(key)}
                  className={`p-2 rounded-lg text-xs ${
                    currentState === key
                      ? `bg-${info.color}-500/20 text-${info.color}-400`
                      : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {info.icon} {info.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">What you need (one per line)</label>
            <textarea
              value={needs}
              onChange={(e) => setNeeds(e.target.value)}
              placeholder="Support, understanding..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-400 mb-2">What you offer (one per line)</label>
            <textarea
              value={offers}
              onChange={(e) => setOffers(e.target.value)}
              placeholder="Loyalty, humor..."
              rows={3}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
            />
          </div>
        </div>
        
        <div>
          <label className="block text-sm text-zinc-400 mb-2">Patterns you notice (one per line)</label>
          <textarea
            value={patterns}
            onChange={(e) => setPatterns(e.target.value)}
            placeholder="Recurring dynamics..."
            rows={2}
            className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-200 resize-none text-sm"
          />
        </div>
        
        <div className="flex gap-3 pt-4">
          <button onClick={onCancel} className="flex-1 py-3 bg-zinc-800 text-zinc-400 rounded-lg">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!name.trim()}
            className="flex-1 py-3 bg-gradient-to-r from-pink-500 to-purple-500 text-white font-medium rounded-lg disabled:opacity-50"
          >
            Add to Constellation
          </button>
        </div>
      </div>
    </div>
  )
}

// ============================================================================
// RELATIONSHIP DETAIL
// ============================================================================

function RelationshipDetail({
  relationship,
  onClose,
  onUpdate,
  onLogInteraction
}: {
  relationship: Relationship
  onClose: () => void
  onUpdate: (r: Relationship) => void
  onLogInteraction: (log: Omit<RelationshipInteraction, 'id' | 'timestamp'>) => void
}) {
  const [showLogForm, setShowLogForm] = useState(false)
  const [logType, setLogType] = useState<RelationshipInteraction['type']>('connection')
  const [logDesc, setLogDesc] = useState('')
  const [logImpact, setLogImpact] = useState<RelationshipInteraction['impact']>('positive')
  
  const typeInfo = RELATIONSHIP_TYPES[relationship.type]
  const stateInfo = STATE_INFO[relationship.currentState]
  
  const handleLogSubmit = () => {
    if (!logDesc.trim()) return
    onLogInteraction({ type: logType, description: logDesc, impact: logImpact })
    setLogDesc('')
    setShowLogForm(false)
  }
  
  return (
    <div className="cascade-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <span className="text-4xl">{relationship.emoji}</span>
          <div>
            <h2 className="text-xl font-bold text-zinc-100">{relationship.name}</h2>
            <p className={`text-sm text-${typeInfo.color}-400`}>{typeInfo.icon} {typeInfo.label}</p>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">✕</button>
      </div>
      
      {/* Status badges */}
      <div className="flex flex-wrap gap-2 mb-6">
        <span className={`px-3 py-1 rounded-full text-xs bg-${stateInfo.color}-500/20 text-${stateInfo.color}-400`}>
          {stateInfo.icon} {stateInfo.label}
        </span>
        <span className={`px-3 py-1 rounded-full text-xs ${
          relationship.energyFlow === 'mutual' ? 'bg-cyan-500/20 text-cyan-400' :
          relationship.energyFlow === 'gives' ? 'bg-emerald-500/20 text-emerald-400' :
          relationship.energyFlow === 'takes' ? 'bg-red-500/20 text-red-400' :
          'bg-zinc-700 text-zinc-400'
        }`}>
          Energy: {relationship.energyFlow}
        </span>
        <span className="px-3 py-1 rounded-full text-xs bg-zinc-800 text-zinc-400">
          Distance: {relationship.distance}/5
        </span>
      </div>
      
      {/* Qualities */}
      {relationship.qualities.length > 0 && (
        <div className="mb-4">
          <p className="text-xs text-zinc-500 mb-2">Qualities</p>
          <div className="flex flex-wrap gap-1">
            {relationship.qualities.map(q => {
              const quality = QUALITIES.find(x => x.id === q)
              return (
                <span key={q} className="px-2 py-1 bg-purple-500/10 text-purple-400 rounded text-xs">
                  {quality?.icon} {quality?.label}
                </span>
              )
            })}
          </div>
        </div>
      )}
      
      {/* Needs & Offers */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        {relationship.needs.length > 0 && (
          <div className="p-3 bg-cyan-500/5 rounded-lg">
            <p className="text-xs text-cyan-400 mb-2">What you need</p>
            {relationship.needs.map((n, i) => (
              <p key={i} className="text-sm text-zinc-300">• {n}</p>
            ))}
          </div>
        )}
        {relationship.offers.length > 0 && (
          <div className="p-3 bg-emerald-500/5 rounded-lg">
            <p className="text-xs text-emerald-400 mb-2">What you offer</p>
            {relationship.offers.map((o, i) => (
              <p key={i} className="text-sm text-zinc-300">• {o}</p>
            ))}
          </div>
        )}
      </div>
      
      {/* Patterns */}
      {relationship.patterns.length > 0 && (
        <div className="p-3 bg-amber-500/5 rounded-lg mb-4">
          <p className="text-xs text-amber-400 mb-2">Patterns</p>
          {relationship.patterns.map((p, i) => (
            <p key={i} className="text-sm text-zinc-300">• {p}</p>
          ))}
        </div>
      )}
      
      {/* Log interaction */}
      {showLogForm ? (
        <div className="p-4 bg-zinc-800/50 rounded-lg mb-4">
          <div className="grid grid-cols-3 gap-2 mb-3">
            {(['connection', 'conflict', 'repair', 'milestone', 'boundary', 'gift'] as const).map(t => (
              <button
                key={t}
                onClick={() => setLogType(t)}
                className={`p-2 rounded text-xs capitalize ${
                  logType === t ? 'bg-cyan-500/20 text-cyan-400' : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <textarea
            value={logDesc}
            onChange={(e) => setLogDesc(e.target.value)}
            placeholder="What happened?"
            rows={2}
            className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded text-sm text-zinc-200 resize-none mb-2"
          />
          <div className="flex gap-2 mb-2">
            {(['positive', 'neutral', 'negative'] as const).map(impact => (
              <button
                key={impact}
                onClick={() => setLogImpact(impact)}
                className={`flex-1 py-1 rounded text-xs capitalize ${
                  logImpact === impact
                    ? impact === 'positive' ? 'bg-emerald-500/20 text-emerald-400' :
                      impact === 'negative' ? 'bg-red-500/20 text-red-400' :
                      'bg-zinc-700 text-zinc-400'
                    : 'bg-zinc-800 text-zinc-500'
                }`}
              >
                {impact}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowLogForm(false)} className="flex-1 py-2 bg-zinc-800 text-zinc-400 rounded text-sm">
              Cancel
            </button>
            <button onClick={handleLogSubmit} className="flex-1 py-2 bg-cyan-500/20 text-cyan-400 rounded text-sm">
              Log
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowLogForm(true)}
          className="w-full py-2 bg-zinc-800 text-zinc-400 rounded-lg text-sm mb-4 hover:bg-zinc-700"
        >
          + Log Interaction
        </button>
      )}
      
      {/* Interaction history */}
      {relationship.interactionLog.length > 0 && (
        <div>
          <p className="text-xs text-zinc-500 mb-2">Recent Interactions</p>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {relationship.interactionLog.slice(-5).reverse().map(log => (
              <div key={log.id} className={`p-2 rounded text-xs ${
                log.impact === 'positive' ? 'bg-emerald-500/5' :
                log.impact === 'negative' ? 'bg-red-500/5' :
                'bg-zinc-800/50'
              }`}>
                <div className="flex justify-between mb-1">
                  <span className="text-zinc-400 capitalize">{log.type}</span>
                  <span className="text-zinc-600">{new Date(log.timestamp).toLocaleDateString()}</span>
                </div>
                <p className="text-zinc-300">{log.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function ConstellationPage() {
  const [relationships, setRelationships] = useState<Relationship[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedRelationship, setSelectedRelationship] = useState<Relationship | null>(null)
  
  // Load relationships
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cascade-relationships')
      if (saved) setRelationships(JSON.parse(saved))
    }
  }, [])
  
  const saveRelationship = (r: Omit<Relationship, 'id' | 'createdAt' | 'interactionLog'>) => {
    const newRelationship: Relationship = {
      ...r,
      id: `rel-${Date.now()}`,
      interactionLog: [],
      createdAt: Date.now()
    }
    
    const updated = [newRelationship, ...relationships]
    setRelationships(updated)
    localStorage.setItem('cascade-relationships', JSON.stringify(updated))
    setShowCreate(false)
  }
  
  const logInteraction = (relationshipId: string, log: Omit<RelationshipInteraction, 'id' | 'timestamp'>) => {
    const newLog: RelationshipInteraction = {
      ...log,
      id: `log-${Date.now()}`,
      timestamp: Date.now()
    }
    
    const updated = relationships.map(r => {
      if (r.id === relationshipId) {
        return {
          ...r,
          interactionLog: [...r.interactionLog, newLog],
          lastContact: Date.now()
        }
      }
      return r
    })
    
    setRelationships(updated)
    localStorage.setItem('cascade-relationships', JSON.stringify(updated))
    
    // Update selected
    if (selectedRelationship?.id === relationshipId) {
      setSelectedRelationship(updated.find(r => r.id === relationshipId) || null)
    }
  }
  
  // Stats
  const thrivingCount = relationships.filter(r => r.currentState === 'thriving').length
  const strainedCount = relationships.filter(r => r.currentState === 'strained').length
  const mutualCount = relationships.filter(r => r.energyFlow === 'mutual').length
  
  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-100 mb-2">Relationship Constellation</h1>
        <p className="text-zinc-500">Map your relational universe</p>
      </header>
      
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-pink-400">{relationships.length}</p>
          <p className="text-xs text-zinc-500">Relationships</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-emerald-400">{thrivingCount}</p>
          <p className="text-xs text-zinc-500">Thriving</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-cyan-400">{mutualCount}</p>
          <p className="text-xs text-zinc-500">Mutual Flow</p>
        </div>
        <div className="cascade-card p-4 text-center">
          <p className="text-3xl font-bold text-amber-400">{strainedCount}</p>
          <p className="text-xs text-zinc-500">Need Attention</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Constellation or Form */}
        <div>
          {showCreate ? (
            <CreateRelationshipForm onSave={saveRelationship} onCancel={() => setShowCreate(false)} />
          ) : selectedRelationship ? (
            <RelationshipDetail
              relationship={selectedRelationship}
              onClose={() => setSelectedRelationship(null)}
              onUpdate={() => {}}
              onLogInteraction={(log) => logInteraction(selectedRelationship.id, log)}
            />
          ) : (
            <div className="cascade-card p-6">
              <h3 className="text-lg font-medium text-zinc-200 mb-4">Your Constellation</h3>
              {relationships.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-4xl mb-4">🌟</p>
                  <p className="text-zinc-400">No relationships mapped yet</p>
                </div>
              ) : (
                <ConstellationView
                  relationships={relationships}
                  onSelect={setSelectedRelationship}
                />
              )}
              <button
                onClick={() => setShowCreate(true)}
                className="w-full mt-4 py-3 bg-pink-500/20 text-pink-400 rounded-lg hover:bg-pink-500/30"
              >
                + Add Relationship
              </button>
            </div>
          )}
        </div>
        
        {/* List view */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-zinc-200">All Relationships</h3>
          {relationships.length === 0 ? (
            <div className="cascade-card p-6 text-center">
              <p className="text-zinc-500">Add your first relationship</p>
            </div>
          ) : (
            relationships.map(r => (
              <div
                key={r.id}
                onClick={() => setSelectedRelationship(r)}
                className={`cascade-card p-4 cursor-pointer hover:border-${RELATIONSHIP_TYPES[r.type].color}-500/30`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{r.emoji}</span>
                  <div className="flex-1">
                    <p className="font-medium text-zinc-200">{r.name}</p>
                    <p className="text-xs text-zinc-500">{RELATIONSHIP_TYPES[r.type].label}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs bg-${STATE_INFO[r.currentState].color}-500/20 text-${STATE_INFO[r.currentState].color}-400`}>
                    {STATE_INFO[r.currentState].label}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Philosophy */}
      <div className="mt-8 cascade-card p-6 bg-gradient-to-br from-pink-500/5 to-purple-500/5">
        <h3 className="text-lg font-medium text-zinc-200 mb-3">💗 On Relationships</h3>
        <p className="text-sm text-zinc-400 mb-3">
          "We are not truly separate from each other. We are interconnected nodes in a 
          living web of relationship." — Martin Buber
        </p>
        <p className="text-sm text-zinc-500">
          Your relationships form a constellation around you. Some stars burn bright and close, 
          others are distant but constant. By mapping this constellation, you can see patterns: 
          where energy flows and where it's blocked, who challenges you to grow and who offers 
          refuge. Healthy relationships have mutual energy flow and clear boundaries.
        </p>
      </div>
    </div>
  )
}
